#!/bin/bash
# Full reproducible V3 build:  ./run.sh            (Blender 4.2 LTS: set BLENDER=/path/to/blender; node >=20 with tools/node_modules installed: cd tools && npm i; toktx on PATH or at /workspace/tools/ktx for KTX2)
#   1 build_scene.py        -> .blend, compat GLBs (build_inst/ intermediates), slots.json, stats.json, export_merge_report.json
#   2 postprocess_glb.mjs   -> compat repack (uint8 COLOR_0), optimized/*.opt.glb (+ .ktx2, .draco), optimization_report.json
#   3 run_validate.sh       -> validation_*.json, slot_diff_*.json (needs python3+numpy[+trimesh])
#   4 perf matrix (optional, slow, software GL):  RUN_PERF=1 ./run.sh   -> perf_results/, perf_results.json, perf_report.md
#   5 gen_docs.py           -> environment_manifest.md, COMPARISON_V1_V2_V3.md, validation_report.md
# NOTE: always run step 1 before step 2 (step 2 rewrites the compat GLBs in place; running it twice on a damaged file keeps the damage).
BL=${BLENDER:-/workspace/blender-4.2.3-linux-x64/blender}
cd "$(dirname "$0")"
set -e
$BL -b --python build_scene.py > build.log 2>&1 || { tail -30 build.log; exit 1; }
node tools/postprocess_glb.mjs . > postprocess.log 2>&1
./run_validate.sh > logs_run_validate.txt 2>&1
[ -n "$RUN_PERF" ] && { tools/perf/run_matrix.sh && python3 tools/perf/summarize.py; }
$BL -b garage_city_environment.blend --python dump_info.py > /dev/null 2>&1
for v in V3; do python3 glb_stats.py garage_city_environment.glb garage_core.glb roads_and_highways.glb city_background.glb waterfront.glb > stats_glb_$v.json; done
python3 gen_docs.py
echo "run.sh done"
