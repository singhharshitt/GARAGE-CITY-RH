# V1 → V2 → V3 comparison

All V1/V2 numbers re-measured from the V1/V2 folders (untouched). 'Draw-call estimate' = glTF primitives (static). 'Measured' = three.js `renderer.info` of the last frame at CAM_Game_Perspective, 1280×720, quality 0 (no shadows/LOD), SwiftShader software GL.

## Geometry, materials, size (compat GLBs)

| file | tris V1 / V2 / V3 | primitives (est.) V1 / V2 / V3 | materials V1 / V2 / V3 | size V1 / V2 / V3 |
|---|---|---|---|---|
| garage_city_environment.glb | 114,636 / 153,832 / 166,305 | 2704 / 656 / 582 | 46 / 61 / 75 | 4.56 MB / 10.85 MB / 10.78 MB |
| garage_core.glb | 20,128 / 38,600 / 48,834 | 391 / 264 / 210 | 32 / 43 / 47 | 1.03 MB / 3.08 MB / 3.36 MB |
| roads_and_highways.glb | 50,520 / 49,526 / 47,971 | 1215 / 120 / 104 | 18 / 18 / 18 | 2.05 MB / 3.52 MB / 3.27 MB |
| city_background.glb | 36,000 / 57,724 / 55,662 | 705 / 231 / 221 | 23 / 36 / 53 | 1.45 MB / 4.12 MB / 3.99 MB |
| waterfront.glb | 7,988 / 7,982 / 13,838 | 393 / 41 / 47 | 17 / 17 / 17 | 0.17 MB / 0.68 MB / 0.97 MB |

V3 optimized combined: 3.53 MB (meshopt+instancing), 3.47 MB (+KTX2), 2.04 MB (Draco). V2 combined: 10.85 MB.

## Measured renderer numbers (software rendering, gameplay camera, quality 0)

| | V1 | V2 | V3 compat | V3 optimized |
|---|---:|---:|---:|---:|
| draw calls @1280×720 | 1124 | 532 | 493 | 577 |
| triangles drawn @1280×720 | 74457 | 138331 | 157925 | 144137 |
| geometries @1280×720 | 352 | 525 | 489 | 438 |
| textures @1280×720 | 6 | 14 | 18 | 18 |
| download ms @1280×720 | 37.4 | 66.2 | 56.4 | 27.3 |
| parse+texture ms @1280×720 | 72.4 | 60 | 66 | 72.1 |
| JS heap Δ load (MB) @1280×720 | 23.9 | 36.7 | 36.2 | 19.7 |
| frame median ms @1280×720 | 104.6 | 120.1 | 134.6 | 138.7 |
| frame median ms @800×450 | 59.8 | 75.5 | 93.6 | 91.9 |

Reading: V3 draws ~14% more triangles than V2 (richer detail) and is ~10–25% slower per frame in software rendering; compat V3 has slightly fewer draw calls than V2, the optimized V3 slightly more (instanced prop meshes). The clear V3 win is transfer size/heap (3.5 MB vs 10.9 MB). One run per row, no repeats → ±~10% noise. **None of this is device FPS.**

## Shipped quality modes, V2 file vs V3 optimized (same quality_modes.js on both; software rendering)

| mode | res | V2 draw calls / tris / median ms | V3 opt draw calls / tris / median ms |
|---|---|---|---|
| full | 1280×720 | 532 / 138,331 / 195.5 | 577 / 144,137 / 233 |
| balanced | 1280×720 | 532 / 138,331 / 196 | 533 / 138,218 / 241.9 |
| low | 1280×720 | 532 / 138,331 / 77.2 | 509 / 133,791 / 89.1 |
| full | 800×450 | 532 / 138,331 / 114.6 | 577 / 144,137 / 164 |
| balanced | 800×450 | 532 / 138,331 / 170.8 | 533 / 138,218 / 172.8 |
| low | 800×450 | 532 / 138,331 / 50.3 | 509 / 133,791 / 61.4 |

(`full` mode includes a shadow pass; 'full' used 12 frames only; the `V3 full 800×450` row was re-run standalone after the matrix script missed it.)

## Qualitative

| aspect | V1 | V2 | V3 |
|---|---|---|---|
| garage | basic compound | enclosed workshop hall, glazed showroom | same layout, more detail (core 38.6k → 48.8k tris), calmer lighting, baked AO, showcase rings/arches as focal point |
| city | uniform boxes, bright window grid | tower generator, 4-layer skyline | fewer/dimmer lit windows, lower far-shore, roof gardens/mechanicals, varied vegetation |
| roads/water | flat | markings, highway | kerbs/sidewalks/joints refined, basin visible in gameplay camera, calm water |
| export | 2.7k primitives | merged chunks | + instancing/meshopt/KTX2/Draco variants, vertex AO, quality modes |
