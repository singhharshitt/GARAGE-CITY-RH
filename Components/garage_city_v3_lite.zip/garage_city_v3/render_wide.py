"""blender -b garage_city_environment.blend --python render_wide.py -- out.png [w h samples] : wide skyline from over the garage looking north-east (inspection only)"""
import bpy, sys, math
from mathutils import Vector
a = sys.argv[sys.argv.index('--') + 1:]
out = a[0]; w = int(a[1]) if len(a) > 1 else 1280; h = int(a[2]) if len(a) > 2 else 720; smp = int(a[3]) if len(a) > 3 else 16
cd = bpy.data.cameras.new('tmpcam'); ob = bpy.data.objects.new('tmpcam', cd); bpy.context.scene.collection.objects.link(ob)
cd.lens = 24; cd.clip_end = 3000; cd.clip_start = 2
ob.location = (-160, -170, 70)
d = Vector((40, 400, 60)) - ob.location
ob.rotation_euler = d.to_track_quat('-Z', 'Y').to_euler()
sc = bpy.context.scene; sc.camera = ob
sc.render.engine = 'BLENDER_EEVEE_NEXT'; sc.render.resolution_x, sc.render.resolution_y = w, h
sc.eevee.taa_render_samples = smp; sc.render.filepath = out
bpy.ops.render.render(write_still=True)
