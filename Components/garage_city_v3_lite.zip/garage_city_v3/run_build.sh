#!/bin/bash
# quick: build + postprocess + blend validation only
BL=${BLENDER:-/workspace/blender-4.2.3-linux-x64/blender}
cd "$(dirname "$0")"
$BL -b --python build_scene.py > build.log 2>&1 && grep -n "Traceback" -A8 build.log
node tools/postprocess_glb.mjs . > postprocess.log 2>&1
$BL -b garage_city_environment.blend --python validate_blend.py 2>&1 | grep -A30 "^VALIDATION_DONE"
