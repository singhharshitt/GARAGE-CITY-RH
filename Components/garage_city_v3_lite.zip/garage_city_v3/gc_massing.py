"""V3 garage massing + landmark showcase.  Everything here is NEW static geometry built around (never inside) the slot
envelopes: tall volumes are only added N/E of the slots and are validated by the keep-clear + sight-line tests.
Hierarchy: (1) glazed atrium tower + central showcase framing, (2) workshop/dock towers with structural depth, (3) canopies."""
from gc_arch import *
from gc_arch import _c
from gc_buildings import parapet


def curtain_wall(mb, x0, x1, y, z0, z1, floors, step=2.2, interior_back=None, glass='glass_tint', frame='structure_dark',
                 ceil_mat='int_panel', depth=0.35, inner='int_wall'):
    """south-facing (outward -Y) glazed curtain wall at plane y with floor slabs, mullions, warm interior and ceiling light strips"""
    L = x1 - x0
    n = max(1, int(round(L / step)))
    st = L / n
    zs = [z0] + list(floors) + [z1]
    for i in range(n + 1):
        mb.box(x0 + st * i, y, z0, 0.16, depth, z1 - z0, frame)
    for z in zs:
        mb.box((x0 + x1) / 2, y, z - 0.1, L, depth, 0.2, frame)
    mb.box((x0 + x1) / 2, y + 0.05, z0, L, 0.05, z1 - z0, glass, top=False)
    # warm interior seen behind the glass: back wall + floor slabs + ceiling strips
    yb = interior_back if interior_back is not None else y + 6.0
    mb.box((x0 + x1) / 2, yb, z0, L, 0.1, z1 - z0, inner, top=False)
    for k, z in enumerate(zs[:-1]):
        mb.box((x0 + x1) / 2, (y + yb) / 2 + 0.4, z, L - 0.4, yb - y - 0.8, 0.12, 'int_floor', mtop='int_floor')
        zc = zs[k + 1] - 0.25
        for j in range(3):
            mb.box((x0 + x1) / 2, y + 1.4 + j * 1.6, zc, L * 0.8, 0.22, 0.06, ceil_mat)
    return n


def pilasters(mb, x0, x1, y_face, z0, z1, n, depth=0.55, w=0.5, m='structure_dark', skip=()):
    st = (x1 - x0) / n
    for i in range(n + 1):
        if i in skip: continue
        mb.box(x0 + st * i, y_face - depth / 2, z0, w, depth, z1 - z0, m)


def build_massing(C, rng):
    cb, cc, cd, cf = C['Buildings'], C['Circulation'], C['Details'], C['Fuel_EV']

    # ================================================================ (1) N1 GLAZED ATRIUM TOWER (dominant showroom volume)
    mb = MB()
    AX0, AX1, AY0, AY1 = -46.0, -28.6, 41.3, 49.6
    z0 = 8.5
    zt = 21.0
    curtain_wall(mb, AX0, AX1, AY0, z0, zt, floors=(12.7, 16.9), step=2.9, interior_back=49.2)
    # east + west flank walls (concrete with a slot window), solid back wall, corner piers
    mb.box(AX0 + 0.3, 45.5, z0, 0.6, 8.2, zt - z0, 'concrete_dk', mtop='concrete_dk')
    mb.box(AX1 - 0.3, 45.5, z0, 0.6, 8.2, zt - z0, 'concrete_dk')
    mb.box((AX0 + AX1) / 2, AY1 - 0.2, z0, AX1 - AX0, 0.4, zt - z0, 'cladding')
    for xx in (AX0, AX1):
        mb.box(xx, AY0, z0, 0.9, 0.9, zt - z0 + 0.5, 'structure_dark')
    # slot window on west flank (vertical amber light)
    mb.box(AX0 - 0.02, 45.5, z0 + 1.5, 0.05, 1.4, zt - z0 - 4, 'int_panel')
    # roof: cantilever plate with LED edge, rooftop plant enclosure and a slim canopy fin
    mb.box((AX0 + AX1) / 2, 45.0, zt, AX1 - AX0 + 3.2, 11.4, 0.45, 'structure_dark', mtop='terrace')
    mb.box((AX0 + AX1) / 2, AY0 - 2.8, zt + 0.02, AX1 - AX0 + 3.2, 0.16, 0.38, 'neon_white')
    mb.box((AX0 + AX1) / 2, 47.5, zt + 0.45, 9.0, 3.8, 2.2, 'cladding', mtop='graphite_dark')
    for k in range(6):
        mb.box(AX0 + 4.2 + 1.5 * k, 45.6, zt + 0.45, 0.1, 0.1, 2.6, 'metal_light')
    mb.box((AX0 + AX1) / 2 - 2, 44.5, zt + 0.45, 2.4, 1.8, 1.4, 'metal_light'); mb.cyl(AX0 + 3.2, 46.5, zt + 0.45, 0.8, 1.6, 'steel_painted', seg=8, mtop='graphite_dark')
    # tall blade fin (landmark): thin tapered blade on the east edge with a vertical light seam
    mb.box(AX1 + 0.4, 44.5, z0, 0.55, 3.2, 27.0, 'structure_dark')
    mb.wedge(AX1 + 0.4, 44.5, z0 + 27.0, 0.55, 3.2, 4.5, 'structure_dark', rot=0)
    mb.box(AX1 + 0.08, 43.2, z0 + 1.0, 0.06, 0.12, 24.0, 'neon_amber')
    mb.finish("Bld_N1_Atrium_Tower", cb)

    # entrance portal on N1's ground floor: heavy piers + lintel + cantilevered canopy with warm downlights
    mb = MB()
    PX = -41.0
    for sx in (-1, 1):
        mb.box(PX + sx * 4.6, 29.9, 0, 1.0, 1.7, 4.8, 'concrete_warm', mtop='concrete_dk')
        mb.box(PX + sx * 4.6, 29.1, 0, 1.15, 0.12, 0.35, 'structure_dark')
    mb.box(PX, 29.9, 4.5, 10.3, 1.7, 0.7, 'concrete_dk', mtop='concrete')
    mb.box(PX, 28.4, 4.15, 11.0, 3.4, 0.28, 'structure_dark', mtop='terrace')
    mb.box(PX, 26.75, 4.2, 11.0, 0.1, 0.32, 'neon_white')
    for k in range(4):
        mb.box(PX - 3.6 + 2.4 * k, 28.3, 4.1, 1.3, 0.22, 0.05, 'int_panel')
    for sx in (-1, 1):
        mb.cyl(PX + sx * 5.2, 26.9, 0, 0.14, 4.15, 'structure_dark', seg=8)          # slender canopy posts
    mb.stairs(PX, 28.2, 0, 7.0, 0.0001, 90, 1, 'concrete', tread=0.1) if False else None
    mb.finish("N1_Entrance_Portal", cb)

    # ================================================================ (2) N2 PAINT & BODY TOWER on the mid roof (replaces loose HVAC)
    mb = MB()
    TX0, TX1, TY0, TY1 = 22.0, 46.0, 41.6, 49.6
    zb = 10.3
    zh = 19.0
    mb.box((TX0 + TX1) / 2, (TY0 + TY1) / 2, zb, TX1 - TX0, TY1 - TY0, zh - zb, 'cladding', mtop='graphite_dark')
    # south face: framing grid + vertical amber slot windows + louvre bands
    for i in range(0, 9):
        mb.box(TX0 + 3.0 * i, TY0 - 0.15, zb, 0.4, 0.4, zh - zb, 'structure_dark')
    for k in range(3):
        mb.box((TX0 + TX1) / 2, TY0 - 0.12, zb + 0.9 + 2.9 * k, TX1 - TX0, 0.3, 0.22, 'structure_dark')
    for i in range(8):
        mb.box(TX0 + 1.5 + 3.0 * i, TY0 - 0.04, zb + 1.4, 0.7, 0.06, 6.2, 'int_panel')          # slot windows (warm)
    for k in range(5):
        mb.box((TX0 + TX1) / 2, TY0 - 0.08, zb + 7.9 + 0.24 * k, TX1 - TX0 - 0.6, 0.12, 0.1, 'graphite_dark')   # louvre band
    mb.box((TX0 + TX1) / 2, TY0 - 0.02, zh - 0.08, TX1 - TX0 + 0.5, 0.5, 0.45, 'structure_dark', mtop='metal_light')   # cap beam
    mb.box(TX0 - 0.02, 45.6, zb + 1.0, 0.06, 5.0, 4.0, 'int_panel')                                   # west face glowing ribbon
    # roof plant on the new roof
    for i in range(4):
        hvac_unit(mb, 26 + 5.2 * i, 46.2, zh, rot=0)
    for i in range(3):
        vent_stack(mb, 25 + 8 * i, 43.6, zh, 2.4)
    pipe_run(mb, [(23, 44.6, zh + 0.9), (45, 44.6, zh + 0.9), (45, 44.6, zh + 0.1)], r=0.09, m='steel_teal')
    cable_tray(mb, 23, 42.6, 45, 42.6, zh + 0.05)
    mb.box(41, 47.5, zh, 3.4, 2.6, 2.6, 'concrete_dk', mtop='graphite_dark'); mb.box(41, 46.18, zh + 0.7, 1.2, 0.05, 1.5, 'steel_painted')   # stair bulkhead
    parapet(mb, TX0, TY0, TX1, TY1, zh, h=0.5, m='structure_dark', cap='metal_light')
    # two tall exhaust flues
    for fx in (44.0, 40.0):
        mb.cyl(fx, 49.0, zh, 0.55, 7.5, 'metal_light', seg=8, r2=0.45)
        mb.cyl(fx, 49.0, zh + 7.5, 0.7, 0.3, 'graphite_dark', seg=8)
    # service gantry bridge between tower and N2 west vault roof: catwalk + railing
    mb.box(22.8, 45.0, zb + 3.2, 1.6, 2.0, 0.12, 'metal_light')
    mb.finish("Bld_N2_Paint_Tower", cb)

    # ================================================================ E1 DOCK TOWER (north end of E1 roof)
    mb = MB()
    ex0, ex1, ey0, ey1 = 62.0, 69.6, 17.8, 36.8
    zb, zh = 8.7, 17.2
    mb.box((ex0 + ex1) / 2, (ey0 + ey1) / 2, zb, ex1 - ex0, ey1 - ey0, zh - zb, 'cladding', mtop='graphite_dark')
    wT = Wall(mb, 'y', ex0)
    # west (camera-facing) elevation: glazed ribbon bands between dark spandrels + vertical fins
    for k in range(3):
        zz = zb + 0.7 + 2.7 * k
        wT.box((ey0 + ey1) / 2, 0.05, zz, ey1 - ey0 - 0.8, 0.1, 1.6, 'glass_tint')
        wT.box((ey0 + ey1) / 2, -0.02, zz + 0.1, ey1 - ey0 - 1.0, 0.06, 1.3, 'int_wall', top=False)
        wT.box((ey0 + ey1) / 2, 0.12, zz - 0.18, ey1 - ey0, 0.28, 0.2, 'structure_dark')
    for i in range(7):
        wT.box(ey0 + 0.4 + (ey1 - ey0 - 0.8) * i / 6, 0.2, zb, 0.3, 0.45, zh - zb, 'structure_dark')
    wT.box((ey0 + ey1) / 2, 0.2, zh - 0.2, ey1 - ey0 + 0.4, 0.6, 0.3, 'metal_light')
    parapet(mb, ex0, ey0, ex1, ey1, zh, h=0.5, m='structure_dark', cap='metal_light')
    hvac_unit(mb, 66, 22, zh, rot=90); hvac_unit(mb, 66, 27, zh, rot=90)
    vent_stack(mb, 64, 31, zh, 2.6); vent_stack(mb, 68, 33, zh, 2.0)
    mb.cyl(66.5, 35.0, zh, 1.7, 2.8, 'steel_painted', seg=10, mtop='graphite_dark')         # water tank
    mb.cyl(66, 19.0, zh, 0.15, 11, 'metal_light', seg=4); mb.box(66, 19.0, zh + 11, 0.3, 0.3, 0.3, 'neon_amber')
    mb.finish("Bld_E1_Dock_Tower", cb)

    # ================================================================ facade depth: pilasters + brise-soleil + overhangs
    mb = MB()
    pilasters(mb, -6, 70, 41.0, 5.4, 10.3, 12, depth=0.45, w=0.5)                       # N2 upper office
    for z_ in (9.4, 9.9):
        mb.box(32, 40.6, z_, 76, 1.2, 0.08, 'structure_dark')                           # shading blades
    mb.box(32, 40.0, 10.3, 76, 2.2, 0.16, 'structure_dark')                             # roof overhang
    mb.box(32, 38.95, 10.3, 76, 0.1, 0.22, 'neon_white')
    pilasters(mb, -70, -19, 33.0, 5.2, 8.2, 10, depth=0.45, w=0.5)                      # N1 upper level
    mb.box(-44.5, 32.2, 8.2, 51, 2.0, 0.16, 'structure_dark')
    mb.box(-44.5, 31.2, 8.2, 51, 0.1, 0.22, 'neon_white')
    pilasters(mb, 62.0, 62.0, 0, 0, 0, 0, depth=0) if False else None
    wP = Wall(mb, 'y', 62.0)
    for i in range(0, 13):
        wP.box(-22 + 58 * i / 12, 0.22, 5.4, 0.5, 0.45, 3.0, 'structure_dark')           # E1 upper pilasters
    for z_ in (8.0, 8.35):
        wP.box(7, 0.6, z_, 62, 1.2, 0.07, 'structure_dark')
    mb.finish("Facade_Depth_Pilasters", cb)

    # ================================================================ fuel + EV canopy upgrades
    mb = MB()
    # fuel canopy: deep fascia, soffit light grid, tapered column collars, roof-top truss, angled corner caps
    fx0, fx1, fy0, fy1 = -38.5, -4.5, -36.2, -29.0
    mb.box(-21.5, fy0 - 0.05, 6.45, fx1 - fx0 + 0.4, 0.3, 0.8, 'structure_dark', mtop='metal_light')
    mb.box(-21.5, fy1 + 0.05, 6.45, fx1 - fx0 + 0.4, 0.3, 0.8, 'structure_dark', mtop='metal_light')
    mb.box(fx0 - 0.05, -32.6, 6.45, 0.3, fy1 - fy0, 0.8, 'structure_dark', mtop='metal_light')
    mb.box(fx1 + 0.05, -32.6, 6.45, 0.3, fy1 - fy0, 0.8, 'structure_dark', mtop='metal_light')
    for k in range(5):
        mb.box(-35.5 + 7.0 * k, -32.6, 5.88, 0.4, 6.4, 0.05, 'neon_white')               # soffit light bars
    for cx in (-37.0, -26.0, -16.0, -6.0):
        mb.box(cx, -29.5, 0, 0.95, 0.95, 0.5, 'concrete_dk', mtop='concrete')            # column collar
        mb.box(cx, -29.5, 5.2, 0.82, 0.82, 0.8, 'structure_dark')                         # capital
    for k in range(4):
        mb.box(-34 + 9.0 * k, -32.6, 6.9, 4.0, 5.2, 0.08, 'solar')                       # roof PV panels (flat)
    mb.box(-21.5, -32.6, 6.92, 34.0, 0.14, 0.35, 'metal_light')                           # ridge truss
    # price pylon blade
    mb.box(-4.5, -44.0, 9.0, 0.8, 0.8, 1.2, 'structure_dark'); mb.box(-4.5, -44.0, 10.2, 1.4, 0.3, 0.2, 'neon_cyan')
    mb.finish("Fuel_Canopy_Upgrade", cf)

    mb = MB()
    mb.box(39, -37.65, 5.4, 36.8, 0.3, 0.7, 'structure_dark', mtop='metal_light')
    mb.box(39, -30.75, 5.4, 36.8, 0.3, 0.7, 'structure_dark', mtop='metal_light')
    for k in range(6):
        mb.box(22.0 + 7.0 * k, -34.2, 5.08, 0.35, 5.8, 0.05, 'neon_cyan')
    for cx in (22.0, 30.0, 39.0, 48.0, 56.0):
        mb.box(cx, -31.4, 0, 0.9, 0.9, 0.45, 'concrete_dk', mtop='concrete')
        mb.box(cx, -31.4, 4.5, 0.74, 0.74, 0.7, 'structure_dark')
    # louvred sunshade fins over the south edge (visible from game camera)
    for k in range(18):
        mb.box(22.0 + 2.0 * k, -37.4, 5.6, 0.08, 0.9, 0.45, 'structure_dark')
    mb.finish("EV_Canopy_Upgrade", cf)

    # ================================================================ gate canopy + guard booth (outside the south wall, clear of every slot ray)
    mb = MB()
    for sx in (-1, 1):
        mb.box(6 + sx * 9.5, -49.5, 0, 0.7, 0.7, 5.0, 'structure_dark')
    mb.box(6, -49.5, 5.0, 20.5, 5.2, 0.4, 'structure_dark', mtop='terrace')
    mb.box(6, -52.1, 5.42, 20.5, 0.14, 0.3, 'neon_white')
    mb.box(6, -49.5, 4.94, 19.0, 3.0, 0.05, 'int_panel')
    # sliding gate rail + guard booth + barrier posts
    mb.box(6, -49.6, 0.0, 17.2, 0.15, 0.05, 'metal_light')
    mb.box(-9.0, -53.0, 0, 2.6, 2.6, 2.7, 'concrete_warm', mtop='structure_dark')
    mb.box(-9.0, -54.31, 0.9, 2.0, 0.06, 1.5, 'glass_tint'); mb.box(-9.0, -54.28, 0.9, 1.9, 0.04, 1.4, 'int_wall')
    mb.box(-9.0, -53.0, 2.7, 3.2, 3.2, 0.2, 'structure_dark', mtop='metal_light')
    mb.finish("Gate_Canopy_GuardBooth", cd)


def build_showcase(mb, cs_ring):
    """V3 central showcase (called from build_garage in place of the V2 block).  Slot envelope above z=0.50 stays empty."""
    ring = cs_ring
    # --- layered base: outer paving apron (flush) with alternating radial inlays, stepped plinth, inset light rings, turntable
    N = 32
    for i in range(N):
        a0, a1 = 2 * math.pi * i / N, 2 * math.pi * (i + 1) / N
        for (r0, r1, z, m) in ((8.6, 9.7, 0.045, 'paving' if i % 2 else 'concrete_dk'),):
            mb.quad((r0 * math.cos(a0), r0 * math.sin(a0), z), (r1 * math.cos(a0), r1 * math.sin(a0), z),
                    (r1 * math.cos(a1), r1 * math.sin(a1), z), (r0 * math.cos(a1), r0 * math.sin(a1), z), m)
    mb.cyl(0, 0, 0, 9.8, 0.04, 'yard_dark', seg=48)
    ring(8.45, 8.58, 0.052, 'neon_amber', 48) if False else None
    mb.cyl(0, 0, 0, 8.7, 0.16, 'concrete', seg=48, mtop='concrete_warm')          # step 1
    mb.cyl(0, 0, 0.16, 8.25, 0.16, 'graphite', seg=48, mtop='paving')              # step 2 (V2 platform edge radius)
    mb.cyl(0, 0, 0.32, 7.95, 0.02, 'paving', seg=48)
    ring(7.45, 7.85, 0.345, 'neon_cyan')                                            # inset cyan ring
    ring(6.95, 7.05, 0.345, 'structure_dark', 48)
    ring(6.45, 6.62, 0.345, 'neon_amber')                                           # inset amber ring
    mb.cyl(0, 0, 0.32, 5.95, 0.18, 'graphite_dark', seg=48, mtop='yard_dark')       # turntable ring (top z 0.50)
    ring(5.3, 5.7, 0.505, 'neon_cyan', 40)
    mb.cyl(0, 0, 0.32, 4.7, 0.185, 'metal_light', seg=48, mtop='metal_light')       # brushed-metal inner disc (top z 0.505)
    ring(4.62, 4.72, 0.508, 'structure_dark', 48)
    for i in range(8):                                                              # radial seams + amber ticks
        a = i * math.pi / 4 + math.pi / 8
        mb.box(3.3 * math.cos(a), 3.3 * math.sin(a), 0.505, 2.8, 0.05, 0.008, 'structure_dark', rot=math.degrees(a))
        mb.box(5.0 * math.cos(a), 5.0 * math.sin(a), 0.51, 0.7, 0.1, 0.008, 'neon_amber', rot=math.degrees(a))
    # --- flush uplights on the apron (12) instead of tall bollards inside the circulation space
    for i in range(12):
        a = 2 * math.pi * i / 12 + math.pi / 12
        mb.box(9.15 * math.cos(a), 9.15 * math.sin(a), 0.045, 0.5, 0.18, 0.04, 'neon_white', rot=math.degrees(a) + 90)
    # --- eastern framing: vertical halo arch (semi-circle in the plane x=14.5) + footings + low curved seating
    xa, R = 15.0, 9.4
    seg = 28
    for i in range(seg):
        a0, a1 = math.pi * i / seg, math.pi * (i + 1) / seg
        p0 = (xa, -R * math.cos(a0), R * math.sin(a0) + 0.2); p1 = (xa, -R * math.cos(a1), R * math.sin(a1) + 0.2)
        mb.pipe(p0, p1, 0.32, 'structure_dark', seg=6, caps=False)
        q0 = (xa - 0.30, p0[1] * 0.985, p0[2] * 0.985 + 0.2 * 0); q1 = (xa - 0.30, p1[1] * 0.985, p1[2] * 0.985)
        mb.pipe(q0, q1, 0.09, 'neon_cyan', seg=4, caps=False)                       # thin inner light line
    for sy in (-1, 1):
        mb.box(xa, sy * R, 0, 1.6, 1.6, 0.5, 'concrete_dk', mtop='concrete_warm')
        mb.box(xa - 0.82, sy * R, 0.2, 0.05, 0.9, 0.05, 'neon_cyan')
    # a smaller inner arch ring for depth
    R2 = 6.6
    for i in range(seg):
        a0, a1 = math.pi * i / seg, math.pi * (i + 1) / seg
        mb.pipe((xa + 1.7, -R2 * math.cos(a0), R2 * math.sin(a0) + 0.2), (xa + 1.7, -R2 * math.cos(a1), R2 * math.sin(a1) + 0.2), 0.16, 'metal_light', seg=5, caps=False)
    for sy in (-1, 1):
        mb.box(xa + 1.7, sy * R2, 0, 0.9, 0.9, 0.35, 'concrete_dk', mtop='concrete_warm')
    # curved low seating (two arcs on the east side, clear of the VIP pads, y<8)
    for (aa0, aa1) in ((-62, -22), (22, 62)):
        n = 8
        for i in range(n):
            a = math.radians(aa0 + (aa1 - aa0) * (i + 0.5) / n)
            rr = 11.3
            mb.box(rr * math.cos(a), rr * math.sin(a), 0, 1.7, 0.5, 0.45, 'concrete_warm', rot=math.degrees(a) + 90, mtop='metal_light')
