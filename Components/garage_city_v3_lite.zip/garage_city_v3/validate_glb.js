// node validate_glb.js file.glb  -> prints gltf-validator summary as JSON
const v = require(process.env.GLTFV || '/workspace/gltfv/node_modules/gltf-validator');
const fs = require('fs');
const f = process.argv[2];
v.validateBytes(new Uint8Array(fs.readFileSync(f)), {uri: f, maxIssues: 0, ignoredIssues: ["UNUSED_OBJECT"]}).then(r => {
  console.log(JSON.stringify({file: f, numErrors: r.issues.numErrors, numWarnings: r.issues.numWarnings, numInfos: r.issues.numInfos, numHints: r.issues.numHints,
    messages: r.issues.messages.slice(0, 8).map(m => m.severity + ' ' + m.code + ' ' + m.pointer), info: {version: (r.info||{}).version, extensionsUsed: (r.info||{}).extensionsUsed, drawCallCount: (r.info||{}).drawCallCount, totalTriangleCount: (r.info||{}).totalTriangleCount, totalVertexCount: (r.info||{}).totalVertexCount, materialCount: (r.info||{}).materialCount, animationCount: (r.info||{}).animationCount}}));
});
