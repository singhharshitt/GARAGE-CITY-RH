"""V2 skyline kit: tapered / stepped / twisted / cylindrical / crowned towers with efficient atlas windows.
All towers use 4 shared window atlases (<=512 px) -> a handful of materials for the whole skyline."""
from gc_lib import *

_BASE_TILE = {'cool': (12.0, 28.8), 'warm': (12.0, 28.8), 'neon': (12.0, 28.8), 'band': (16.0, 57.6), 'curtain': (24.0, 24.0),
              'punch': (25.0, 32.0), 'fins': (24.0, 24.0)}
TILE = {}
for _p in ('win_', 'win_far_', 'win_dist_'):
    for _k, _v in _BASE_TILE.items():
        TILE[_p + _k] = _v

def pick_win(rng, far=False, pref=None):
    """V3: far=0 near (emission 0.85), 1 mid-far (0.55), 2 distant (0.34).  Fewer bright grids: punched / fin / band / curtain mix."""
    if pref: return pref
    lvl = int(far)
    pre = ('win_', 'win_far_', 'win_dist_')[min(lvl, 2)]
    if lvl:
        base = rng.choice(['cool', 'warm', 'band', 'curtain', 'curtain', 'punch', 'punch', 'fins', 'fins'])
    else:
        base = rng.choice(['punch', 'punch', 'punch', 'fins', 'fins', 'cool', 'warm', 'band', 'curtain', 'curtain', 'neon' if rng.random() < 0.15 else 'warm'])
    return pre + base

def uvof(wm, rng, vo=None):
    tw, th = TILE[wm]
    return (tw, th, rng.random(), rng.random() if vo is None else vo)

def crown_ring(mb, x, y, z, w, d, acc, rot=0, t=0.35):
    if acc:
        mb.box(x, y, z, w + 0.5, d + 0.5, t, acc, rot=rot, top=False)

def roof_garden(mb, x, y, z, w, d, rng, rot=0):
    """terrace roof: parapet rim, concrete deck, raised planter beds with trees, walkway between (no full-roof green slab)"""
    t = 0.5
    mb.box(x, y, z, w - 1.0, d - 1.0, 0.25, 'concrete', mtop='concrete')
    for sx in (-1, 1):
        mb.box(x + sx * (w / 2 - 0.5), y, z, t, d - 0.4, 1.0, 'graphite')
        mb.box(x, y + sx * (d / 2 - 0.5), z, w - 0.4, t, 1.0, 'graphite')
    nbx = 2 if w > 18 else 1
    nby = max(1, int(d // 14))
    bw = (w - 5.0) / nbx - 2.2; bd = (d - 5.0) / nby - 2.2
    if bw < 2 or bd < 2: return
    for i in range(nbx):
        for j in range(nby):
            bx = x - (w - 5.0) / 2 + ((w - 5.0) / nbx) * (i + 0.5)
            by = y - (d - 5.0) / 2 + ((d - 5.0) / nby) * (j + 0.5)
            mb.box(bx, by, z + 0.25, bw, bd, 0.55, 'planter', mtop='foliage_b')
            for k in range(1 + int(bw * bd / 30)):
                px, py = bx + rng.uniform(-bw / 3, bw / 3), by + rng.uniform(-bd / 3, bd / 3)
                mb.cyl(px, py, z + 0.8, 0.14, 1.4, 'trunk', seg=4)
                mb.cyl(px, py, z + 1.8, 1.1, 1.5, 'foliage', seg=5, r2=0.15, top=False)

def roof_kit(mb, x, y, z, w, d, rng, rot=0, garden=False):
    """rooftop: a rotating pick of mechanical kits (HVAC + stair bulkhead, water tank on legs, louvre screen, solar array, dish, mast)
    or a green terrace.  V3: every roof gets a different silhouette."""
    if garden and w > 8 and d > 8:
        roof_garden(mb, x, y, z, w, d, rng, rot)
        if rng.random() < 0.5:
            mb.box(x + w * 0.28, y - d * 0.28, z + 0.25, min(4.0, w * 0.2), min(3.5, d * 0.2), 2.6, 'concrete_warm', mtop='graphite_dark')   # lift/stair core in the garden
        return
    k = rng.randint(0, 4)
    mb.box(x + w * 0.15, y - d * 0.12, z, w * 0.32, d * 0.26, 2.2, 'cladding', rot=rot, mtop='graphite_dark')           # plant room
    mb.box(x + w * 0.15, y - d * 0.12 - d * 0.14, z + 0.6, w * 0.26, 0.12, 1.2, 'graphite_dark', rot=rot)             # louvre face
    if k == 0:                    # water tank on legs
        for (ax, ay) in ((-1, -1), (-1, 1), (1, -1), (1, 1)):
            mb.box(x - w * 0.25 + ax * 0.9, y + d * 0.2 + ay * 0.9, z, 0.2, 0.2, 2.4, 'structure_dark')
        mb.cyl(x - w * 0.25, y + d * 0.2, z + 2.4, 1.5, 2.6, 'steel_painted', seg=8, mtop='graphite_dark')
    elif k == 1:                  # louvre screen + solar
        mb.box(x - w * 0.15, y + d * 0.28, z, w * 0.5, 0.35, 2.6, 'structure_dark', top=True)
        for i in range(3):
            mb.box(x - w * 0.3 + i * w * 0.15, y - d * 0.3, z + 0.3, w * 0.12, d * 0.2, 0.15, 'solar', rot=rot)
    elif k == 2:                  # dish + low block
        mb.cyl(x - w * 0.25, y + d * 0.2, z, 0.12, 2.4, 'metal_light', seg=4)
        mb.cyl(x - w * 0.25, y + d * 0.2, z + 2.4, 1.2, 0.4, 'metal_light', seg=8, r2=0.1, top=False)
        mb.box(x - w * 0.2, y - d * 0.25, z, w * 0.2, d * 0.2, 1.4, 'metal_light', rot=rot)
    elif k == 3:                  # stepped bulkhead
        mb.box(x - w * 0.22, y + d * 0.15, z, w * 0.25, d * 0.22, 3.4, 'concrete_dk', rot=rot, mtop='graphite_dark')
        mb.box(x - w * 0.22, y + d * 0.15, z + 3.4, w * 0.15, d * 0.14, 1.4, 'cladding', rot=rot, mtop='graphite_dark')
    if rng.random() < 0.45 and w > 10 and d > 10:
        mb.cyl(x + w * 0.3, y + d * 0.3, z, 0.2, 9 + rng.random() * 10, 'metal_light', seg=4)
        mb.box(x + w * 0.3, y + d * 0.3, z + 9 + 2, 0.45, 0.45, 0.45, 'refl_amber')

def fins(mb, x, y, z, w, d, h, rng, rot=0, n=None):
    """vertical graphite fins on the two camera-facing sides (S and W) for facade layering"""
    n = n or max(2, int(w // 8))
    c, s = math.cos(math.radians(rot)), math.sin(math.radians(rot))
    for i in range(n + 1):
        a = -w / 2 + w * i / n
        px, py = x + a * c + (-d / 2 - 0.2) * -s, y + a * s + (-d / 2 - 0.2) * c
        mb.box(px, py, z + 2, 0.7, 0.5, h - 2, 'graphite', rot=rot)
    for i in range(n + 1):
        a = -d / 2 + d * i / n
        px, py = x + (-w / 2 - 0.2) * c - a * s, y + (-w / 2 - 0.2) * s + a * c
        mb.box(px, py, z + 2, 0.5, 0.7, h - 2, 'graphite', rot=rot)

def tower2(mb, x, y, w, d, h, rng, far=False, near=False, accent=None, podium=0.0, rot=0, kind=None, wm=None, detail=True):
    wm = pick_win(rng, far, wm)
    uv = uvof(wm, rng)
    z0 = 0.0
    if podium > 0 and not far:
        mb.box(x, y, 0, w + 4, d + 4, podium, 'concrete', rot=rot, mtop='planter')
        mb.box(x, y, podium - 0.3, w + 4.3, d + 4.3, 0.3, accent or 'neon_cyan', rot=rot, top=False) if accent else None
        mb.box(x, y, 3.0, w + 4.2, d + 4.2, 3.2, 'glass', rot=rot, top=False) if podium > 6 else None
        z0 = podium
    if kind is None:
        r = rng.random()
        if h < 32: kind = 'block'
        elif h < 60: kind = rng.choice(['block', 'stepped', 'wedge'])
        elif h < 110: kind = rng.choice(['stepped', 'tapered', 'tapered', 'cyl', 'twist', 'block'])
        else: kind = rng.choice(['tapered', 'twist', 'stepped', 'cyl', 'tapered'])
        if w < 14 and kind in ('twist',): kind = 'tapered'
    if far:                       # LOD: far towers use only boxes / frusta / short cylinders
        if kind in ('twist',): kind = 'tapered'
        if kind == 'stepped' and rng.random() < 0.5: kind = 'block'
    zt = z0 + h; wt, dt = w, d
    if kind == 'block':
        mb.box(x, y, z0, w, d, h, wm, rot=rot, mtop='graphite_dark', uv=uv)
        if detail and not far and z0 == 0 and w > 10 and d > 10:      # V3: dark plinth + slab overhang, and an L-wing of different height
            mb.box(x, y, 0, w + 0.5, d + 0.5, 3.4, 'concrete_dk', rot=rot, top=False)
            mb.box(x, y, 3.4, w + 1.0, d + 1.0, 0.35, 'concrete_warm', rot=rot, mtop='concrete')
            if rng.random() < 0.55 and h > 12:
                ww, dd = w * rng.uniform(0.35, 0.5), d * rng.uniform(0.35, 0.5)
                hw = h * rng.uniform(0.45, 0.8)
                sx_, sy_ = rng.choice([-1, 1]), rng.choice([-1, 1])
                mb.box(x + sx_ * (w / 2 + ww / 2 - 0.2), y + sy_ * (d / 2 - dd / 2), 0, ww, dd, hw, pick_win(rng, far, None), rot=0, mtop='concrete_dk', uv=uvof('win_punch', rng))
        if detail and not far and h > 24 and not near: fins(mb, x, y, z0, w, d, h, rng, rot)
        if accent and not far: crown_ring(mb, x, y, zt - 0.3, w, d, accent, rot)
    elif kind == 'stepped':
        t = [0.55, 0.28, 0.17]; s = [1.0, 0.78, 0.5]; z = z0
        for i in range(3):
            hh = h * t[i]
            mb.box(x, y, z, w * s[i], d * s[i], hh, wm, rot=rot, mtop='graphite_dark', uv=(uv[0], uv[1], uv[2] + 0.13 * i, uv[3] + 0.31 * i))
            if i < 2 and not far:   # terrace rim with planting on the setback
                mb.box(x, y, z + hh, w * s[i] + 0.6, d * s[i] + 0.6, 0.45, 'terrace', top=True, mtop='foliage_b') if i == 0 else None
                if accent: crown_ring(mb, x, y, z + hh - 0.25, w * s[i], d * s[i], accent, rot)
            z += hh
        zt = z; wt, dt = w * 0.5, d * 0.5
        if accent and not far: crown_ring(mb, x, y, zt - 0.3, wt, dt, accent, rot)
    elif kind == 'tapered':
        hb = h * 0.3
        mb.box(x, y, z0, w, d, hb, wm, rot=rot, mtop='graphite_dark', uv=uv)
        mb.frustum(x, y, z0 + hb, w, d, w * 0.55, d * 0.55, h - hb, wm, rot=rot, mtop='graphite_dark', uv=(uv[0], uv[1], uv[2], uv[3] + hb / uv[1]))
        zt = z0 + h; wt, dt = w * 0.55, d * 0.55
        if accent and not far:
            crown_ring(mb, x, y, z0 + hb - 0.25, w, d, accent, rot); crown_ring(mb, x, y, zt - 0.3, wt, dt, accent, rot)
        if h > 70:
            mb.cyl(x, y, zt, 0.35, h * 0.12, 'metal_light', seg=4, r2=0.08)
            mb.box(x, y, zt + h * 0.12, 0.5, 0.5, 0.5, 'refl_amber')
    elif kind == 'wedge':
        mb.frustum(x, y, z0, w, d, w, d * 0.45, h, wm, rot=rot, mtop='graphite_dark', uv=uv, off=(0, d * 0.27))
        zt = z0 + h; dt = d * 0.45
    elif kind == 'twist':
        top = mb.twist(x, y, z0, w, d, h, rng.choice([-1, 1]) * rng.uniform(50, 90), 6, wm, taper=0.72, mtop='graphite_dark', uv=uv)
        zt = z0 + h; wt, dt = w * 0.6, d * 0.6
        if accent:
            mb.cyl(x, y, zt, w * 0.28, 0.4, accent, seg=8, top=True)
        mb.cyl(x, y, zt, 0.3, h * 0.14, 'metal_light', seg=4, r2=0.08)
    elif kind == 'cyl':
        r = min(w, d) * 0.5
        seg = 10 if far else 16
        mb.cyl(x, y, z0, r, h, wm, seg=seg, uv=(uv[0], uv[1], uv[2], uv[3]), mtop='graphite_dark')
        if not far:
            for k in range(1, 4):
                zz = z0 + h * k / 4
                mb.cyl(x, y, zz, r + 0.5, 0.5, 'terrace', seg=seg, mtop='foliage_b') if k == 2 else mb.cyl(x, y, zz, r + 0.35, 0.35, accent or 'graphite', seg=seg, top=False)
        zt = z0 + h; wt = dt = r * 1.6
        if accent and not far:
            mb.cyl(x, y, zt - 0.3, r + 0.3, 0.4, accent, seg=seg, top=False)
    if detail and not far:
        roof_kit(mb, x, y, zt, wt, dt, rng, rot, garden=(h < 40 and rng.random() < 0.3))
    elif far and h > 60 and kind != 'cyl':
        mb.box(x, y, zt, 0.4, 0.4, 6, 'metal_light')
    return zt

# ------------------------------------------------------------------ landmarks
def lm_twist(mb, x, y, rng, h=230, w=30):
    mb.box(x, y, 0, w * 1.5, w * 1.5, 14, 'win_curtain', uv=(24, 24, 0.1, 0.1), mtop='planter')
    mb.box(x, y, 12, w * 1.5 + 0.6, w * 1.5 + 0.6, 0.5, 'neon_cyan', top=False)
    mb.twist(x, y, 14, w, w, h - 14, 110, 14, 'win_curtain', taper=0.55, mtop='graphite_dark', uv=(24, 24, 0.0, 0.0))
    z = h
    mb.cyl(x, y, z, w * 0.3, 1.2, 'neon_cyan', seg=10)
    mb.cyl(x, y, z + 1.2, 0.5, 46, 'metal_light', seg=4, r2=0.1)
    mb.box(x, y, z + 47, 1.0, 1.0, 1.0, 'neon_amber')
    return z + 48

def lm_crown(mb, x, y, rng, h=210, w=34):
    """stepped tower with an illuminated crown (open lantern)"""
    mb.box(x, y, 0, w * 1.4, w * 1.1, 16, 'win_band', uv=(16, 57.6, 0.2, 0.1), mtop='terrace')
    mb.box(x, y, 15.5, w * 1.4 + 0.6, w * 1.1 + 0.6, 0.5, 'neon_amber', top=False)
    z = 16
    for (s, hh) in ((1.0, 0.45), (0.78, 0.3), (0.56, 0.25)):
        hh *= h - 16
        mb.box(x, y, z, w * s, w * s * 0.8, hh, 'win_curtain', uv=(24, 24, 0.3 * s, z / 24.0), mtop='graphite_dark')
        mb.box(x, y, z + hh - 0.3, w * s + 0.5, w * s * 0.8 + 0.5, 0.45, 'neon_cyan', top=False)
        z += hh
    # lantern crown: four corner posts + glowing core
    for (ax, ay) in ((1, 1), (1, -1), (-1, 1), (-1, -1)):
        mb.box(x + ax * w * 0.2, y + ay * w * 0.16, z, 0.8, 0.8, 12, 'graphite')
    mb.box(x, y, z + 1, w * 0.3, w * 0.24, 10, 'int_panel')
    mb.box(x, y, z + 12, w * 0.5, w * 0.4, 0.8, 'neon_cyan')
    mb.cyl(x, y, z + 12.8, 0.4, 30, 'metal_light', seg=4, r2=0.08)
    return z + 44

def lm_cyl(mb, x, y, rng, h=250, r=15):
    mb.cyl(x, y, 0, r + 4, 12, 'win_band', seg=18, uv=(16, 57.6, 0.0, 0.0), mtop='terrace')
    mb.cyl(x, y, 0, r, h, 'win_curtain', seg=18, uv=(24, 24, 0.3, 0.1), mtop='graphite_dark')
    for k in range(7):
        z = 28 + k * (h - 44) / 6
        mb.cyl(x, y, z, r + 0.9, 0.9, 'neon_violet' if k in (2, 5) else 'neon_cyan', seg=18, top=False)
        if k % 2 == 0:
            mb.cyl(x, y, z - 0.5, r + 2.2, 0.5, 'terrace', seg=18, mtop='foliage_b')
    mb.cyl(x, y, h, r * 0.75, 16, 'graphite', seg=18, r2=r * 0.35)
    mb.cyl(x, y, h + 16, 0.4, 36, 'metal_light', seg=4, r2=0.1)
    mb.box(x, y, h + 52, 0.9, 0.9, 0.9, 'neon_amber')
    return h + 53


def lm_crescent(mb, x, y, rng, h=220, R=46, arc=150, thick=16, rot=0.0, win='win_far_fins'):
    """V3 curved landmark: a crescent-plan tower (concave inner face), stepped crown blade"""
    n = 14
    a0 = math.radians(rot - arc / 2)
    da = math.radians(arc) / n
    tw, th = TILE[win]
    r0, r1 = R - thick / 2, R + thick / 2
    def P(r, a, z): return (x + r * math.cos(a), y + r * math.sin(a), z)
    zt = h
    for i in range(n):
        a, b = a0 + i * da, a0 + (i + 1) * da
        u0, u1 = (r1 * a) / tw, (r1 * b) / tw
        mb.quad(P(r1, a, 0), P(r1, b, 0), P(r1, b, h), P(r1, a, h), win, uvs=[(u0, 0), (u1, 0), (u1, h / th), (u0, h / th)])
        mb.quad(P(r0, b, 0), P(r0, a, 0), P(r0, a, h), P(r0, b, h), 'win_far_curtain', uvs=[(u1, 0), (u0, 0), (u0, h / 24), (u1, h / 24)])
        mb.quad(P(r0, a, h), P(r0, b, h), P(r1, b, h), P(r1, a, h), 'graphite_dark')
    for a in (a0, a0 + n * da):
        mb.quad(P(r0, a, 0), P(r1, a, 0), P(r1, a, h), P(r0, a, h), 'graphite_dark')
    # stepped crown blade + hairline cyan crown on the outer edge
    for k in range(1, 4):
        zz = h * (0.55 + 0.14 * k)
        ar = a0 + (n * da) * (0.5 + (0.12 * k))
    mb.cyl(x + R * math.cos(math.radians(rot)), y + R * math.sin(math.radians(rot)), h, 0.5, h * 0.18, 'metal_light', seg=4, r2=0.1)
    ring_a = a0
    for i in range(n):
        a, b = a0 + i * da, a0 + (i + 1) * da
        mb.quad(P(r1 + 0.05, a, h - 0.9), P(r1 + 0.05, b, h - 0.9), P(r1 + 0.05, b, h - 0.5), P(r1 + 0.05, a, h - 0.5), 'neon_cyan')
    return h

def lm_needle(mb, x, y, rng, h=300, w=12):
    """V3 slender landmark: tapered needle with an observation pod and a lit spire"""
    mb.box(x, y, 0, w * 1.8, w * 1.8, 10, 'win_far_band', uv=(16, 57.6, 0.1, 0.1), mtop='graphite_dark')
    mb.frustum(x, y, 10, w, w, w * 0.45, w * 0.45, h * 0.72, 'win_far_fins', mtop='graphite_dark', uv=(24, 24, 0.1, 0.0))
    z = 10 + h * 0.72
    mb.cyl(x, y, z - 6, w * 0.95, 5, 'graphite', seg=14, r2=w * 1.1)
    mb.cyl(x, y, z - 1, w * 1.1, 1.2, 'neon_cyan', seg=14, top=True)
    mb.cyl(x, y, z, w * 0.5, 4, 'graphite', seg=10, r2=w * 0.3)
    mb.cyl(x, y, z + 4, 0.5, h * 0.22, 'metal_light', seg=4, r2=0.1)
    mb.box(x, y, z + 4 + h * 0.22, 0.8, 0.8, 0.8, 'neon_amber')
    return z + h * 0.22
