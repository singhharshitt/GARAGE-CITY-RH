import bpy, json, os, math
OUT = os.path.dirname(bpy.data.filepath)
I = {}
for n in ('CAM_Game_Perspective', 'CAM_Game_Isometric_Ortho', 'CAM_Preview_Skyline', 'CAM_V3_Hero_Skyline', 'CAM_V3_Close_Detail'):
    o = bpy.data.objects[n]; d = o.data
    fwd = o.matrix_world.to_quaternion() @ __import__('mathutils').Vector((0, 0, -1))
    I[n] = dict(type=d.type, loc=[round(v, 2) for v in o.location], rot_deg=[round(math.degrees(v), 2) for v in o.rotation_euler], lens=round(d.lens, 3), sensor=d.sensor_width,
                hfov_deg=round(math.degrees(d.angle_x), 2) if d.type == 'PERSP' else None, ortho_scale=d.ortho_scale if d.type == 'ORTHO' else None,
                clip=[d.clip_start, d.clip_end], forward=[round(v, 4) for v in fwd], shift_y=d.shift_y)
I['lights'] = {o.name: dict(energy=o.data.energy, color=[round(c, 3) for c in o.data.color], rot_deg=[round(math.degrees(v), 1) for v in o.rotation_euler]) for o in bpy.data.objects if o.type == 'LIGHT'}
I['materials'] = sorted(m.name for m in bpy.data.materials)
I['images'] = {i.name: list(i.size) for i in bpy.data.images if i.name != 'Render Result'}
cols = {}
def walk(c, d=0):
    objs = [o for o in c.objects]
    tris = 0
    for o in c.all_objects:
        if o.type == 'MESH': tris += sum(len(p.vertices) - 2 for p in o.data.polygons)
    cols[c.name] = dict(depth=d, objects=len(c.all_objects), tris=tris)
    for ch in c.children: walk(ch, d + 1)
walk(bpy.context.scene.collection.children[0])
I['collections'] = cols
meshes = [o for o in bpy.data.objects if o.type == 'MESH']
I['mesh_objects'] = len(meshes); I['unique_meshes'] = len({o.data.name for o in meshes}); I['total_tris_rendered'] = sum(sum(len(p.vertices) - 2 for p in o.data.polygons) for o in meshes)
I['linked_duplicate_objects'] = len(meshes) - len({o.data.name for o in meshes})
json.dump(I, open(os.path.join(OUT, 'scene_info.json'), 'w'), indent=1)
