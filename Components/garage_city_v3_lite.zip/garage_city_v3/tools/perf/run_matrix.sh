#!/usr/bin/env bash
# Repeatable software-rendering (SwiftShader) perf matrix. Run from garage_city_v3 root. Sequential on purpose (CPU-bound).
# Output: perf_results/*.json  (consolidated by tools/perf/summarize.mjs -> perf_results.json + perf_report.md)
set -u
cd "$(dirname "$0")/../.."
P="node tools/perf/perf_run.mjs"
V2=v2/garage_city_environment.glb
V3C=v3/garage_city_environment.glb
V3O=v3/optimized/garage_city_environment.opt.glb
V3K=v3/optimized/garage_city_environment.opt.ktx2.glb
V3D=v3/optimized/garage_city_environment.opt.draco.glb
mkdir -p perf_results
# 1) load-only check of every variant in the browser (frames=1)
for v in V2 V3C V3O V3K V3D; do eval g=\$$v; $P --glb $g --frames 1 --mode balanced --shot perf_results/load_$v.png --out perf_results/load_$v.json >/dev/null 2>&1; done
# 2) identical-conditions baseline: quality 0 (1 hemi+1 dir, no shadows, no LOD, no tone mapping), N frames
for res in "1280 720" "800 450"; do set -- $res
  for v in V2 V3C V3O V3K V3D; do eval g=\$$v; $P --glb $g --quality 0 --w $1 --h $2 --frames 30 --out perf_results/q0_${v}_$1.json >/dev/null 2>&1; done
done
# 3) shipped quality modes, V2 vs V3 optimized (same code path/regexes applied to both)
for res in "1280 720" "800 450"; do set -- $res
  for m in full balanced low; do
    n=30; [ $m = full ] && n=12
    for v in V2 V3O; do eval g=\$$v; $P --glb $g --mode $m --w $1 --h $2 --frames $n --out perf_results/mode_${m}_${v}_$1.json >/dev/null 2>&1; done
  done
done
echo MATRIX_DONE
