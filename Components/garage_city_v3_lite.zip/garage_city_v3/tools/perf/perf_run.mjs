// node tools/perf/perf_run.mjs --glb v3/garage_city_environment.glb [--mode full|balanced|low] [--w 1280 --h 720 --frames 60] [--cam NAME] [--quality 0] [--shot out.png] [--out result.json]
// Serves: /v3 -> garage_city_v3, /v2 -> garage_city_v2, /three -> three package, /web, /tools.  SOFTWARE (SwiftShader) WebGL in headless Chrome.
import http from 'http'; import fs from 'fs'; import path from 'path'; import puppeteer from 'puppeteer-core';
const a = Object.fromEntries(process.argv.slice(2).reduce((acc, v, i, arr) => { if (v.startsWith('--')) acc.push([v.slice(2), (arr[i + 1] && !arr[i + 1].startsWith('--')) ? arr[i + 1] : '1']); return acc; }, []));
const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '../..');
const MAP = { '/v3': ROOT, '/v2': process.env.V2_DIR || path.resolve(ROOT, '../garage_city_v2'), '/three': path.join(ROOT, 'tools/node_modules/three'),
  '/web': path.join(ROOT, 'web'), '/tools': path.join(ROOT, 'tools') };
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.wasm': 'application/wasm', '.glb': 'model/gltf-binary', '.png': 'image/png', '.json': 'application/json', '.ktx2': 'image/ktx2' };
const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]); const k = Object.keys(MAP).find(p => u === p || u.startsWith(p + '/'));
  if (!k) { res.writeHead(404); return res.end(); }
  const f = path.join(MAP[k], u.slice(k.length)); if (!f.startsWith(MAP[k]) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-store' }); fs.createReadStream(f).pipe(res);
});
await new Promise(r => server.listen(0, '127.0.0.1', r)); const port = server.address().port;
const browser = await puppeteer.launch({ executablePath: process.env.CHROME || '/usr/bin/google-chrome', headless: 'new',
  args: ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--enable-precise-memory-info', '--js-flags=--expose-gc'] });
const page = await browser.newPage(); page.on('pageerror', e => console.error('pageerror', e.message));
page.on('console', m => { if (m.type() === 'error') console.error('console.error', m.text()); });
const W = +(a.w || 1280), H = +(a.h || 720);
await page.setViewport({ width: W, height: H });
const qs = new URLSearchParams({ glb: a.glb.split(',').map(g => '/' + g.replace(/^\//, '')).join(','), mode: a.mode || 'full', w: W, h: H, frames: a.frames || 60, cam: a.cam || 'CAM_Game_Perspective', quality: a.quality ?? '1', shot: a.shot ? '1' : '0' });
if (a.exposure) qs.set('exposure', a.exposure);
const t0 = Date.now();
await page.goto(`http://127.0.0.1:${port}/tools/perf/perf.html?${qs}`);
await page.waitForFunction('window.__result', { timeout: 600000 });
const r = await page.evaluate('window.__result'); r.wall_s = (Date.now() - t0) / 1000;
r.software_rendering_note = 'SwiftShader (CPU) WebGL in headless Chrome on a ' + (await import('os')).cpus().length + '-core box: relative numbers only, NOT real-device FPS';
if (a.shot) await page.screenshot({ path: a.shot, clip: { x: 0, y: 0, width: W, height: H } });
if (a.out) fs.writeFileSync(a.out, JSON.stringify(r, null, 1)); console.log(JSON.stringify(r, null, 1));
await browser.close(); server.close();
