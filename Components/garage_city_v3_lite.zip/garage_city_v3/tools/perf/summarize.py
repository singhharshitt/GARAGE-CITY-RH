"""python3 tools/perf/summarize.py  -> perf_results.json + perf_report.md  (from perf_results/*.json written by run_matrix.sh)"""
import json, glob, os
D = os.path.abspath(os.path.join(os.path.dirname(__file__), '../..'))
R = {}
for f in sorted(glob.glob(f'{D}/perf_results/*.json')):
    R[os.path.basename(f)[:-5]] = json.load(open(f))
NAME = {'V1': 'V1 combined GLB', 'V2': 'V2 combined GLB', 'V3C': 'V3 compat combined GLB', 'V3O': 'V3 optimized (instancing+meshopt)', 'V3K': 'V3 optimized + KTX2', 'V3D': 'V3 optimized + Draco'}
rows = []
def row(key, label, res, mode):
    r = R.get(key)
    if not r: return None
    fm = r.get('frame_ms') or {}; ri = r.get('renderer_info') or {}
    return {'key': key, 'config': label, 'resolution': res, 'mode': mode, 'glb_mb': round(r['glb_bytes'] / 1048576, 2), 'download_ms': r['download_ms'], 'parse_ms': r['parse_incl_textures_ms'],
            'heap_delta_load_mb': r['js_heap_delta_load_mb'], 'first_render_ms': r['first_render_ms'], 'draw_calls': ri.get('draw_calls'), 'triangles': ri.get('triangles'),
            'geometries': ri.get('geometries'), 'textures': ri.get('textures'), 'frame_ms_median': fm.get('median'), 'frame_ms_p95': fm.get('p95'), 'frames': r['frames'], 'errors': r['errors']}
loads = [row(f'load_{v}', NAME[v], '1280x720', 'balanced(1 frame)') for v in NAME]
q0 = [row(f'q0_{v}_{w}', NAME[v], f'{w}x{h}', 'quality 0 (hemi+sun, no shadow/LOD/tonemap)') for w, h in ((1280, 720), (800, 450)) for v in NAME]
modes = [row(f'mode_{m}_{v}_{w}', NAME[v], f'{w}x{h}', m) for w, h in ((1280, 720), (800, 450)) for m in ('full', 'balanced', 'low') for v in ('V2', 'V3O')]
out = {'note': 'SOFTWARE rendering (SwiftShader/ANGLE CPU WebGL, headless Chrome). Relative comparisons only. Real-device FPS (30 min / 60 target) is UNVERIFIED.',
       'load_check': [r for r in loads if r], 'baseline_quality0': [r for r in q0 if r], 'quality_modes': [r for r in modes if r]}
json.dump(out, open(f'{D}/perf_results.json', 'w'), indent=1)
def tbl(rs, cols):
    s = '| ' + ' | '.join(c[0] for c in cols) + ' |\n|' + '|'.join('---' for _ in cols) + '|\n'
    for r in rs: s += '| ' + ' | '.join(str(r[c[1]]) for c in cols) + ' |\n'
    return s
C = [('config', 'config'), ('res', 'resolution'), ('mode', 'mode'), ('GLB MB', 'glb_mb'), ('download ms', 'download_ms'), ('parse+tex ms', 'parse_ms'), ('heap Δ MB', 'heap_delta_load_mb'), ('draw calls', 'draw_calls'), ('tris', 'triangles'),
     ('geoms', 'geometries'), ('tex', 'textures'), ('frame median ms', 'frame_ms_median'), ('p95 ms', 'frame_ms_p95'), ('N', 'frames')]
md = ['# Performance results (SOFTWARE rendering only)\n', out['note'] + '\n',
      'Harness: `tools/perf/perf_run.mjs` + `perf.html` (puppeteer-core, headless Chrome with `--use-angle=swiftshader`), static local server, three r169, gameplay camera `CAM_Game_Perspective`, GLB loaded via GLTFLoader (+Meshopt/Draco/KTX2 loaders as needed). Frame time = `renderer.render` + a 1-pixel `readPixels` sync, after 5 warm-up frames. `renderer.info` values are for the last rendered frame (they include the shadow pass when shadows are on). Download is from localhost (not a network measurement). V2 and V3 run under the same harness, machine and settings; one run per row (no repeats), so differences of a few % are noise.\n',
      '## A. Load check of every variant in the browser (1 frame, balanced mode)\n', tbl([r for r in loads if r], C),
      '## B. Same-conditions baseline: quality 0 (one hemisphere + one directional light, no shadows, no LOD, no tone mapping)\n', tbl([r for r in q0 if r], C),
      '## C. Shipped quality modes, V2 file vs V3 optimized file (same quality_modes.js applied to both)\n', tbl([r for r in modes if r], C)]
open(f'{D}/perf_report.md', 'w').write('\n'.join(md)); print('ok', len(out['load_check']), len(out['baseline_quality0']), len(out['quality_modes']))
