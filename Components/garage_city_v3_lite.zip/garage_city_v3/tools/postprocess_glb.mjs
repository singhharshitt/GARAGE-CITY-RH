// Garage City V3 GLB post-processing (node):  node tools/postprocess_glb.mjs <v3 dir>
//  1. compat   : <dir>/<name>.glb            -> COLOR_0 repacked to normalized uint8 (core glTF only, NO extensions added), dedup/prune
//  2. optimized: <dir>/optimized/<name>.opt.glb       -> EXT_mesh_gpu_instancing (props/vegetation/lights) + KHR_mesh_quantization + EXT_meshopt_compression
//  3. ktx2     : <dir>/optimized/<name>.opt.ktx2.glb  -> same + KHR_texture_basisu (UASTC+zstd, mipmapped) via toktx
//  4. draco    : <dir>/optimized/garage_city_environment.opt.draco.glb -> instancing + KHR_draco_mesh_compression (PNG textures)
import { NodeIO, Document, MathUtils } from '@gltf-transform/core';
import { ALL_EXTENSIONS, EXTMeshGPUInstancing, KHRTextureBasisu } from '@gltf-transform/extensions';
import { dedup, prune, quantize, meshopt, reorder, weld, flatten } from '@gltf-transform/functions';
import { MeshoptEncoder, MeshoptDecoder } from 'meshoptimizer';
import draco3d from 'draco3dgltf';
import fs from 'fs'; import path from 'path'; import { execFileSync } from 'child_process'; import os from 'os';

const DIR = path.resolve(process.argv[2] || '.');
const NAMES = ['garage_city_environment', 'garage_core', 'roads_and_highways', 'city_background', 'waterfront'];
const TOKTX = process.env.TOKTX || '/workspace/tools/ktx/bin/toktx';
const KTXLIB = process.env.KTX_LIB || '/workspace/tools/ktx/lib';
const CELL = 200;           // m, spatial cell for instance batches (frustum culling granularity)
await MeshoptEncoder.ready; await MeshoptDecoder.ready;
const io = new NodeIO().registerExtensions(ALL_EXTENSIONS).registerDependencies({
  'meshopt.encoder': MeshoptEncoder, 'meshopt.decoder': MeshoptDecoder,
  'draco3d.encoder': await draco3d.createEncoderModule(), 'draco3d.decoder': await draco3d.createDecoderModule() });

function colorToU8(doc) {
  for (const mesh of doc.getRoot().listMeshes()) for (const prim of mesh.listPrimitives()) {
    const a = prim.getAttribute('COLOR_0'); if (!a || a.getComponentType() === 5121) continue;
    const n = a.getCount(), src = a.getArray(), w = a.getElementSize(), out = new Uint8Array(n * 4);
    const f = a.getComponentType() === 5126 ? 255 : (a.getComponentType() === 5123 ? 255 / 65535 : 1);
    for (let i = 0; i < n; i++) { for (let k = 0; k < 3; k++) out[i * 4 + k] = Math.round(Math.min(1, Math.max(0, src[i * w + k] * (a.getComponentType() === 5126 ? 1 : 1))) * (a.getComponentType() === 5126 ? 255 : 255 / (a.getComponentType() === 5123 ? 65535 : 255) * (a.getComponentType() === 5123 ? 65535 : 255) / (a.getComponentType() === 5123 ? 65535 : 255) * 1)); out[i * 4 + 3] = w === 4 ? Math.round((a.getComponentType() === 5126 ? src[i * w + 3] * 255 : src[i * w + 3] / 65535 * 255)) : 255; }
    a.setType('VEC4').setNormalized(true).setArray(out);
  }
}
// NOTE for uint16-normalized sources the simple path below is used instead (rare: only a few glow decals)
function colorToU8Simple(doc) {
  for (const mesh of doc.getRoot().listMeshes()) for (const prim of mesh.listPrimitives()) {
    const a = prim.getAttribute('COLOR_0'); if (!a || a.getComponentType() === 5121) continue;
    const n = a.getCount(), w = a.getElementSize(), out = new Uint8Array(n * 4), v = [0, 0, 0, 1];
    for (let i = 0; i < n; i++) { a.getElement(i, v); for (let k = 0; k < 4; k++) out[i * 4 + k] = Math.round(Math.min(1, Math.max(0, w === 3 && k === 3 ? 1 : v[k])) * 255); }
    a.setType('VEC4').setNormalized(true).setArray(out);
  }
}

function instance(doc) {
  const root = doc.getRoot(), ext = doc.createExtension(EXTMeshGPUInstancing).setRequired(true);
  const byMesh = new Map();
  for (const node of root.listNodes()) { const m = node.getMesh(); if (m && !node.getSkin()) { if (!byMesh.has(m)) byMesh.set(m, []); byMesh.get(m).push(node); } }
  const scene = root.listScenes()[0]; let made = 0, removed = 0, kept = 0;
  for (const [mesh, nodes] of byMesh) {
    if (nodes.length < 2) { kept += nodes.length; continue; }
    const cells = new Map();
    for (const nd of nodes) { const t = nd.getWorldTranslation(); const k = Math.floor(t[0] / CELL) + '_' + Math.floor(t[2] / CELL); if (!cells.has(k)) cells.set(k, []); cells.get(k).push(nd); }
    for (const [k, list] of cells) {
      if (list.length < 2) { kept += list.length; continue; }
      const T = new Float32Array(list.length * 3), R = new Float32Array(list.length * 4), S = new Float32Array(list.length * 3);
      list.forEach((nd, i) => { const t = [0, 0, 0], r = [0, 0, 0, 1], s = [1, 1, 1]; MathUtils.decompose(nd.getWorldMatrix(), t, r, s); T.set(t, i * 3); R.set(r, i * 4); S.set(s, i * 3); });
      const buf = root.listBuffers()[0];
      const acc = (arr, type) => doc.createAccessor().setType(type).setArray(arr).setBuffer(buf);
      const batch = ext.createInstancedMesh().setAttribute('TRANSLATION', acc(T, 'VEC3')).setAttribute('ROTATION', acc(R, 'VEC4')).setAttribute('SCALE', acc(S, 'VEC3'));
      const inst = doc.createNode('Inst_' + (mesh.getName() || 'mesh') + '_' + k).setMesh(mesh).setExtension('EXT_mesh_gpu_instancing', batch);
      inst.setExtras({ instance_count: list.length, cell_m: CELL });
      scene.addChild(inst); made++; removed += list.length;
      for (const nd of list) nd.dispose();
    }
  }
  return { instanced_nodes: made, source_nodes_replaced: removed, single_nodes_kept: kept };
}

function toKTX2(doc) {
  const ext = doc.createExtension(KHRTextureBasisu).setRequired(true);
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ktx-')); let n = 0, before = 0, after = 0;
  // colour-space: textures used as baseColor/emissive are sRGB, everything else linear
  const srgb = new Set();
  for (const m of doc.getRoot().listMaterials()) { for (const t of [m.getBaseColorTexture(), m.getEmissiveTexture()]) if (t) srgb.add(t); }
  for (const tex of doc.getRoot().listTextures()) {
    if (tex.getMimeType() !== 'image/png') continue;
    const inp = path.join(tmp, 't' + n + '.png'), outp = path.join(tmp, 't' + n + '.ktx2'); n++;
    fs.writeFileSync(inp, tex.getImage()); before += tex.getImage().length;
    const args = ['--t2', '--encode', 'uastc', '--uastc_quality', '2', '--zcmp', '19', '--genmipmap', '--assign_oetf', srgb.has(tex) ? 'srgb' : 'linear', '--assign_primaries', 'bt709', outp, inp];
    execFileSync(TOKTX, args, { env: { ...process.env, LD_LIBRARY_PATH: KTXLIB }, stdio: 'pipe' });
    const kb = fs.readFileSync(outp); after += kb.length;
    tex.setImage(new Uint8Array(kb)).setMimeType('image/ktx2');
  }
  fs.rmSync(tmp, { recursive: true, force: true });
  return { textures: n, png_bytes: before, ktx2_bytes: after };
}

const report = { generated_by: 'tools/postprocess_glb.mjs', cell_m: CELL, files: {} };
fs.mkdirSync(path.join(DIR, 'optimized'), { recursive: true });
for (const name of NAMES) {
  const rep = {};
  const compatPath = path.join(DIR, name + '.glb'), instPath = path.join(DIR, 'build_inst', name + '.glb');
  // 1) compat (no extensions)
  { const doc = await io.read(compatPath); colorToU8Simple(doc); await doc.transform(dedup(), prune({ keepLeaves: true, keepExtras: true }));
    await io.write(compatPath, doc); rep.compat = { path: name + '.glb', bytes: fs.statSync(compatPath).size }; }
  // 2) optimized: quantize first (shared meshes get node-level dequantization), then instance, then meshopt
  const mk = async () => { const doc = await io.read(instPath); colorToU8Simple(doc); await doc.transform(dedup(), prune({ keepLeaves: true, keepExtras: true }));
    return doc; };
  const tail = async (doc, mode) => {
    await doc.transform(quantize({ quantizePosition: 16, quantizeNormal: 10, quantizeTexcoord: 14, quantizeColor: 8, quantizeWeight: 8, quantizeGeneric: 12 }));
    rep.instancing = instance(doc);
    await doc.transform(prune({ keepLeaves: true, keepExtras: true }));
    if (mode === 'meshopt') await doc.transform(reorder({ encoder: MeshoptEncoder }), meshopt({ encoder: MeshoptEncoder, level: 'medium' }));
  };
  { const doc = await mk(); await tail(doc, 'meshopt'); const p = path.join(DIR, 'optimized', name + '.opt.glb'); await io.write(p, doc);
    rep.optimized = { path: 'optimized/' + name + '.opt.glb', bytes: fs.statSync(p).size, extensions: doc.getRoot().listExtensionsUsed().map(e => e.extensionName) };
    if (name !== 'waterfront' || true) { const k = toKTX2(doc); rep.ktx2_textures = k;
      const p2 = path.join(DIR, 'optimized', name + '.opt.ktx2.glb'); await io.write(p2, doc);
      rep.optimized_ktx2 = { path: 'optimized/' + name + '.opt.ktx2.glb', bytes: fs.statSync(p2).size, extensions: doc.getRoot().listExtensionsUsed().map(e => e.extensionName) }; } }
  // 3) draco variant (combined only)
  if (name === 'garage_city_environment') {
    const doc = await mk(); instance(doc); await doc.transform(prune({ keepLeaves: true, keepExtras: true }));
    const { draco } = await import('@gltf-transform/functions');
    await doc.transform(draco({ method: 'edgebreaker', quantizePosition: 16, quantizeNormal: 10, quantizeTexcoord: 14, quantizeColor: 8 }));
    const p = path.join(DIR, 'optimized', name + '.opt.draco.glb'); await io.write(p, doc);
    rep.optimized_draco = { path: 'optimized/' + name + '.opt.draco.glb', bytes: fs.statSync(p).size, extensions: doc.getRoot().listExtensionsUsed().map(e => e.extensionName) };
  }
  report.files[name] = rep; console.log(name, JSON.stringify(rep));
}
fs.writeFileSync(path.join(DIR, 'optimization_report.json'), JSON.stringify(report, null, 1));
