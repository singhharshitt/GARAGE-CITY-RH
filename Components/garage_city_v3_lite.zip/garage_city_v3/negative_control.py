# Opens the .blend, injects a cube into SLOT_bay_01's envelope AND a tall wall between SLOT_bay_05 and the game camera, saves to /tmp, then validate_blend.py must flag it.
import bpy, bmesh, os
from mathutils import Vector
sl = bpy.data.objects['SLOT_bay_01']
bpy.ops.mesh.primitive_cube_add(size=1.0, location=sl.matrix_world.translation + Vector((0,0,0.9)))
c = bpy.context.object; c.name='NEGCTRL_cube'; c.scale=(1.5,1.5,1.2)
s5 = bpy.data.objects['SLOT_bay_05'].matrix_world.translation; cam = bpy.data.objects['CAM_Game_Perspective'].matrix_world.translation
p = s5 + (cam - s5).normalized()*3.0
bpy.ops.mesh.primitive_cube_add(size=1.0, location=(p.x,p.y,s5.z+3)); w=bpy.context.object; w.name='NEGCTRL_wall'; w.scale=(6,6,6)
bpy.ops.wm.save_as_mainfile(filepath='/tmp/negctrl/garage_neg.blend')
