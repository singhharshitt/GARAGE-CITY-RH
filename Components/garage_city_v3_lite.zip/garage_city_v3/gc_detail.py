"""V2 environmental detail pass: workshop aprons, floor drains/grates, safety markings, fuel + EV station dressing,
loading-area props, benches, signs, planters, lights.  Everything placed on open ground is filtered with free_xy()
against the slot keep-clear footprints, so parking / lift / fuel / EV / display placement areas stay uncluttered."""
from gc_arch import *
from gc_arch import _c
from gc_buildings import railing2, planter_box

def _safe(x, y, sx=1.2, sy=1.2, margin=1.2):
    return free_xy(x, y, sx, sy, margin)

def build_detail(C, rng):
    cd, cw, cf, cc = C['Details'], C['Workshops_Lifts'], C['Fuel_EV'], C['Circulation']
    # ------------------------------------------------------------------------------------ workshop aprons (outside, between doors)
    mb = MB()
    # E1 west wall (x ~57.1): items in the gaps between service doors + along lounge / dock frontage
    e1_gaps = [-17.1, -10.8, -4.4, 2.0]
    kinds = ['cab', 'shelf', 'tires', 'cart']
    for i, y in enumerate(e1_gaps):
        k = kinds[i % 4]
        if k == 'cab': tool_cabinet(mb, 57.0, y, 90, h=1.3)
        elif k == 'shelf': shelf_unit(mb, 57.1, y, 90, L=1.6, levels=3, hgt=2.0)
        elif k == 'tires': tire_rack(mb, 57.0, y, 90, rows=2)
        else: tool_cart(mb, 56.9, y, 90)
    for y in (9.0, 11.5):
        tool_cabinet(mb, 57.0, y, 90, h=1.3) if y == 9.0 else terminal(mb, 57.0, y, 90)
    for y in (20.5, 22.5):
        bench(mb, 56.9, y, 90)
    # N2 front (y ~36.7): gaps between roll-up doors
    for x, k in ((10.4, 'bench'), (19.2, 'cab'), (25.6, 'cab'), (32.0, 'cab'), (41.2, 'tires'), (43.5, 'shelf'), (53, 'cart'), (55, 'tires'), (58, 'shelf'), (61, 'cab'), (64, 'cart'), (67, 'cab')):
        if k == 'bench': bench(mb, x, 36.7, 0, 2.2)
        elif k == 'cab': tool_cabinet(mb, x, 36.8, 0, h=1.3)
        elif k == 'tires': tire_rack(mb, x, 36.7, 0, rows=2)
        elif k == 'shelf': shelf_unit(mb, x, 36.9, 0, L=1.6, levels=3, hgt=2.0)
        else: tool_cart(mb, x, 36.7, 0)
    for x in (53.5, 62.5):
        compressor(mb, x, 36.6, 0)
    for (x, y) in ((56.2, 37.0), (68.6, 36.3)):
        drum(mb, x, y)
    mb.finish("Equip_Workshop_Aprons", cw)

    # ------------------------------------------------------------------------------------ hazard / safety markings (flat decals)
    mb = MB()
    def hz(x0, y0, x1, y1, z=0.052):
        gq(mb, x0, y0, x1, y1, z, 'hazard')
    # threshold bands in front of every N2 / E1 / D1 door
    for (ux, w_) in [(4, 6.0), (16, 4.4), (22.4, 4.4), (28.8, 4.4), (35.2, 4.4), (48, 6.0)]:
        hz(ux - w_ / 2, 35.6, ux + w_ / 2, 36.0)
    for (uy, w_) in [(-20.5, 5.0), (-14, 4.4), (-7.6, 4.4), (-1.2, 4.4), (5.2, 4.4)]:
        hz(56.0, uy - w_ / 2, 56.4, uy + w_ / 2)
    for ux in (26.5, 31.5):
        hz(ux - 2.2, 4.8, ux + 2.2, 5.2)
    # loading-dock edge, ramp edges, stair noses
    hz(54.2, 24.6, 54.6, 37.4); hz(-33.6, 6.2, -23.4, 6.5, 1.03) if False else None
    # pedestrian crossing in front of the gate and across the main lane
    for k in range(-5, 6):
        gq(mb, 6 + k * 1.1 - 0.3, -35.0, 6 + k * 1.1 + 0.3, -32.6, 0.05, 'mark_white') if _safe(6 + k * 1.1, -33.8, 0.6, 2.4, 0.2) else None
    for k in range(-4, 5):
        gq(mb, -3.2, 3.0 + k * 1.1 - 0.3, -0.8, 3.0 + k * 1.1 + 0.3, 0.05, 'mark_white') if _safe(-2, 3.0 + k * 1.1, 2.4, 0.6, 0.2) else None
    # floor drains + trench grates (flat, under the 15 cm floor tolerance)
    for ux in (16, 22.4, 28.8, 35.2):
        trench_grate(mb, ux - 1.6, 34.2, ux + 1.6, 34.7)
    for uy in (-14, -7.6, -1.2, 5.2):
        trench_grate(mb, 52.0, uy - 1.6, 52.5, uy + 1.6)
    for x in (-60, -50, -40, -30):
        trench_grate(mb, x - 1.5, -24.6, x + 1.5, -24.15) if _safe(x, -24.4, 3.0, 0.5, 0.3) else None
    for (x, y) in [(-1, -20), (12, -12), (6, 6), (-14, 6), (14, -34), (-34, -14), (30, -22), (44, 22), (-8, 28), (-42, 10), (62, 18), (-20, -47), (20, -47)]:
        if _safe(x, y, 0.8, 0.8, 0.3): drain(mb, x, y)
    # manhole / tank covers at the fuel station
    for x in (-33, -26, -19, -12):
        mb.ring_flat(x, -39.7 if False else -41.2, 0.05, 0.0, 0.55, 'graphite_dark', seg=10) if _safe(x, -41.2, 1.1, 1.1, 0.2) else None
    # directional arrows along the main lane
    for (x, y, rot) in ((-20, -24.5, 0), (10, 0, 90), (-6, 21, 0), (36, 21, 0), (54, -36, 0)):
        c, s = _c(rot)
        def R(a, b): return (x + a * c - b * s, y + a * s + b * c, 0.052)
        mb.quad(R(-0.35, -1.6), R(0.35, -1.6), R(0.35, 0.3), R(-0.35, 0.3), 'mark_white')
        mb.tri(R(-1.0, 0.3), R(1.0, 0.3), R(0, 1.9), 'mark_white')
    mb.finish("Floor_Safety_Drains", cd)

    # ------------------------------------------------------------------------------------ yard furniture & signage
    mb = MB()
    # blank service terminals + benches around the central plaza and entrance
    for (x, y, r) in ((-2.0, -29.4, 0), (14, -29.4, 0), (23, 18.5, 90), (-14.5, 14.5, 0), (50.5, 14.0, 90), (-5.5, 24.5, 0)):
        if _safe(x, y, 0.8, 0.8, 1.2): terminal(mb, x, y, r)
    for (x, y, r) in ((-18, 27.4, 0), (-4, 27.4, 0), (3, 27.4, 0), (16, -29.2, 0), (-8.0, -26.8, 0), (-54.5, 28.5, 0)):
        if _safe(x, y, 2.0, 0.6, 1.2): bench(mb, x, y, r, 2.0)
    # blank wayfinding boards (no text): post + dark panel with a plain cyan stripe
    for (x, y, r) in ((-1.5, -46.8, 0), (13.5, -46.8, 0), (2, 26.5, 0), (-44, 28.6, 0), (-58.5, -26.5, 90), (53, 38 - 3.0, 0)):
        if _safe(x, y, 1.6, 0.3, 1.0):
            mb.box(x, y, 0, 0.12, 0.12, 2.6, 'graphite_dark', rot=r)
            mb.box(x, y, 1.7, 1.5, 0.08, 0.9, 'polymer', rot=r)
            mb.box(x, y - 0.05, 2.35, 1.4, 0.03, 0.08, 'neon_cyan', rot=r)
    # cable reels / pallets / crates in the loading zone and by W2
    for (x, y) in ((-60, 5.0), (-62.4, 5.4), (-55.8, 6.0)):
        mb.cyl(x, y, 0.0, 0.7, 0.9, 'cabinet_orange', seg=8, top=True); mb.cyl(x, y, 0.45, 0.2, 0.46, 'graphite_dark', seg=6)
    for (x, y) in ((-60.5, 3.6), (-57.0, 3.9)):
        for k in range(3):
            mb.box(x, y, k * 0.55, 1.1, 1.1, 0.5, 'cabinet_blue' if k % 2 else 'steel_painted')
    mb.finish("Yard_Props_Terminals_Benches", cd)

    # ------------------------------------------------------------------------------------ loading platform dressing (V1 platform top z=1.0)
    mb = MB()
    for (x, y) in ((-26.5, 9.0), (-26.5, 11.6), (-29.8, 10.5), (-24.8, 13.8)):
        mb.box(x, y, 1.0, 1.2, 1.0, 0.14, 'concrete'); mb.box(x, y, 1.14, 1.05, 0.9, 0.55, 'cabinet_orange' if int(x * 3 + y) % 2 else 'cabinet_blue')
    mb.box(-33.0, 11, 1.0, 0.3, 8.0, 0.15, 'hazard')
    for k in range(3):
        mb.box(-24.2 - 0.0, 8.0 + k * 3.0, 1.0, 0.4, 0.4, 1.6, 'graphite_dark'); mb.box(-24.2, 8.0 + k * 3.0, 2.6, 0.5, 0.5, 0.08, 'neon_amber')
    mb.finish("Loading_Platform_Props", cc)

    # ------------------------------------------------------------------------------------ FUEL STATION dressing
    mb = MB()
    for p in (-31, -21, -11):
        for sx_ in (-0.35, 0.35):
            # hoses + nozzle holsters (north face away from the camera is irrelevant; kept small)
            mb.box(p + sx_, -34.65, 0.95, 0.12, 0.12, 0.35, 'rubber'); mb.box(p + sx_, -34.68, 1.3, 0.18, 0.1, 0.12, 'metal_light')
        mb.box(p, -33.7, 0.22, 1.1, 0.1, 0.9, 'graphite_dark')                    # island back guard
        mb.box(p - 0.5, -34.8, 0.22, 0.12, 0.12, 0.45, 'neon_amber'); mb.box(p + 0.5, -34.8, 0.22, 0.12, 0.12, 0.45, 'neon_amber')   # protective bollard lights
        mb.box(p, -34.2, 0.22, 0.2, 0.2, 2.2, 'graphite_dark')
    # canopy structure: fascia band, trusses, light panels (visible edge + underside), column bases
    mb.box(-21.5, -36.2, 5.85, 34.4, 0.4, 0.5, 'graphite'); mb.box(-21.5, -36.42, 5.95, 34.0, 0.04, 0.12, 'neon_amber')
    for x in np.arange(-36, -5, 3.0):
        mb.box(x, -32.6, 5.6, 0.16, 7.0, 0.3, 'graphite_dark')
    for cx in (-37.0, -26.0, -16.0, -6.0):
        mb.box(cx, -29.5, 0, 0.9, 0.9, 0.25, 'concrete'); mb.box(cx, -29.5, 5.6, 0.8, 0.8, 0.3, 'graphite_dark')
    solar_row(mb, -34, -31.5, 7, 4.6, w=4.0, d=3.4, z=6.45, tilt=0.35)
    # air & water island + tank vent pipes (clear of bays; checked)
    if _safe(-1.2, -39.0, 1.0, 2.0, 1.3):
        mb.box(-1.2, -39.0, 0, 1.2, 2.0, 0.2, 'concrete'); mb.box(-1.2, -39.0, 0.2, 0.5, 0.5, 1.3, 'steel_teal'); mb.box(-1.2, -39.28, 1.0, 0.4, 0.03, 0.3, 'neon_cyan')
    for k in range(3):
        mb.cyl(-39.5 + 0.7 * k, -27.4, 0, 0.07, 3.6, 'metal_light', seg=6)
    mb.box(-38.8, -27.4, 3.6, 2.1, 0.12, 0.12, 'metal_light')
    mb.finish("Fuel_Station_Dressing", cf)

    # ------------------------------------------------------------------------------------ EV STATION dressing
    mb = MB()
    for i in range(6):
        px_ = 27 + 4.5 * i + 2.25
        mb.box(px_, -36.3, 1.5, 0.52, 0.37, 0.08, 'neon_blue')
        mb.cyl(px_ + 0.38, -36.1, 0.2, 0.05, 1.0, 'rubber', seg=5)                        # cable holster
        mb.cyl(px_, -36.3, 1.58, 0.0, 0.0, 'graphite') if False else None
        mb.box(px_, -36.3, 1.6, 0.3, 0.3, 0.55, 'graphite_dark'); mb.box(px_, -36.3, 2.15, 0.3, 0.3, 0.05, 'neon_cyan')    # LED mast head
        mb.box(px_, -36.3, 0, 0.7, 0.55, 0.12, 'concrete')
    # canopy beams + under-glow + solar tilt rows
    for x in np.arange(22.5, 56, 3.0):
        mb.box(x, -34.2, 5.1, 0.14, 6.6, 0.28, 'graphite')
    mb.box(39, -37.7, 5.25, 36.4, 0.3, 0.45, 'graphite'); mb.box(39, -37.88, 5.35, 36.0, 0.04, 0.12, 'neon_cyan')
    solar_row(mb, 24.2, -34.2, 8, 4.2, w=3.7, d=5.0, z=5.62, tilt=0.4)
    # wheel guards between bays (low), outside slot footprints
    for i in range(7):
        x_ = 27 + 4.5 * i - 2.25
        if _safe(x_, -40, 0.2, 5.0, 0.0) if False else True:
            pass
    mb.finish("EV_Station_Dressing", cf)

    # ------------------------------------------------------------------------------------ display plinths: blank info steles + spot posts behind each platform, showcase inlay
    mb = MB()
    for i in range(6):
        x_ = -51 + 8 * i
        for sx in (-1, 1):
            xp = x_ + sx * 2.3
            if _safe(xp, 25.3, 0.3, 0.3, 0.2):
                mb.box(xp, 25.3, 0, 0.22, 0.22, 2.6, 'graphite')
                mb.box(xp - 0.1 * sx, 25.15, 2.5, 0.5, 0.35, 0.18, 'graphite_dark')
                mb.box(xp - 0.05 * sx, 25.05, 2.44, 0.36, 0.2, 0.05, 'int_panel')       # warm spot-light lens
        if _safe(x_, 25.9, 1.0, 0.3, 0.2):
            mb.box(x_, 25.9, 0, 1.0, 0.18, 0.9, 'graphite', mtop='graphite_dark')
            mb.box(x_, 25.78, 0.55, 0.8, 0.02, 0.28, 'int_dark')                         # blank info plate (no text)
    # showcase inlay: radial spokes + concentric dim bands on the central turntable apron (below the cyan rings)
    for k in range(24):
        a = 2 * math.pi * k / 24
        r0, r1 = 3.2, 7.2
        c_, s_ = math.cos(a), math.sin(a)
        mb.quad((r0 * c_ - 0.06 * s_, r0 * s_ + 0.06 * c_, 0.515), (r1 * c_ - 0.06 * s_, r1 * s_ + 0.06 * c_, 0.515),
                (r1 * c_ + 0.06 * s_, r1 * s_ - 0.06 * c_, 0.515), (r0 * c_ + 0.06 * s_, r0 * s_ - 0.06 * c_, 0.515), 'mark_white' if k % 3 else 'refl_cyan')
    mb.finish("Display_Showcase_Dressing", C['Showcase_Display'])

    # ------------------------------------------------------------------------------------ light poles + planters in the parking zones (soft props: auto-removed if they ever block a slot)
    cv = C['Vegetation']
    for (x, y) in [(-68.2, -34), (-47, -34), (-43.5, -34), (-68.2, -10), (-47, -10), (-36.5, -10), (-52.5, 6), (-68.2, 6), (-14, -10), (14, 8), (14, -10), (34, 20), (58, 12),
                   (3, 33), (-8, 34), (-52, 30), (-34, 28)]:
        if _safe(x, y, 0.4, 0.4, 1.4):
            P.place('plazalight', cd, x, y, 0.0, rot=0)
    for (x, y) in [(-61, -10), (-45, -10), (-35, -35), (7, -22), (-10, 20), (27, 21), (51, 22), (-20, 6), (6, 26)]:
        if _safe(x, y, 1.4, 1.4, 1.5):
            P.place('planter_s', cv, x, y, 0.0)
