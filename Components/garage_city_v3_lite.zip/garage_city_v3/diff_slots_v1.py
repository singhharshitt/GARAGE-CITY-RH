"""python3 diff_slots_v1.py -> slot_diff_vs_v1.json + slot_diff_vs_v2.json : compares this build's slots.json (V3) against the V1 baseline
(slots_v1.json, shipped here) and against the V2 pack's slots.json (../garage_city_v2/slots.json if present, else slots_v2.json)."""
import json, os
D = os.path.dirname(os.path.abspath(__file__))
KEYS = ['type', 'zone', 'x', 'y', 'z', 'nose', 'yaw', 'w', 'l', 'h', 'note', 'blender_zup', 'gltf_yup', 'nose_direction', 'metadata']
def diff(base_path, label, out):
    base = {s['name']: s for s in json.load(open(base_path))}
    cur = {s['name']: s for s in json.load(open(os.path.join(D, 'slots.json')))}
    rep = dict(baseline=label, baseline_count=len(base), v3_count=len(cur), missing_in_v3=sorted(set(base) - set(cur)), new_in_v3=sorted(set(cur) - set(base)), changed=[])
    for n in sorted(set(base) & set(cur)):
        d = {k: [base[n].get(k), cur[n].get(k)] for k in KEYS if k in base[n] and base[n].get(k) != cur[n].get(k)}
        if d: rep['changed'].append(dict(slot=n, diff=d))
    bad = []
    for n, s in cur.items():
        g = s['gltf_yup']['position_m']
        if [round(s['x'], 4), round(s['z'], 4), round(-s['y'], 4)] != [round(a, 4) for a in g]: bad.append(n)
    rep['gltf_position_mismatch'] = bad
    rep['identical'] = not (rep['missing_in_v3'] or rep['new_in_v3'] or rep['changed'] or bad)
    json.dump(rep, open(os.path.join(D, out), 'w'), indent=1)
    print(label, 'identical =', rep['identical'], '| changed', len(rep['changed']), 'missing', len(rep['missing_in_v3']), 'new', len(rep['new_in_v3']), 'count', rep['v3_count'])
diff(os.path.join(D, 'slots_v1.json'), 'V1', 'slot_diff_vs_v1.json')
v2 = os.path.join(D, 'slots_v2.json')
if not os.path.exists(v2): v2 = os.path.join(D, '..', 'garage_city_v2', 'slots.json')
diff(v2, 'V2', 'slot_diff_vs_v2.json')
