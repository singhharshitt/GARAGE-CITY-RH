# V3 progress notes (resume file)
DONE: build (build_scene.py) + postprocess (tools/postprocess_glb.mjs) -> compat GLBs + optimized/ (meshopt, ktx2, draco); previews (3 cams + close + hero, three.js full mode, from opt GLB);
 validate_glb.py, validate_glb_blender.py, threejs_load_test.mjs, validate_glb_three.mjs (clearance+LOS+neg control), negative_control.py (.blend) ; perf matrix (perf_results/*.json, MATRIX_DONE).
TODO (in order): 1 re-run all validators after final build; 2 slot diff V1/V2; 3 perf summarize (tools/perf/summarize.py); 4 gen_manifest.py V3 -> environment_manifest.md; 5 COMPARISON_V1_V2_V3.md, CHANGELOG_V3.md, validation_report.md;
 6 run.sh/run_build.sh update; 7 pack zip (python zipfile); 8 verify V1/V2 untouched; 9 final report.
validators rerun OK (run_validate.sh); slots diff v1/v2 identical (slot_empties_diff_vs_v1_v2.json). NEXT: stats, docs, zip
docs+changelog+run scripts done; NEXT: zip, final untouched check, report
ZIP built. NEXT: final report
