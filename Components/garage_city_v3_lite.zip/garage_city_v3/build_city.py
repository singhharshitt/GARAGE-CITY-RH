from gc_lib import *
import gc_props as P
import gc_city2 as C2
from gc_arch import trench_grate
HWY_PTS = []     # (x,y,z) samples of every highway, used to keep skyline blocks clear of them
SHORE_Y = 252.0   # far-shore quay line (bay is y 125..252)

CAM_PERSP = None      # set by build_scene: (Vector pos)
SLOT_PTS = []         # (x,y) of slots for shadow checks
TAN_ISO = math.tan(math.radians(35.264))

# ---------------------------------------------------------------- layout constants
NS_ROADS = [-400, -330, -260, -200, -150, -84, 84, 192, 260, 330, 400]
EW_ROADS = [-120, -64, 64, 100]
RW = 16.0
CANAL = (140.0, 160.0)
BASIN = (140.0, 322.0, -56.0, 124.0)     # V3: harbour basin NE of the garage (x0,x1,y0,y1) -> waterfront visible from the gameplay camera
X_MIN, X_MAX = -440.0, 440.0
Y_MIN, Y_MAX = -200.0, 124.0
WATER_Z = -1.0
PAVE_Z = 0.15

def in_basin(x, y, m=0.0):
    return BASIN[0] - m < x < BASIN[1] + m and BASIN[2] - m < y < BASIN[3] + m

def seg_point_dist(px, py, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy
    t = 0 if L2 == 0 else max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / L2))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))

def occludes(rect, h):
    """does a building rect (x0,y0,x1,y1) of height h hide any car slot from the game cameras?"""
    x0, y0, x1, y1 = rect
    if max(abs((x0 + x1) / 2), abs((y0 + y1) / 2)) > 330 and h < 200:
        return False
    pts = [(x0, y0), (x1, y0), (x1, y1), (x0, y1), ((x0 + x1) / 2, (y0 + y1) / 2)]
    for (px, py) in pts:
        # perspective camera
        if CAM_PERSP is not None:
            cx, cy, cz = CAM_PERSP
            if h < cz - 5:
                k = cz / (cz - h)
                qx, qy = cx + (px - cx) * k, cy + (py - cy) * k
                for (sx, sy) in SLOT_PTS:
                    if seg_point_dist(sx, sy, px, py, qx, qy) < 4.5:
                        return True
        # iso ortho camera (looking toward +x +y)
        L = h / TAN_ISO
        qx, qy = px + L * 0.7071, py + L * 0.7071
        for (sx, sy) in SLOT_PTS:
            if seg_point_dist(sx, sy, px, py, qx, qy) < 4.5:
                return True
    return False

def fit_height(rect, h, hmin=5.0):
    while h > hmin and occludes(rect, h):
        h *= 0.85
    return max(h, hmin) if not occludes(rect, max(h, hmin)) else hmin * 0.6

# ---------------------------------------------------------------- catmull-rom
def catmull(pts, step=4.0):
    P3 = [Vector(p) for p in pts]
    P3 = [P3[0] * 2 - P3[1]] + P3 + [P3[-1] * 2 - P3[-2]]
    out = []
    for i in range(1, len(P3) - 2):
        p0, p1, p2, p3 = P3[i - 1], P3[i], P3[i + 1], P3[i + 2]
        L = (p2 - p1).length
        n = max(2, int(L / step))
        for k in range(n):
            t = k / n
            t2, t3 = t * t, t * t * t
            p = 0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3)
            out.append(p)
    out.append(P3[-2])
    return out

# ---------------------------------------------------------------- highways
def highway(name, ctrl, width, coll, veg_coll, neon, rng, thick=1.4, pillar_every=24.0, step=4.0, water_fn=None, lamp_every=48.0):
    pts = catmull(ctrl, step)
    n = len(pts)
    HWY_PTS.extend((p.x, p.y, p.z) for p in pts)
    tang, norm = [], []
    for i in range(n):
        a = pts[max(0, i - 1)]; b = pts[min(n - 1, i + 1)]
        t = Vector((b.x - a.x, b.y - a.y, 0)).normalized()
        tang.append(t); norm.append(Vector((-t.y, t.x, 0)))
    mb = MB(); mp = MB()
    W = width / 2
    def at(i, off, dz=0.0):
        p = pts[i]; nn = norm[i]
        return (p.x + nn.x * off, p.y + nn.y * off, p.z + dz)
    for i in range(n - 1):
        j = i + 1
        # top
        mb.quad(at(i, -W), at(j, -W), at(j, W), at(i, W), 'asphalt')
        # bottom
        mb.quad(at(i, W, -thick), at(j, W, -thick), at(j, -W, -thick), at(i, -W, -thick), 'graphite_dark')
        # deck sides
        mb.quad(at(i, W, 0), at(j, W, 0), at(j, W, -thick), at(i, W, -thick), 'graphite')       # left outward +n  (order d,c,b,a reversed form)
        mb.quad(at(j, -W, 0), at(i, -W, 0), at(i, -W, -thick), at(j, -W, -thick), 'graphite')
        # parapets
        pw = 0.55
        for sgn in (1, -1):
            o_out, o_in = sgn * W, sgn * (W - pw)
            hh = 0.95
            # outer face
            if sgn == 1:
                mb.quad(at(i, o_out, hh), at(j, o_out, hh), at(j, o_out, 0), at(i, o_out, 0), 'graphite')
                mb.quad(at(j, o_in, hh), at(i, o_in, hh), at(i, o_in, 0), at(j, o_in, 0), 'graphite')
                mb.quad(at(j, o_in, hh), at(j, o_out, hh), at(i, o_out, hh), at(i, o_in, hh), 'graphite_dark')
            else:
                mb.quad(at(j, o_out, hh), at(i, o_out, hh), at(i, o_out, 0), at(j, o_out, 0), 'graphite')
                mb.quad(at(i, o_in, hh), at(j, o_in, hh), at(j, o_in, 0), at(i, o_in, 0), 'graphite')
                mb.quad(at(i, o_in, hh), at(i, o_out, hh), at(j, o_out, hh), at(j, o_in, hh), 'graphite_dark')
            # neon strip on parapet inner face
            if sgn == 1:
                mb.quad(at(j, o_in - 0.01, 0.62), at(i, o_in - 0.01, 0.62), at(i, o_in - 0.01, 0.48), at(j, o_in - 0.01, 0.48), neon)
            else:
                mb.quad(at(i, o_in + 0.01, 0.62), at(j, o_in + 0.01, 0.62), at(j, o_in + 0.01, 0.48), at(i, o_in + 0.01, 0.48), neon)
        # under-deck neon strip along both sides
        mb.quad(at(i, W + 0.01, -0.45), at(j, W + 0.01, -0.45), at(j, W + 0.01, -0.62), at(i, W + 0.01, -0.62), neon)
        mb.quad(at(j, -W - 0.01, -0.45), at(i, -W - 0.01, -0.45), at(i, -W - 0.01, -0.62), at(j, -W - 0.01, -0.62), neon)
        # lane markings
        zz = 0.03
        for off in (-0.25, 0.25):
            mb.quad(at(i, off - 0.07, zz), at(j, off - 0.07, zz), at(j, off + 0.07, zz), at(i, off + 0.07, zz), 'mark_yellow')
        if i % 2 == 0:
            for off in (-W / 2, W / 2):
                mb.quad(at(i, off - 0.08, zz), at(j, off - 0.08, zz), at(j, off + 0.08, zz), at(i, off + 0.08, zz), 'mark_white')
        for off in (-(W - pw - 0.5), (W - pw - 0.5)):
            mb.quad(at(i, off - 0.1, zz), at(j, off - 0.1, zz), at(j, off + 0.1, zz), at(i, off + 0.1, zz), 'mark_white')
    # pillars
    acc = 0.0
    for i in range(1, n - 1):
        acc += (pts[i] - pts[i - 1]).length
        if acc < pillar_every:
            continue
        acc = 0.0
        p = pts[i]
        base = 0.0
        if water_fn and water_fn(p.x, p.y):
            base = -2.0
        zb = p.z - thick
        if zb - base < 2.4:
            continue
        yaw = math.degrees(math.atan2(tang[i].y, tang[i].x))
        mp.box(p.x, p.y, base, 2.2, 2.2, zb - 1.3 - base, 'concrete', rot=yaw)
        mp.box(p.x, p.y, zb - 1.3, 2.6, width - 3.0, 1.3, 'graphite', rot=yaw)
        mp.box(p.x, p.y, zb - 0.12, 2.65, width - 2.9, 0.1, neon, rot=yaw)
    ob = mb.finish(name + "_deck", coll)
    mp.finish(name + "_pillars", coll)
    # lamps on the deck edge
    acc = 0.0
    for i in range(1, n - 1):
        acc += (pts[i] - pts[i - 1]).length
        if acc < lamp_every:
            continue
        acc = 0.0
        p = pts[i]
        for sgn in (1, -1):
            nn = norm[i] * sgn
            ang = math.degrees(math.atan2(-nn.y, -nn.x))
            l = P.place('streetlight', veg_coll, p.x + nn.x * (W - 0.8), p.y + nn.y * (W - 0.8), p.z + 0.0, rot=ang, scale=0.75)
    return pts

# ---------------------------------------------------------------- towers
WIN_TILE = (12.0, 28.8)
def win_mat(rng, pref=None):
    return pref or rng.choice(['win_cool', 'win_cool', 'win_warm', 'win_neon', 'win_warm'])

def tower(mb, x, y, w, d, h, rng, wm=None, accent=None, antenna=True, podium=0.0, rot=0, detail=True):
    wm = win_mat(rng, wm)
    uo, vo = rng.random(), rng.random()
    uv = (WIN_TILE[0], WIN_TILE[1], uo, vo)
    if podium > 0:
        mb.box(x, y, 0, w + 4, d + 4, podium, wm, rot=rot, mtop='graphite_dark', uv=(WIN_TILE[0], WIN_TILE[1], uo, vo))
        if accent:
            mb.box(x, y, podium - 0.3, w + 4.3, d + 4.3, 0.3, accent, rot=rot, top=False)
    kind = rng.random()
    if h > 60 and kind < 0.35:      # tiered
        t1 = h * 0.55; t2 = h * 0.28; t3 = h * 0.17
        mb.box(x, y, podium, w, d, t1, wm, rot=rot, mtop='graphite_dark', uv=uv)
        mb.box(x, y, podium + t1, w * 0.78, d * 0.78, t2, wm, rot=rot, mtop='graphite_dark', uv=(WIN_TILE[0], WIN_TILE[1], uo, vo + 0.37))
        mb.box(x, y, podium + t1 + t2, w * 0.5, d * 0.5, t3, wm, rot=rot, mtop='graphite_dark', uv=(WIN_TILE[0], WIN_TILE[1], uo + .3, vo + 0.1))
        top = podium + h
        if accent:
            mb.box(x, y, podium + t1 - 0.2, w * 1.02, d * 1.02, 0.35, accent, rot=rot, top=False)
            mb.box(x, y, podium + t1 + t2 - 0.2, w * 0.8, d * 0.8, 0.35, accent, rot=rot, top=False)
        zt = top
        wt, dt = w * 0.5, d * 0.5
    else:
        mb.box(x, y, podium, w, d, h, wm, rot=rot, mtop='graphite_dark', uv=uv)
        zt = podium + h
        wt, dt = w, d
        if accent:
            mb.box(x, y, zt - 0.3, w + 0.35, d + 0.35, 0.45, accent, rot=rot, top=False)
            if h > 45 and detail:       # vertical corner light strips on two corners
                for (sx, sy) in ((1, 1), (-1, -1)):
                    c, s = math.cos(math.radians(rot)), math.sin(math.radians(rot))
                    ax, ay = sx * w / 2, sy * d / 2
                    mb.box(x + ax * c - ay * s, y + ax * s + ay * c, podium, 0.5, 0.5, h, accent, rot=rot)
    if detail:
        # rooftop equipment + antenna
        mb.box(x + wt * 0.15, y - dt * 0.1, zt, wt * 0.3, dt * 0.25, 2.0, 'graphite', rot=rot)
        if antenna and h > 40 and rng.random() < 0.7:
            mb.cyl(x, y, zt, 0.25, 12 + rng.random() * 14, 'metal_light', seg=4)
            mb.box(x, y, zt + 12 + rng.random() * 3, 0.6, 0.6, 0.6, 'neon_amber')
    return zt

def landmark_spire(mb, x, y, rng, scale=1.0):
    s = scale
    uv = (WIN_TILE[0], WIN_TILE[1], 0.1, 0.2)
    mb.box(x, y, 0, 40 * s, 40 * s, 12, 'win_cool', uv=uv, mtop='graphite_dark')
    # tapering shaft in 4 stages
    h0 = 12; sizes = [(26, 90), (20, 70), (14, 50), (8, 36)]
    for (sz, hh) in sizes:
        mb.box(x, y, h0, sz * s, sz * s, hh * s, 'win_cool', uv=(WIN_TILE[0], WIN_TILE[1], 0.2, 0.0 + h0 / 50), mtop='graphite_dark')
        mb.box(x, y, h0 + hh * s - 0.5, sz * s + 0.5, sz * s + 0.5, 0.9, 'neon_cyan', top=False)
        h0 += hh * s
    mb.cyl(x, y, h0, 0.7, 70 * s, 'metal_light', seg=5, r2=0.12)
    mb.box(x, y, h0 + 70 * s, 1.2, 1.2, 1.2, 'neon_amber')
    for (ax, ay) in ((1, 1), (1, -1), (-1, 1), (-1, -1)):
        mb.box(x + ax * 13 * s, y + ay * 13 * s, 12, 0.6, 0.6, 90 * s, 'neon_cyan')
    return h0 + 70 * s

def landmark_pill(mb, x, y, rng, h=230, r=14):
    mb.cyl(x, y, 0, r, h, 'win_neon', seg=16, uv=(WIN_TILE[0], WIN_TILE[1], 0.3, 0.1), mtop='graphite_dark')
    for k in range(6):
        z = 30 + k * (h - 40) / 6
        mb.cyl(x, y, z, r + 0.4, 1.2, 'neon_magenta' if k % 2 == 0 else 'neon_violet', seg=16, top=False)
    mb.cyl(x, y, h, r * 0.7, 18, 'graphite', seg=16, r2=r * 0.35)
    mb.cyl(x, y, h + 18, 0.4, 40, 'metal_light', seg=4, r2=0.1)
    mb.box(x, y, h + 58, 0.9, 0.9, 0.9, 'neon_amber')
    return h + 58

def landmark_twin(mb, x, y, rng, h=190):
    for sx in (-1, 1):
        C2.tower2(mb, x + sx * 17, y, 20, 24, h, rng, kind='tapered', wm='win_warm', accent='neon_amber', detail=False)
    mb.box(x, y, h * 0.62, 34, 14, 10, 'glass', mtop='graphite')
    mb.box(x, y, h * 0.62 + 9.6, 34.5, 14.5, 0.5, 'neon_cyan', top=False)
    mb.box(x, y, h * 0.62 - 0.2, 34.5, 14.5, 0.4, 'neon_cyan', top=False)
    return h

def landmark_led(mb, x, y, rng, h=180):
    w, d = 24, 14
    mb.box(x, y, 0, w, d, h, 'graphite', mtop='graphite_dark')
    # LED facade stripes on the south face (abstract, no text)
    cols = ['refl_cyan', 'refl_violet', 'refl_cyan', 'refl_magenta']
    n = 10
    for i in range(n):
        wi = w / n
        hh = h * (0.45 + 0.5 * ((i * 37) % 10) / 10)
        mb.box(x - w / 2 + wi * (i + 0.5), y - d / 2 - 0.15, h - hh - 8, wi - 0.4, 0.3, hh, cols[i % 4], top=False)
    mb.box(x, y, h, w + 0.5, d + 0.5, 0.8, 'neon_cyan')
    return h

def nsegs(rx, segs):
    """NS road segments, clipped so they stop at the basin south quay"""
    out = []
    for (a, b) in segs:
        if BASIN[0] - 1 < rx < BASIN[1] + 1:
            if a >= BASIN[2] - 1: continue
            b = min(b, BASIN[2] - 1.0)
            if b - a < 2: continue
        out.append((a, b))
    return out

# ---------------------------------------------------------------- scene builder
def build_roads(C, rng):
    cr, cv = C['Roads'], C['Road_Props']
    mb = MB()
    # big base ground (land) tiles avoiding canal and bay
    def ground(x0, y0, x1, y1, z=-0.25):
        mb.box((x0 + x1) / 2, (y0 + y1) / 2, z - 0.5, x1 - x0, y1 - y0, 0.5, 'ground')
    ground(-900, -300, CANAL[0], 124)                     # west of canal/basin
    ground(CANAL[1], -300, 900, BASIN[2])                  # south of the basin (east of the canal)
    ground(BASIN[1], BASIN[2], 900, 124)                   # east of the basin
    # seabed under water
    mb.box(0, 100, -3.5, 2000, 800, 0.5, 'ground')
    mb.finish("Ground_Base", cr)
    # roads: EW continuous
    mb = MB()
    def road_slab(x0, y0, x1, y1):
        mb.box((x0 + x1) / 2, (y0 + y1) / 2, -0.25, x1 - x0, y1 - y0, 0.25, 'asphalt', top=True)
    for ry in EW_ROADS:
        if BASIN[2] < ry < BASIN[3]:          # road ends at the basin quays
            road_slab(X_MIN, ry - RW / 2, BASIN[0] - 1.2, ry + RW / 2)
            road_slab(BASIN[1] + 1.2, ry - RW / 2, X_MAX, ry + RW / 2)
        else:
            road_slab(X_MIN, ry - RW / 2, X_MAX, ry + RW / 2)
    ey = [(ry - RW / 2, ry + RW / 2) for ry in EW_ROADS]
    # NS roads: segments between EW roads
    Ys = [Y_MIN] + [v for e in ey for v in e] + [Y_MAX]
    segs = [(Ys[i], Ys[i + 1]) for i in range(0, len(Ys) - 1, 2)]
    segs = [(a, b) for (a, b) in segs if b - a > 1 and a < 100]
    for rx in NS_ROADS:
        for (a, b) in nsegs(rx, segs):
            road_slab(rx - RW / 2, a, rx + RW / 2, b)
    mb.finish("Road_Surfaces", cr)
    # markings
    mb = MB()
    def in_ns(x, margin=10):
        return any(abs(x - rx) < RW / 2 + margin for rx in NS_ROADS) or (CANAL[0] - 2 < x < CANAL[1] + 2)
    def in_ew(y, margin=10):
        return any(abs(y - ry) < RW / 2 + margin for ry in EW_ROADS)
    LIM = 300
    for ry in EW_ROADS:
        x = -LIM
        while x < LIM:
            if not in_ns(x + 1.5) and not in_basin(x + 4, ry):
                if ry != 100:
                    for o in (-0.22, 0.22):                         # V3: solid double-yellow centre line
                        gq(mb, x, ry + o - 0.06, x + 8, ry + o + 0.06, 0.04, 'mark_yellow')
                for off in (-4.0, 4.0):
                    gq(mb, x, ry + off - 0.08, x + 3, ry + off + 0.08, 0.04, 'mark_white')
            x += 8
        # edge lines
        # V3: edge lines only between junctions (no lines through intersections / over the basin)
        xe = [-LIM] + sorted(v for rx in NS_ROADS if abs(rx) < LIM for v in (rx - RW / 2 - 0.4, rx + RW / 2 + 0.4)) + [LIM]
        for k in range(0, len(xe) - 1, 2):
            for off in (-RW / 2 + 0.5, RW / 2 - 0.5):
                xa_, xb_ = xe[k], xe[k + 1]
                if in_basin((xa_ + xb_) / 2, ry): continue
                if xb_ - xa_ > 2: gq(mb, xa_, ry + off - 0.08, xb_, ry + off + 0.08, 0.04, 'mark_white')
        # stop lines before every NS junction
        for rx in NS_ROADS:
            if abs(rx) > LIM or in_basin(rx, ry): continue
            for sgn, off in ((-1, -1), (1, 1)):
                xx = rx + sgn * (RW / 2 + 0.9)
                gq(mb, xx - 0.2, ry - (RW / 2 - 0.6) * (1 if sgn < 0 else 0) - (0 if sgn < 0 else 0) * 0, xx + 0.2, ry, 0.04, 'mark_white') if False else None

    for rx in NS_ROADS:
        if abs(rx) > LIM:
            continue
        y = -190
        ylim = BASIN[2] - 3 if BASIN[0] - 1 < rx < BASIN[1] + 1 else 90
        while y < ylim:
            if not in_ew(y + 1.5):
                for o in (-0.22, 0.22):
                    gq(mb, rx + o - 0.06, y, rx + o + 0.06, y + 8, 0.04, 'mark_yellow')
                for off in (-4.0, 4.0):
                    gq(mb, rx + off - 0.08, y, rx + off + 0.08, y + 3, 0.04, 'mark_white')
            y += 8
        for off in (-RW / 2 + 0.5, RW / 2 - 0.5):
            for (a, b) in nsegs(rx, segs):
                if b - a > 20:
                    gq(mb, rx + off - 0.08, a + 1, rx + off + 0.08, min(b, 92) - 1, 0.04, 'mark_white')
    # crosswalks + stop lines
    for ry in EW_ROADS:
        for rx in NS_ROADS:
            if abs(rx) > 270 or in_basin(rx, ry, 8):
                continue
            for sgn in (-1, 1):
                # across NS road, north/south of the intersection (stripes along y)
                cy = ry + sgn * (RW / 2 + 2.2)
                for k in range(-6, 7):
                    gq(mb, rx + k * 1.15 - 0.3, cy - 1.6, rx + k * 1.15 + 0.3, cy + 1.6, 0.04, 'mark_white')
                # across EW road, east/west of the intersection (stripes along x)
                cx = rx + sgn * (RW / 2 + 2.2)
                for k in range(-6, 7):
                    gq(mb, cx - 1.6, ry + k * 1.15 - 0.3, cx + 1.6, ry + k * 1.15 + 0.3, 0.04, 'mark_white')
    mb.finish("Road_Markings", cr)

    # canal + bridges + quays
    mb = MB()
    for xq, ytop in ((CANAL[0] - 0.6, 124), (CANAL[1] + 0.6, BASIN[2])):
        mb.box(xq, (Y_MIN + ytop) / 2, -1.6, 1.2, ytop - Y_MIN, 1.75, 'concrete', mtop='graphite')
        gq(mb, xq - 0.55 if xq < 150 else xq - 0.55, Y_MIN, xq + 0.55, 124, 0.165, 'neon_cyan') if False else None
    for xq, ytop in ((CANAL[0] - 1.1, 124), (CANAL[1] + 1.1, BASIN[2])):
        gq(mb, xq - 0.05, Y_MIN, xq + 0.05, ytop, 0.17, 'neon_cyan')
    mb.finish("Canal_Quays", cr)
    mb = MB()
    for ry in [r_ for r_ in EW_ROADS if not (BASIN[2] < r_ < BASIN[3])]:
        # bridge deck + parapets
        mb.box(150, ry, -0.5, 24, RW, 0.5, 'graphite', mtop='asphalt')
        for sgn in (-1, 1):
            mb.box(150, ry + sgn * (RW / 2 - 0.25), 0, 24, 0.5, 1.0, 'graphite')
            gq(mb, 138, ry + sgn * (RW / 2 - 0.25) - 0.04, 162, ry + sgn * (RW / 2 - 0.25) + 0.04, 1.02, 'neon_cyan')
        # under-bridge arches suggestion
        mb.box(150, ry, -2.2, 22, 3.0, 1.7, 'concrete')
    mb.finish("Bridges_Canal", cr)

    # medians (landscaped islands) with palms
    mb = MB()
    def median_x(ry):
        x = -LIM
        while x < LIM:
            if not in_ns(x + 15, margin=6) and not in_basin(x + 15, ry, 15):
                a, b = x, min(x + 30, LIM)
                mb.box((a + b) / 2, ry, 0, b - a, 3.0, 0.25, 'planter', mtop='lawn')
                P.palm(cv, a + 15, ry, 0.25, rng, k=rng.choice([0, 1]))
            x += 30
    for ry in (-120, 64, -64):
        median_x(ry)
    def median_y(rx):
        for (a, b) in segs:
            if b - a > 30:
                aa, bb = a + 10, min(b, 92) - 10
                mb.box(rx, (aa + bb) / 2, 0, 3.0, bb - aa, 0.25, 'planter', mtop='lawn')
                y = aa + 8
                while y < bb - 4:
                    P.palm(cv, rx, y, 0.25, rng, k=rng.choice([0, 1]))
                    y += 14
    for rx in (-84, 84):
        median_y(rx)
    mb.finish("Landscaped_Islands", cr)

    # streetlights, signs, bollards along sidewalks (instances)
    for ry in EW_ROADS:
        x = -250 + rng.uniform(0, 10)
        while x < 270:
            if not in_ns(x, margin=8) and not in_basin(x, ry, 6):
                for sgn in (1, -1):
                    P.place('streetlight', cv, x, ry + sgn * (RW / 2 + 1.0), 0.0, rot=(-90 * sgn))
            x += 38
    for rx in NS_ROADS:
        if abs(rx) > 270:
            continue
        for (a, b) in nsegs(rx, segs):
            y = a + 14
            while y < min(b, 92) - 10:
                for sgn in (1, -1):
                    P.place('streetlight', cv, rx + sgn * (RW / 2 + 1.0), y, 0.0, rot=(180 if sgn == 1 else 0))
                y += 38
    # road signs near intersections
    for ry in EW_ROADS:
        for rx in NS_ROADS:
            if abs(rx) <= 270 and rng.random() < 0.55 and not in_basin(rx, ry, 12):
                P.place('sign', cv, rx + RW / 2 + 2.2, ry - RW / 2 - 2.2, 0.0, rot=rng.choice([0, 90, 180, 270]))
    return segs

def block_cells():
    xs = sorted([r - RW / 2 for r in NS_ROADS] + [r + RW / 2 for r in NS_ROADS] + [CANAL[0], CANAL[1]])
    ysr = []
    for ry in EW_ROADS:
        ysr += [ry - RW / 2, ry + RW / 2]
    xi = [(X_MIN, xs[0])]
    for i in range(1, len(xs) - 1, 2):
        xi.append((xs[i], xs[i + 1]))
    xi.append((xs[-1], X_MAX))
    # canal creates gap: remove cells that are the canal itself
    xi = [(a, b) for (a, b) in xi if not (abs(a - CANAL[0]) < 0.1 and abs(b - CANAL[1]) < 0.1) and b - a > 6]
    yi = [(Y_MIN + 0.0, ysr[0])] + [(ysr[i], ysr[i + 1]) for i in range(1, len(ysr) - 1, 2)] + [(ysr[-1], 124.0)]
    return xi, yi

def build_blocks(C, rng, stats):
    cb, cv, cbg = C['Blocks'], C['Block_Veg'], C['Skyline']
    xi, yi = block_cells()
    pave = MB()
    cells = []
    for (xa, xb) in xi:
        for (ya, yb) in yi:
            if xa >= BASIN[0] - 0.1 and xb <= BASIN[1] + 0.1 and yb > BASIN[2] + 0.1:
                continue                      # V3: this cell is the harbour basin
            cells.append((xa, ya, xb, yb))
    idx = 0
    for (xa, ya, xb, yb) in cells:
        cx, cy = (xa + xb) / 2, (ya + yb) / 2
        w, d = xb - xa, yb - ya
        if w < 8 or d < 8:
            continue
        # skip garage cell (special) -> sidewalk ring only
        if xa <= -75 and xb >= 75 and ya <= -55 and yb >= 55 and abs(cx) < 5 and abs(cy) < 5:
            continue
        # promenade strip (y >= 108)
        if ya >= 107:
            pave.box(cx, cy, -0.25, w, d, PAVE_Z + 0.25, 'sidewalk')
            continue
        pave.box(cx, cy, -0.25, w, d, PAVE_Z + 0.25, 'sidewalk')
        # V3: kerb stones around the lot + storm grates (edge transition road -> kerb -> sidewalk)
        kw = 0.35
        for (kx, ky, ksx, ksy) in ((cx, ya + kw / 2, w, kw), (cx, yb - kw / 2, w, kw), (xa + kw / 2, cy, kw, d), (xb - kw / 2, cy, kw, d)):
            pave.box(kx, ky, PAVE_Z, ksx, ksy, 0.07, 'curb')
        if w > 40 and not (xa <= -75 and xb >= 75 and ya <= -55 and yb >= 55):
            for gx in (xa + w * 0.3, xa + w * 0.7):
                trench_grate(pave, gx - 0.8, ya + 0.6, gx + 0.8, ya + 1.1, z=0.0)
    # garage sidewalk ring
    pave.box(0, -54, -0.25, 152, 4, PAVE_Z + 0.25, 'sidewalk'); pave.box(0, 54, -0.25, 152, 4, PAVE_Z + 0.25, 'sidewalk')
    pave.box(-74, 0, -0.25, 4, 104, PAVE_Z + 0.25, 'sidewalk'); pave.box(74, 0, -0.25, 4, 104, PAVE_Z + 0.25, 'sidewalk')
    # promenade rim light + railings
    pave.finish("Block_Pavements", cb)
    cnt = 0
    for (xa, ya, xb, yb) in cells:
        cx, cy = (xa + xb) / 2, (ya + yb) / 2
        w, d = xb - xa, yb - ya
        if w < 8 or d < 8 or ya >= 107:
            continue
        if xa <= -75 and xb >= 75 and ya <= -55 and yb >= 55 and abs(cx) < 5:
            continue
        idx += 1
        # character of the cell
        near_cam = (cx + cy) / 1.414 < -70 or (ya < -60 and abs(cx) < 220)
        far = abs(cx) > 300 or abs(cy) > 250
        r = rng.random()
        lot = (xa + 4, ya + 4, xb - 4, yb - 4)
        lw, ld = lot[2] - lot[0], lot[3] - lot[1]
        if lw < 6 or ld < 6:
            continue
        mbp = MB()   # buildings
        force_park = abs(xb - BASIN[0]) < 0.1 and yb > BASIN[2]          # V3: waterfront park along the basin's west shore
        if force_park or (near_cam and r < 0.55) or (not near_cam and r < 0.12):
            # park / plaza
            mb = MB()
            plaza = (not force_park) and rng.random() < 0.38
            cxl, cyl_ = (lot[0] + lot[2]) / 2, (lot[1] + lot[3]) / 2
            mb.box(cxl, cyl_, PAVE_Z, lw - 3, ld - 3, 0.08, 'paving' if plaza else 'lawn', top=True)
            if plaza:
                # hard-landscaped plaza: tree planters on a grid, a few palms, benches
                for gx in range(int((lw - 8) // 9) + 1):
                    for gy in range(int((ld - 8) // 9) + 1):
                        px, py = lot[0] + 4.5 + gx * 9, lot[1] + 4.5 + gy * 9
                        if px > lot[2] - 3 or py > lot[3] - 3 or (abs(px - cxl) < 5 and abs(py - cyl_) < 5):
                            continue
                        mb.box(px, py, PAVE_Z, 2.4, 2.4, 0.45, 'planter', top=True)
                        P.tree(cv, px, py, PAVE_Z + 0.45, rng) if rng.random() < 0.6 else P.place('bush', cv, px, py, PAVE_Z + 0.45, scale=rng.uniform(1.0, 1.5), rng=rng)
                for sgn in (-1, 1):
                    mb.box(cxl, cyl_ + sgn * (ld / 2 - 3.2), PAVE_Z + 0.08, min(lw - 10, 14), 0.5, 0.45, 'concrete', top=True)
            else:
                # paths + clipped hedges
                gq(mb, lot[0] + 1.5, cyl_ - 1.2, lot[2] - 1.5, cyl_ + 1.2, PAVE_Z + 0.1, 'sidewalk')
                gq(mb, cxl - 1.2, lot[1] + 1.5, cxl + 1.2, lot[3] - 1.5, PAVE_Z + 0.1, 'sidewalk')
                for sgn in (-1, 1):
                    for (a0, a1) in ((lot[0] + 2.5, cxl - 3), (cxl + 3, lot[2] - 2.5)):
                        if a1 - a0 > 3:
                            mb.box((a0 + a1) / 2, cyl_ + sgn * (ld / 2 - 2.6), PAVE_Z + 0.08, a1 - a0, 1.2, 0.8, 'foliage_b', top=True)
                for k in range(int(lw * ld / 300) + 2):
                    px, py = rng.uniform(lot[0] + 3, lot[2] - 3), rng.uniform(lot[1] + 3, lot[3] - 3)
                    if abs(px - cxl) < 2.5 or abs(py - cyl_) < 2.5 or abs(abs(py - cyl_) - (ld / 2 - 2.6)) < 1.6:
                        continue
                    r_ = rng.random()
                    if r_ < 0.4: P.palm(cv, px, py, PAVE_Z + 0.08, rng)
                    elif r_ < 0.8: P.tree(cv, px, py, PAVE_Z + 0.08, rng)
                    else: P.place('bush', cv, px, py, PAVE_Z + 0.08, scale=rng.uniform(1.0, 1.6), rng=rng)
            # fountain/light ring in the middle of some parks
            if rng.random() < 0.6:
                mb.cyl((lot[0] + lot[2]) / 2, (lot[1] + lot[3]) / 2, PAVE_Z, 4.0, 0.5, 'planter', seg=12, mtop='water')
                mb.cyl((lot[0] + lot[2]) / 2, (lot[1] + lot[3]) / 2, PAVE_Z + 0.5, 3.4, 0.02, 'neon_cyan', seg=12)
            mb.finish("Park_%02d" % idx, cb)
            continue
        # building lots
        nx = max(1, int(lw // 30)); ny = max(1, int(ld // 30))
        if far:
            nx, ny = max(1, int(lw // 40)), max(1, int(ld // 40))
        nx = min(nx, 3); ny = min(ny, 3)
        lwx, lwy = lw / nx, ld / ny
        # height character: taller to north/east and farther from the camera
        for i in range(nx):
            for j in range(ny):
                x0, y0 = lot[0] + i * lwx + 1.0, lot[1] + j * lwy + 1.0
                x1, y1 = lot[0] + (i + 1) * lwx - 1.0, lot[1] + (j + 1) * lwy - 1.0
                bw, bd = x1 - x0, y1 - y0
                if bw < 8 or bd < 8:
                    continue
                dist_back = ((cx + cy) / 1.414 + 150) / 450.0
                base = 14 + 120 * max(0.0, dist_back) * rng.random() ** 1.3
                if cy > 60:
                    base += 25 * rng.random()
                if near_cam:
                    base = min(base, 14)
                if y0 > 60 and abs((x0 + x1) / 2) < 330:      # V3: low waterfront row so the basin/bay shows behind the garage
                    base = min(base, 9 + 6 * rng.random())
                dcg = max(abs((x0 + x1) / 2) - 75, abs((y0 + y1) / 2) - 55, 0.0)   # distance from the garage compound
                base = min(base, 11 + 0.42 * dcg)
                rect = (x0, y0, x1, y1)
                h = fit_height(rect, base)
                podium = 0.0
                if h > 50 and bw > 20 and bd > 20:
                    podium = min(10, h * 0.15)
                    tw, td = bw - 4.5, bd - 4.5
                    tx, ty = (x0 + x1) / 2, (y0 + y1) / 2
                else:
                    tw, td = bw - 2.0, bd - 2.0
                    tx, ty = (x0 + x1) / 2, (y0 + y1) / 2
                accent = rng.choice(['neon_cyan', 'neon_cyan', 'neon_amber']) if rng.random() < 0.25 else None
                C2.tower2(mbp, tx, ty, tw, td, h - podium, rng, near=near_cam, accent=accent, podium=podium, detail=True)
                cnt += 1
                # rooftop garden on low buildings
                if h < 22 and tw > 12 and near_cam and rng.random() < 0.4:
                    C2.roof_garden(mbp, tx, ty, h, tw, td, rng)
        mbp.finish("Bldgs_Cell_%02d" % idx, cbg if (cy > 0 and not near_cam) else cb)
        # sidewalk trees
        k = 0
        while k < int(w / 15):
            for yy in (ya + 2.0, yb - 2.0):
                r_ = rng.random()
                px_ = xa + 7 + k * 15 + rng.uniform(-3.5, 3.5)
                if r_ < 0.28:
                    P.palm(cv, px_, yy, PAVE_Z, rng, k=rng.choice([0, 1, 2]))
                elif r_ < 0.46:
                    P.place('cypress', cv, px_, yy, PAVE_Z, scale=rng.uniform(0.8, 1.3), rng=rng)
                elif r_ < 0.58:
                    P.tree(cv, px_, yy, PAVE_Z, rng)
            k += 1
    stats['near_buildings'] = cnt

def bridge_pylons(C, rng):
    """cable-stayed pylons on the west flyover where it crosses the bay (visible supports + cable fans)"""
    mb = MB(); H = C['Highways']
    x0, y0, zd = -150.0, 190.0, 19.0
    for sx in (-1, 1):
        px = x0 + sx * 14.5
        mb.frustum(px, y0, -2.5, 4.5, 6.0, 2.2, 3.2, 88.0, 'concrete', mtop='graphite')
        mb.box(px, y0, 62.0, 2.4, 3.4, 0.5, 'neon_cyan', top=False)
        mb.box(px, y0, 85.0, 2.6, 3.6, 0.45, 'neon_violet', top=False)
        mb.box(px, y0, 40.0, 6.0, 8.0, 2.2, 'graphite')       # cross-head under the deck brace
        for k in range(1, 7):
            for sy in (-1, 1):
                top = (px, y0 + sy * 0.6, 84.0 - k * 2.6)
                bot = (x0 + sx * 8.5, y0 + sy * (k * 11.0), zd + 0.8)
                mb.pipe(top, bot, 0.11, 'metal_light', seg=4, caps=False)
    mb.box(x0, y0, 60.0, 31.0, 2.0, 1.2, 'graphite') if False else None
    mb.finish("Bridge_Pylons_West", H)

def build_promenade(C, rng):
    cw, cv = C['Waterfront'], C['Waterfront_Props']
    mb = MB()
    for (a, b) in ((X_MIN, CANAL[0]), (BASIN[1], X_MAX)):
        L = b - a; cx = (a + b) / 2
        mb.box(cx, 124.4, -1.6, L, 1.0, 1.9, 'concrete', mtop='graphite')       # quay wall
        gq(mb, a, 123.9, b, 124.05, PAVE_Z + 0.02, 'neon_cyan')
        mb.box(cx, 123.5, PAVE_Z, L, 0.12, 1.0, 'metal_light', top=True)          # low rail (thin slab)
        # benches + planters
        x = a + 10
        while x < b - 10:
            mb.box(x, 118, PAVE_Z, 3.0, 0.7, 0.45, 'graphite')
            mb.box(x + 7, 112, PAVE_Z, 5.0, 1.2, 0.5, 'planter', mtop='foliage')
            x += 24
    # piers / boardwalk fingers into the bay
    for px in (-250, -60, 100, 350, 400):
        mb.box(px, 136, -0.4, 10, 24, 0.55, 'graphite', mtop='terrace')
        gq(mb, px - 5, 124, px - 4.8, 148, 0.17, 'neon_amber'); gq(mb, px + 4.8, 124, px + 5, 148, 0.17, 'neon_amber')
        for k in range(4):
            P.place('plazalight', cv, px - 4.5, 128 + 6 * k, 0.15, rot=0)
            P.place('plazalight', cv, px + 4.5, 128 + 6 * k, 0.15, rot=180)
    mb.finish("Promenade_Quay", cw)
    x = X_MIN + 12
    while x < X_MAX:
        if not (CANAL[0] - 6 < x < BASIN[1] + 6):
            if rng.random() < 0.6: P.palm(cv, x, 115.0, PAVE_Z, rng, k=rng.choice([0, 1, 2]))
            else: P.place('cypress', cv, x, 115.0, PAVE_Z, scale=rng.uniform(0.9, 1.3), rng=rng)
            P.place('plazalight', cv, x + 12, 120.5, PAVE_Z, rot=-90)
        x += 24
    # water
    mb = MB()
    wm = 'water'
    def wq(x0, y0, x1, y1, z=WATER_Z, tile=26.0):
        mb.quad((x0, y0, z), (x1, y0, z), (x1, y1, z), (x0, y1, z), wm,
                uvs=[(x0 / tile, y0 / tile), (x1 / tile, y0 / tile), (x1 / tile, y1 / tile), (x0 / tile, y1 / tile)])
    wq(-900, 124.9, 1100, SHORE_Y + 0.6)
    wq(CANAL[0] + 0.3, -200, CANAL[1] - 0.3, BASIN[2] + 0.3)
    wq(BASIN[0] + 0.3, BASIN[2] + 0.3, BASIN[1] - 0.3, 124.9)
    mb.finish("Water_Surface", cw)
    # reflection streaks
    mb = MB()
    cols = ['refl_cyan', 'refl_amber', 'refl_amber']
    # V3: restrained highlights -- short soft glints grouped under the far-shore towers, none in the gameplay foreground
    for i in range(36):
        x = rng.uniform(-420, 640)
        y = rng.uniform(176, 246)
        L = rng.uniform(6, 22)
        wd = rng.uniform(0.35, 0.9)
        gq(mb, x - wd, y, x + wd, y + L, WATER_Z + 0.03, rng.choice(cols))
    for xh in (-150, 192):
        for k in range(4):
            gq(mb, xh - 0.4 + rng.uniform(-3, 3), 130 + k * 22, xh + 0.4 + rng.uniform(-3, 3), 130 + k * 22 + 8, WATER_Z + 0.03, 'refl_cyan')
    mb.finish("Water_Reflection_Streaks", cw)
    # canal water reflections
    mb = MB()
    for k in range(18):
        gq(mb, 149.0 + rng.uniform(-3, 3), -190 + k * 8, 150.4 + rng.uniform(-3, 3), -190 + k * 8 + 4, WATER_Z + 0.03, rng.choice(cols))
    mb.finish("Canal_Reflection_Streaks", cw)

def shore_edge(mb, cv, rng, p0, p1, land_n, lamp_every=26.0, bench_every=40.0, post=3.0, veg=True, z=PAVE_Z):
    """V3 waterfront edge: concrete coping, balustrade (posts + two rails), cyan-capped bollards, plaza lights, benches facing the
    water, a tree line inland.  p0->p1 runs along the quay line; land_n = unit vector pointing to the land side."""
    p0 = Vector((p0[0], p0[1], 0)); p1 = Vector((p1[0], p1[1], 0)); L = (p1 - p0).length
    t = (p1 - p0).normalized(); ang = math.degrees(math.atan2(t.y, t.x)); n = Vector((land_n[0], land_n[1], 0))
    c = (p0 + p1) / 2
    mb.box(c.x, c.y, z - 0.9, L, 0.9, 1.0, 'concrete', rot=ang, mtop='curb')                      # coping beam
    cc = c + n * 0.55
    mb.box(cc.x, cc.y, z + 0.0, L, 0.2, 0.08, 'graphite_dark', rot=ang)
    k = int(L / post)
    for i in range(k + 1):
        pnt = p0 + t * (L * i / max(1, k)) + n * 0.5
        mb.box(pnt.x, pnt.y, z, 0.07, 0.07, 1.0, 'graphite_dark', rot=ang)
    mb.box(c.x + n.x * 0.5, c.y + n.y * 0.5, z + 1.0, L, 0.08, 0.05, 'metal_light', rot=ang)
    mb.box(c.x + n.x * 0.5, c.y + n.y * 0.5, z + 0.5, L, 0.03, 0.03, 'metal_light', rot=ang)
    mb.box(c.x + n.x * 0.5, c.y + n.y * 0.5, z + 1.05, L, 0.04, 0.02, 'neon_cyan', rot=ang)
    d = 6.0
    while d < L - 4:
        pnt = p0 + t * d + n * 1.4
        P.place('bollard', cv, pnt.x, pnt.y, z, rot=0)
        d += 12.0
    d = 12.0 + rng.uniform(0, 6)
    while d < L - 6:
        pnt = p0 + t * d + n * 2.2
        P.place('plazalight', cv, pnt.x, pnt.y, z, rot=ang + (90 if n.x * -t.y + n.y * t.x > 0 else -90))
        d += lamp_every
    d = 20.0 + rng.uniform(0, 10)
    while d < L - 10:
        pnt = p0 + t * d + n * 2.6
        mb.box(pnt.x, pnt.y, z, 2.2, 0.55, 0.45, 'graphite', rot=ang + 0); mb.box(pnt.x + n.x * 0.3, pnt.y + n.y * 0.3, z + 0.45, 2.2, 0.12, 0.45, 'graphite', rot=ang)
        d += bench_every
    if veg:
        d = 8.0 + rng.uniform(0, 8)
        while d < L - 8:
            pnt = p0 + t * d + n * 5.0
            r_ = rng.random()
            if r_ < 0.4: P.palm(cv, pnt.x, pnt.y, z, rng, k=rng.choice([0, 1, 2]))
            elif r_ < 0.7: P.place('cypress', cv, pnt.x, pnt.y, z, scale=rng.uniform(0.9, 1.3), rng=rng)
            else: P.place('bush', cv, pnt.x, pnt.y, z, scale=rng.uniform(0.9, 1.6), rng=rng)
            d += rng.uniform(13, 22)

def build_basin(C, rng):
    """V3: basin + canal shores, steps into the water, mooring posts, bridge-head details"""
    cw, cv = C['Waterfront'], C['Waterfront_Props']
    mb = MB()
    x0, x1, y0, y1 = BASIN
    # south shore wall (road side), east shore wall, wall caps
    mb.box((CANAL[1] + x1) / 2, y0 + 0.6, -1.6, x1 - CANAL[1], 1.2, 1.75, 'concrete', mtop='graphite')
    mb.box(x1 + 0.6, (y0 + y1) / 2, -1.6, 1.2, y1 - y0, 1.75, 'concrete', mtop='graphite')
    gq(mb, CANAL[1], y0 - 0.1, x1, y0 + 0.05, 0.17, 'neon_cyan')
    shore_edge(mb, cv, rng, (CANAL[1] + 2, y0 - 1.2), (x1 - 2, y0 - 1.2), (0, -1))            # south boulevard edge
    shore_edge(mb, cv, rng, (x1 + 1.2, y0 + 3), (x1 + 1.2, y1 - 6), (1, 0))                      # east shore
    shore_edge(mb, cv, rng, (x0 - 1.2, y0 + 3), (x0 - 1.2, y1 - 4), (-1, 0), veg=False)          # west park edge
    shore_edge(mb, cv, rng, (CANAL[0] - 1.2, -190), (CANAL[0] - 1.2, y0 - 2), (-1, 0), lamp_every=34, veg=False)
    shore_edge(mb, cv, rng, (CANAL[1] + 1.2, -190), (CANAL[1] + 1.2, y0 - 12), (1, 0), lamp_every=34, veg=False)
    # steps down to the water (west shore, two places) + mooring posts + a floating pontoon with rails
    for yy in (-10.0, 62.0):
        mb.stairs(x0 + 1.6, yy, -1.0, 5.0, 1.15, 180, 4, 'concrete', tread=0.4, mside='concrete')
    for yy in (0.0, 20.0, 40.0, 80.0, 100.0):
        mb.cyl(x0 + 0.3, yy, -1.0, 0.18, 1.2, 'graphite', seg=6); mb.cyl(x0 + 0.3, yy, 0.2, 0.2, 0.06, 'neon_amber', seg=6)
    for (px, py) in ((x1 - 14, 40), (x0 + 20, 78)):
        mb.box(px, py, -1.2, 16, 4.5, 0.5, 'graphite', mtop='terrace')
        for sgn in (-1, 1):
            mb.box(px, py + sgn * 2.1, -0.7, 16, 0.08, 0.7, 'metal_light', top=True)
        mb.box(px, py, -0.69, 15.5, 0.12, 0.03, 'neon_amber')
    mb.finish("Basin_Shores", cw)

def build_far(C, rng, stats):
    """layered skyline: far shore + distant blocks, merged into chunk meshes"""
    cbg = C['Skyline']
    n_b = 0
    def chunk(name, x0, x1, y0, y1, step, hmin, hmax, hpow=1.5, low=False, far_lod=None):
        far_lod = (1 if low else 0) if far_lod is None else far_lod       # V3: 0 mid-detail, 1 far, 2 distant (progressively less emissive)
        nonlocal n_b
        mb = MB()
        y = y0
        while y < y1:
            x = x0
            while x < x1:
                w = rng.uniform(16, 34); d = rng.uniform(16, 34)
                px, py = x + rng.uniform(-4, 4), y + rng.uniform(-4, 4)
                # height profile: taller towards centre-north
                h = hmin + (hmax - hmin) * (rng.random() ** hpow)
                if rng.random() < 0.06:
                    h *= 1.6
                rect = (px - w / 2, py - d / 2, px + w / 2, py + d / 2)
                hh = fit_height(rect, h) if (abs(px) < 340 and abs(py) < 340) else h
                if any(math.hypot(px - hx, py - hy) < 24 for (hx, hy, hz) in HWY_PTS if hz > 5):
                    x += step; continue
                C2.tower2(mb, px, py, w, d, hh, rng, far=far_lod, accent=(rng.choice([None, None, None, None, 'neon_cyan', 'neon_amber', 'neon_violet']) if not far_lod else None), detail=False)
                n_b += 1
                x += step
            y += step
        mb.finish(name, cbg)
    # far shore: land slab + quay, then four depth layers (LOD: L1 mid-detail, L2-L4 box/frustum only)
    mb = MB()
    mb.box(100, 480, -0.9, 2000, 460, 0.65, 'ground', mtop='ground')
    mb.box(100, SHORE_Y + 0.5, -1.6, 2000, 1.0, 1.9, 'concrete', mtop='graphite')
    gq(mb, -900, SHORE_Y + 1.0, 1100, SHORE_Y + 1.2, 0.12, 'neon_cyan')
    mb.box(100, SHORE_Y + 8, -0.25, 2000, 14, 0.4, 'sidewalk')
    mb.finish("FarShore_Land", cbg)
    chunk("Skyline_FarShore_L1", -520, 940, SHORE_Y + 18, SHORE_Y + 70, 34, 30, 105, 1.6, far_lod=False)
    chunk("Skyline_FarShore_L2", -560, 960, SHORE_Y + 90, SHORE_Y + 150, 44, 45, 165, 1.4, low=True)
    chunk("Skyline_FarShore_L3", -600, 1000, SHORE_Y + 180, SHORE_Y + 250, 52, 60, 210, 1.3, low=True, far_lod=2)
    chunk("Skyline_FarShore_L4", -700, 1100, SHORE_Y + 290, SHORE_Y + 340, 70, 50, 170, 1.2, low=True, far_lod=2)
    # east / west / south distant blocks (low detail)
    chunk("Skyline_East_Distant", 450, 900, -200, 240, 56, 25, 120, 1.6, low=True, far_lod=2)
    chunk("Skyline_West_Distant", -900, -450, -200, 240, 56, 25, 120, 1.6, low=True, far_lod=2)
    chunk("Skyline_South_Distant", -450, 450, -520, -210, 60, 12, 55, 1.6, low=True, far_lod=2)
    # mountain ridge on the horizon (3 low-poly silhouettes, unlit dusk colour)
    mb = MB()
    for (yy, hh, col) in ((830, 170, "ridge_far"), (740, 110, "ridge_near")):
        x = -900.0
        while x < 900:
            wv = rng.uniform(90, 200); hv = hh * rng.uniform(0.35, 1.0)
            mb.frustum(x, yy, -1, wv, 90, wv * 0.12, 30, hv, col, uv=None)
            x += wv * 0.55
    mb.finish("Mountain_Ridge", C['Atmosphere'])
    # landmark towers (layered across the bay + two on the near shore)
    mb = MB()
    C2.lm_crown(mb, -60, SHORE_Y + 40, rng, 215, 34)
    C2.lm_twist(mb, 255, SHORE_Y + 44, rng, 235, 30)
    landmark_twin(mb, 105, SHORE_Y + 105, rng, 210)
    landmark_led(mb, -235, SHORE_Y + 36, rng, 190)
    C2.lm_cyl(mb, 520, SHORE_Y + 120, rng, 240, 14)
    C2.lm_crescent(mb, -400, SHORE_Y + 20, rng, 250, 60, 150, 16, rot=-90)
    C2.lm_needle(mb, 20, SHORE_Y + 200, rng, 330, 13)
    C2.lm_crescent(mb, 330, SHORE_Y + 130, rng, 205, 44, 160, 14, rot=-60)
    mb.finish("Landmark_Towers_FarShore", cbg)
    mb = MB()
    r = (-232, 68, -190, 98)
    C2.lm_crown(mb, -210, 82, rng, fit_height(r, 150), 24)
    r2 = (205, 66, 262, 104)
    C2.lm_needle(mb, 372, 90, rng, 150, 9) if not occludes((364, 82, 380, 98), 150) else None
    mb.finish("Landmark_Towers_NearShore", cbg)
    stats['far_buildings'] = n_b

def build_sky(C):
    mb = MB()
    R = 1300.0
    nlon, nlat = 24, 12
    for j in range(nlat):
        for i in range(nlon):
            def pt(ii, jj):
                lon = 2 * math.pi * ii / nlon
                lat = -math.pi / 2 + math.pi * jj / nlat
                return (R * math.cos(lat) * math.cos(lon), R * math.cos(lat) * math.sin(lon), R * math.sin(lat))
            def uv(ii, jj):
                return (ii / nlon, jj / nlat)
            # inward-facing (normal toward centre)
            mb.quad(pt(i, j), pt(i, j + 1), pt(i + 1, j + 1), pt(i + 1, j), 'sky_gradient',
                    uvs=[uv(i, j), uv(i, j + 1), uv(i + 1, j + 1), uv(i + 1, j)])
    ob = mb.finish("Sky_Dome", C['Atmosphere'])
    ob.visible_shadow = False; ob.visible_glossy = False; ob.visible_diffuse = False
    return ob
