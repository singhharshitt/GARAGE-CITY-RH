# Performance results (SOFTWARE rendering only)

SOFTWARE rendering (SwiftShader/ANGLE CPU WebGL, headless Chrome). Relative comparisons only. Real-device FPS (30 min / 60 target) is UNVERIFIED.

Harness: `tools/perf/perf_run.mjs` + `perf.html` (puppeteer-core, headless Chrome with `--use-angle=swiftshader`), static local server, three r169, gameplay camera `CAM_Game_Perspective`, GLB loaded via GLTFLoader (+Meshopt/Draco/KTX2 loaders as needed). Frame time = `renderer.render` + a 1-pixel `readPixels` sync, after 5 warm-up frames. `renderer.info` values are for the last rendered frame (they include the shadow pass when shadows are on). Download is from localhost (not a network measurement). V2 and V3 run under the same harness, machine and settings; one run per row (no repeats), so differences of a few % are noise.

## A. Load check of every variant in the browser (1 frame, balanced mode)

| config | res | mode | GLB MB | download ms | parse+tex ms | heap Δ MB | draw calls | tris | geoms | tex | frame median ms | p95 ms | N |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| V2 combined GLB | 1280x720 | balanced(1 frame) | 10.85 | 73.1 | 61.2 | 36.9 | 532 | 138331 | 525 | 15 | 206.3 | 206.3 | 1 |
| V3 compat combined GLB | 1280x720 | balanced(1 frame) | 10.78 | 71 | 74.6 | 37.7 | 493 | 157925 | 489 | 19 | 227.2 | 227.2 | 1 |
| V3 optimized (instancing+meshopt) | 1280x720 | balanced(1 frame) | 3.53 | 27.4 | 78.1 | 19.9 | 533 | 138218 | 438 | 19 | 226.8 | 226.8 | 1 |
| V3 optimized + KTX2 | 1280x720 | balanced(1 frame) | 3.47 | 25.3 | 264.2 | 24.4 | 533 | 138218 | 438 | 19 | 250 | 250 | 1 |
| V3 optimized + Draco | 1280x720 | balanced(1 frame) | 2.04 | 21.1 | 109.5 | 19.6 | 541 | 138914 | 438 | 19 | 220.5 | 220.5 | 1 |

## B. Same-conditions baseline: quality 0 (one hemisphere + one directional light, no shadows, no LOD, no tone mapping)

| config | res | mode | GLB MB | download ms | parse+tex ms | heap Δ MB | draw calls | tris | geoms | tex | frame median ms | p95 ms | N |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| V1 combined GLB | 1280x720 | quality 0 (hemi+sun, no shadow/LOD/tonemap) | 4.56 | 37.4 | 72.4 | 23.9 | 1124 | 74457 | 352 | 6 | 104.6 | 129 | 30 |
| V2 combined GLB | 1280x720 | quality 0 (hemi+sun, no shadow/LOD/tonemap) | 10.85 | 66.2 | 60 | 36.7 | 532 | 138331 | 525 | 14 | 120.1 | 129.4 | 30 |
| V3 compat combined GLB | 1280x720 | quality 0 (hemi+sun, no shadow/LOD/tonemap) | 10.78 | 56.4 | 66 | 36.2 | 493 | 157925 | 489 | 18 | 134.6 | 173.7 | 30 |
| V3 optimized (instancing+meshopt) | 1280x720 | quality 0 (hemi+sun, no shadow/LOD/tonemap) | 3.53 | 27.3 | 72.1 | 19.7 | 577 | 144137 | 438 | 18 | 138.7 | 149 | 30 |
| V3 optimized + KTX2 | 1280x720 | quality 0 (hemi+sun, no shadow/LOD/tonemap) | 3.47 | 28.4 | 261.6 | 24.5 | 577 | 144137 | 438 | 18 | 144.5 | 158.3 | 30 |
| V3 optimized + Draco | 1280x720 | quality 0 (hemi+sun, no shadow/LOD/tonemap) | 2.04 | 16.5 | 118.7 | 20.3 | 581 | 144533 | 438 | 18 | 137.9 | 144.2 | 30 |
| V1 combined GLB | 800x450 | quality 0 (hemi+sun, no shadow/LOD/tonemap) | 4.56 | 34.7 | 71.9 | 23.9 | 1124 | 74457 | 352 | 6 | 59.8 | 68.7 | 30 |
| V2 combined GLB | 800x450 | quality 0 (hemi+sun, no shadow/LOD/tonemap) | 10.85 | 64.3 | 65.1 | 36.4 | 532 | 138331 | 525 | 14 | 75.5 | 79.7 | 30 |
| V3 compat combined GLB | 800x450 | quality 0 (hemi+sun, no shadow/LOD/tonemap) | 10.78 | 63.8 | 62.1 | 35.6 | 493 | 157925 | 489 | 18 | 93.6 | 100.9 | 30 |
| V3 optimized (instancing+meshopt) | 800x450 | quality 0 (hemi+sun, no shadow/LOD/tonemap) | 3.53 | 30.2 | 81.6 | 19.9 | 577 | 144137 | 438 | 18 | 91.9 | 113.9 | 30 |
| V3 optimized + KTX2 | 800x450 | quality 0 (hemi+sun, no shadow/LOD/tonemap) | 3.47 | 34.9 | 275.9 | 24.5 | 577 | 144137 | 438 | 18 | 88.8 | 100.1 | 30 |
| V3 optimized + Draco | 800x450 | quality 0 (hemi+sun, no shadow/LOD/tonemap) | 2.04 | 20.3 | 104.1 | 19.5 | 581 | 144533 | 438 | 18 | 85.5 | 96 | 30 |

## C. Shipped quality modes, V2 file vs V3 optimized file (same quality_modes.js applied to both)

| config | res | mode | GLB MB | download ms | parse+tex ms | heap Δ MB | draw calls | tris | geoms | tex | frame median ms | p95 ms | N |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| V2 combined GLB | 1280x720 | full | 10.85 | 59.1 | 63.8 | 36.7 | 532 | 138331 | 525 | 15 | 195.5 | 203.6 | 12 |
| V3 optimized (instancing+meshopt) | 1280x720 | full | 3.53 | 27.1 | 75.6 | 20.1 | 577 | 144137 | 438 | 19 | 233 | 258.5 | 12 |
| V2 combined GLB | 1280x720 | balanced | 10.85 | 58.9 | 64.2 | 36.8 | 532 | 138331 | 525 | 15 | 196 | 227.6 | 30 |
| V3 optimized (instancing+meshopt) | 1280x720 | balanced | 3.53 | 26.5 | 72.8 | 19.8 | 533 | 138218 | 438 | 19 | 241.9 | 276.5 | 30 |
| V2 combined GLB | 1280x720 | low | 10.85 | 70.1 | 63.8 | 36.2 | 532 | 138331 | 525 | 14 | 77.2 | 85.3 | 30 |
| V3 optimized (instancing+meshopt) | 1280x720 | low | 3.53 | 29 | 74.5 | 19.7 | 509 | 133791 | 438 | 18 | 89.1 | 98.5 | 30 |
| V2 combined GLB | 800x450 | full | 10.85 | 58.3 | 62.1 | 36.4 | 532 | 138331 | 525 | 15 | 114.6 | 125.9 | 12 |
| V3 optimized (instancing+meshopt) | 800x450 | full | 3.53 | 35.8 | 98.3 | 19.7 | 577 | 144137 | 438 | 19 | 164 | 189.4 | 12 |
| V2 combined GLB | 800x450 | balanced | 10.85 | 69.3 | 59.2 | 37.1 | 532 | 138331 | 525 | 15 | 170.8 | 287.6 | 30 |
| V3 optimized (instancing+meshopt) | 800x450 | balanced | 3.53 | 76.9 | 125.4 | 19.8 | 533 | 138218 | 438 | 19 | 172.8 | 199.4 | 30 |
| V2 combined GLB | 800x450 | low | 10.85 | 93 | 74.1 | 36.3 | 532 | 138331 | 525 | 14 | 50.3 | 55 | 30 |
| V3 optimized (instancing+meshopt) | 800x450 | low | 3.53 | 36.9 | 92.2 | 19.7 | 509 | 133791 | 438 | 18 | 61.4 | 71.4 | 30 |
