"""blender -b garage_city_environment.blend --python render_preview.py -- <camera> <out.png> [w h samples]"""
import bpy, sys
a = sys.argv[sys.argv.index('--') + 1:]
cam, out = a[0], a[1]
w = int(a[2]) if len(a) > 2 else 1600
h = int(a[3]) if len(a) > 3 else 900
smp = int(a[4]) if len(a) > 4 else 32
sc = bpy.context.scene
sc.camera = bpy.data.objects[cam]
sc.render.engine = 'BLENDER_EEVEE_NEXT'
sc.eevee.taa_render_samples = smp
sc.render.resolution_x, sc.render.resolution_y = w, h
sc.render.resolution_percentage = 100
sc.render.filepath = out
sc.render.image_settings.file_format = 'PNG'
bpy.ops.render.render(write_still=True)
