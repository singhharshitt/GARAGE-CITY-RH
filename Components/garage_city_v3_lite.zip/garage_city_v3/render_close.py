"""blender -b garage_city_environment.blend --python render_close.py -- x y z ortho_scale out.png [w h samples]"""
import bpy, sys
from mathutils import Vector
a = sys.argv[sys.argv.index('--') + 1:]
tx, ty, tz, scl, out = float(a[0]), float(a[1]), float(a[2]), float(a[3]), a[4]
w = int(a[5]) if len(a) > 5 else 1280; h = int(a[6]) if len(a) > 6 else 720; smp = int(a[7]) if len(a) > 7 else 16
cam = bpy.data.objects['CAM_Game_Isometric_Ortho']
d = cam.location - Vector((0, 8, 0))
cam.location = Vector((tx, ty, tz)) + d
cam.data.ortho_scale = scl
sc = bpy.context.scene; sc.camera = cam
sc.render.engine = 'BLENDER_EEVEE_NEXT'
sc.render.resolution_x, sc.render.resolution_y = w, h
sc.eevee.taa_render_samples = smp
sc.render.filepath = out
bpy.ops.render.render(write_still=True)
