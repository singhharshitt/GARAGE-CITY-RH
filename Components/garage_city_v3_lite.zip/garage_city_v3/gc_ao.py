"""V3 baked AO-style shading: per-corner vertex colour 'Col' (exported as COLOR_0, multiplied into baseColor only,
so emissive surfaces are never darkened).  Pure Blender/bmesh/BVH; no textures, no lightmap atlas."""
import bpy, bmesh, math, re, time
from mathutils import Vector
from mathutils.bvhtree import BVHTree

NO_VCOL_MAT = re.compile(r'(neon|glow|lamp|sky|water|glass|refl|floor_light|light_|emit|halo)', re.I)
SKIP_OBJ = re.compile(r'^(SLOT_|Sky_Dome|Water_Surface|Mountain_Ridge|FarShore|Skyline_(FarShore|South_Distant|East_Distant|West_Distant)|Landmark_Towers_FarShore|Floor_Glow)')
PROP = re.compile(r'^(palm[0-2]|tree[01]|cypress|bush|shrub|planter_s|plazalight|bollard|sign|streetlight)_\d+(\.\d+)?$')

def _white(me):
    if 'Col' not in me.color_attributes:
        a = me.color_attributes.new('Col', 'BYTE_COLOR', 'CORNER')
        a.data.foreach_set('color', [1.0] * (4 * len(me.loops)))
    me.color_attributes.active_color = me.color_attributes['Col']
    me.color_attributes.render_color_index = me.color_attributes.find('Col')

def ensure_all_cols():
    for me in bpy.data.meshes:
        _white(me)

def proto_height_ao(me, lo=0.55, mats=('foliage', 'foliage_b', 'palm_leaf', 'planter')):
    """cheap fake AO for the shared prop meshes: foliage darkens towards the trunk/inside"""
    _white(me)
    zs = [v.co.z for v in me.vertices]
    zmax = max(zs) or 1.0
    col = me.color_attributes['Col']
    vals = []
    midx = {i: (m.name if m else '') for i, m in enumerate(me.materials)}
    for p in me.polygons:
        nm = midx.get(p.material_index, '')
        f = any(k in nm for k in mats)
        for li in p.loop_indices:
            z = me.vertices[me.loops[li].vertex_index].co.z
            g = lo + (1 - lo) * min(1.0, max(0.0, z / zmax)) ** 0.7 if f else 0.82 + 0.18 * min(1.0, z / zmax)
            vals += [g, g, g, 1.0]
    col.data.foreach_set('color', vals)

def install_vcol_nodes(mats):
    """multiply Color Attribute 'Col' into Principled Base Color for every non-emissive-type material"""
    n = 0
    for m in mats:
        if NO_VCOL_MAT.search(m.name) or not m.use_nodes:
            continue
        nt = m.node_tree
        pr = next((x for x in nt.nodes if x.type == 'BSDF_PRINCIPLED'), None)
        if pr is None: continue
        bc = pr.inputs['Base Color']
        ca = nt.nodes.new('ShaderNodeVertexColor'); ca.layer_name = 'Col'; ca.location = (-600, 200)
        mx = nt.nodes.new('ShaderNodeMix'); mx.data_type = 'RGBA'; mx.blend_type = 'MULTIPLY'; mx.location = (-350, 250)
        mx.inputs[0].default_value = 1.0
        if bc.is_linked:
            src = bc.links[0].from_socket
            nt.links.new(src, mx.inputs[6])
        else:
            mx.inputs[6].default_value = bc.default_value
        nt.links.new(ca.outputs['Color'], mx.inputs[7])
        nt.links.new(mx.outputs[2], bc)
        n += 1
    return n

def subdivide_up_faces(obs, min_area=18.0, max_area=25000.0, maxlen=2.6, max_passes=7):
    added = 0
    for ob in obs:
        me = ob.data
        bm = bmesh.new(); bm.from_mesh(me)
        if not any(f.normal.z > 0.9 and min_area < f.calc_area() < max_area for f in bm.faces):
            bm.free(); continue
        n0 = len(bm.faces)
        for _ in range(max_passes):
            ed = set()
            for f in bm.faces:
                if f.normal.z > 0.9 and min_area < f.calc_area() < max_area and len(f.verts) == 4:
                    if max(e.calc_length() for e in f.edges) > maxlen:
                        ed.update(f.edges)
            if not ed: break
            bmesh.ops.subdivide_edges(bm, edges=list(ed), cuts=1, use_grid_fill=True)
        bm.to_mesh(me); bm.free()
        added += len(me.polygons) - n0
    return added

def bake_vertex_ao(targets, occluders, rays=8, dist=4.5, lo=0.40, log=print):
    t0 = time.time()
    dg = bpy.context.evaluated_depsgraph_get()
    verts, polys = [], []
    for ob in occluders:
        ev = ob.evaluated_get(dg); me = ev.to_mesh()
        mw = ob.matrix_world
        base = len(verts)
        verts += [mw @ v.co for v in me.vertices]
        me.calc_loop_triangles()
        polys += [tuple(base + i for i in t.vertices) for t in me.loop_triangles]
        ev.to_mesh_clear()
    bvh = BVHTree.FromPolygons(verts, polys)
    log("AO bvh tris=%d (%.1fs)" % (len(polys), time.time() - t0))
    # cosine-weighted hemisphere samples (z up) - fixed stratified set, rotated per key
    S = []
    for i in range(rays):
        u = (i + 0.5) / rays; a = i * 2.399963
        r = math.sqrt(u); S.append((r * math.cos(a), r * math.sin(a), math.sqrt(1 - u)))
    stat = dict(loops=0, unique=0)
    for ob in targets:
        me = ob.data
        _white(me)
        mw = ob.matrix_world; nm = mw.to_3x3().inverted_safe().transposed()
        cache = {}; vals = [1.0] * (4 * len(me.loops))
        for p in me.polygons:
            n = (nm @ p.normal).normalized()
            t = n.cross(Vector((0, 0, 1)) if abs(n.z) < 0.9 else Vector((1, 0, 0))).normalized(); b = n.cross(t)
            for li in p.loop_indices:
                co = mw @ me.vertices[me.loops[li].vertex_index].co
                key = (round(co.x, 2), round(co.y, 2), round(co.z, 2), round(n.x, 1), round(n.y, 1), round(n.z, 1))
                v = cache.get(key)
                stat['loops'] += 1
                if v is None:
                    stat['unique'] += 1
                    o = co + n * 0.06
                    ph = (hash(key) % 628) / 100.0; c, s = math.cos(ph), math.sin(ph)
                    occ = 0.0
                    for (sx, sy, sz) in S:
                        x2, y2 = sx * c - sy * s, sx * s + sy * c
                        d = (t * x2 + b * y2 + n * sz)
                        hit = bvh.ray_cast(o, d, dist)
                        if hit[0] is not None:
                            occ += 1.0 - (hit[3] / dist) * 0.75
                    ao = 1.0 - occ / rays
                    v = lo + (1.0 - lo) * (ao ** 1.3)
                    cache[key] = v
                vals[4 * li] = vals[4 * li + 1] = vals[4 * li + 2] = v
        me.color_attributes['Col'].data.foreach_set('color', vals)
    log("AO baked: %s (%.1fs)" % (stat, time.time() - t0))
    return stat
