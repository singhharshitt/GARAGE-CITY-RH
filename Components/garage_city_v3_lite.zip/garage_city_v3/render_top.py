"""blender -b X.blend --python render_top.py -- cx cy scale out.png [w h samples]  top-down ortho map (inspection only)"""
import bpy, sys
a = sys.argv[sys.argv.index('--') + 1:]
cx, cy, scl, out = float(a[0]), float(a[1]), float(a[2]), a[3]
w = int(a[4]) if len(a) > 4 else 1280; h = int(a[5]) if len(a) > 5 else 720; smp = int(a[6]) if len(a) > 6 else 8
cd = bpy.data.cameras.new('topcam'); cd.type = 'ORTHO'; cd.ortho_scale = scl; cd.clip_end = 3000
ob = bpy.data.objects.new('topcam', cd); bpy.context.scene.collection.objects.link(ob)
ob.location = (cx, cy, 900); ob.rotation_euler = (0, 0, 0)
sc = bpy.context.scene; sc.camera = ob
sc.render.engine = 'BLENDER_EEVEE_NEXT'; sc.render.resolution_x, sc.render.resolution_y = w, h
sc.eevee.taa_render_samples = smp; sc.render.filepath = out
bpy.ops.render.render(write_still=True)
