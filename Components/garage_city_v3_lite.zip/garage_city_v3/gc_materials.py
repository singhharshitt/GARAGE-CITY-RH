from gc_lib import *

def build_materials():
    M = {}
    # --- textures (<=512px)
    # V3: restrained window palettes -- mostly warm/neutral white, pale cyan accents, violet only as a rare far-skyline accent
    PAL_COOL = [((0.80, 0.93, 1.0), .62), ((0.45, 0.82, 1.0), .16), ((1.0, 0.80, 0.50), .20), ((0.70, 0.50, 1.0), .02)]
    PAL_WARM = [((1.0, 0.74, 0.42), .60), ((1.0, 0.88, 0.66), .34), ((0.55, 0.85, 1.0), .06)]
    PAL_NEON = [((0.80, 0.93, 1.0), .55), ((0.45, 0.82, 1.0), .25), ((1.0, 0.76, 0.45), .13), ((0.85, 0.40, 0.95), .07)]
    t1 = make_window_tex("tex_windows_cool", PAL_COOL, 0.22, 1)
    t2 = make_window_tex("tex_windows_warm", PAL_WARM, 0.24, 2)
    t3 = make_window_tex("tex_windows_neon", PAL_NEON, 0.18, 3)
    t4 = make_window_band_tex("tex_windows_bands", PAL_COOL, 0.24, 4)
    t5 = make_window_curtain_tex("tex_windows_curtain", PAL_WARM, 0.22, 5)
    t6 = make_window_punch_tex("tex_windows_punched", PAL_WARM, 0.30, 6)
    t7 = make_window_fins_tex("tex_windows_fins", PAL_COOL, 0.30, 7)
    tsky = make_sky_tex("tex_sky_gradient")
    twat = make_water_tex("tex_water_ripple")

    # emission strength falls with distance: near 0.85 -> mid (far) 0.55 -> distant 0.34
    for nm, tx in (("cool", t1), ("warm", t2), ("neon", t3), ("band", t4), ("curtain", t5), ("punch", t6), ("fins", t7)):
        mat("win_" + nm, None, rough=0.4, metal=0.1, tex=tx, emit_tex=True, estr=0.70)
        mat("win_far_" + nm, None, rough=0.5, metal=0.0, tex=tx, emit_tex=True, estr=0.36)
        mat("win_dist_" + nm, None, rough=0.6, metal=0.0, tex=tx, emit_tex=True, estr=0.20)
    tglow = make_glow_tex("tex_glow_soft")
    for n, c in dict(cyan='#17c8ff', amber='#ff9a2a', magenta='#ff2cd2', violet='#8d3cff', blue='#2d6bff').items():
        g = mat("glow_" + n, c, rough=1.0, emit=c, estr=1.0, tex=tglow)
        nt = g.node_tree; b = nt.nodes["Principled BSDF"]
        tn = [n_ for n_ in nt.nodes if n_.type == 'TEX_IMAGE'][0]
        for l in list(nt.links):
            if l.to_socket == b.inputs["Base Color"]:
                nt.links.remove(l)
        b.inputs["Base Color"].default_value = (0, 0, 0, 1)
        b.inputs["Emission Color"].default_value = srgb(c); b.inputs["Emission Strength"].default_value = 1.0
        nt.links.new(tn.outputs["Alpha"], b.inputs["Alpha"])
        g.blend_method = 'BLEND'
        try:
            g.surface_render_method = 'BLENDED'
        except Exception:
            pass
        g.use_backface_culling = True
        g.show_transparent_back = False
    mat("sky_gradient", '#000000', unlit_tex=tsky)
    mat("water", None, rough=0.12, metal=0.0, tex=twat, emit_tex=True, estr=0.30)

    # V2: brighter, textured surfaces (all textures <= 256 px, tiling 3 m)
    tconc = make_concrete_tex("tex_concrete_light", (0.62, 0.66, 0.74), joints=4, contrast=0.10, seed=11)
    tyard = make_concrete_tex("tex_floor_yard", (0.46, 0.54, 0.68), joints=4, contrast=0.07, seed=12)
    tpave = make_concrete_tex("tex_paving", (0.56, 0.62, 0.74), joints=6, contrast=0.07, seed=13)
    tasph = make_asphalt_tex("tex_asphalt", (0.22, 0.26, 0.37))
    tbrush = make_brushed_tex("tex_brushed_steel", (0.62, 0.70, 0.78))
    tgraph = make_brushed_tex("tex_graphite_panel", (0.27, 0.31, 0.38), seed=9, panel=2)
    thaz = make_hazard_tex("tex_hazard")
    # V3 material differentiation: tonal concrete variants, dark structural steel, brushed trim, copper accent
    tconc_dk = make_concrete_tex("tex_concrete_dark", (0.36, 0.40, 0.48), joints=3, contrast=0.12, seed=21)
    tconc_wm = make_concrete_tex("tex_concrete_warm", (0.58, 0.57, 0.58), joints=4, contrast=0.09, seed=22)
    mat("concrete_dk", None, rough=0.85, tex=tconc_dk)
    mat("concrete_warm", None, rough=0.82, tex=tconc_wm)
    mat("structure_dark", '#1b212d', rough=0.38, metal=0.55)
    mat("cladding", None, rough=0.42, metal=0.35, tex=tgraph)
    mat("copper_trim", '#a9744c', rough=0.38, metal=0.7)
    mat("graphite", None, rough=0.45, metal=0.15, tex=tgraph)
    mat("graphite_dark", '#303746', rough=0.55, metal=0.15)
    mat("concrete", None, rough=0.85, tex=tconc)
    mat("paving", None, rough=0.55, metal=0.0, tex=tpave)
    mat("yard_dark", None, rough=0.5, metal=0.0, tex=tyard)
    mat("asphalt", None, rough=0.7, metal=0.0, tex=tasph)
    mat("sidewalk", '#6a7590', rough=0.7)
    mat("curb", '#8d97ab', rough=0.7)
    mat("ground", '#27304a', rough=0.9)
    mat("ridge_far", '#3a3470', rough=1.0, emit='#3a3470', estr=0.5)
    mat("ridge_near", '#2a2c5e', rough=1.0, emit='#2a2c5e', estr=0.5)
    mat("glass", '#12425e', rough=0.06, metal=0.3, emit='#1a7fa8', estr=0.35)
    # lightly tinted transparent glass (alpha-blended; exported as alphaMode BLEND)
    gt = mat("glass_tint", '#3aa6c4', rough=0.08, metal=0.0)
    gt.node_tree.nodes["Principled BSDF"].inputs["Alpha"].default_value = 0.22
    gt.blend_method = 'BLEND'
    try: gt.surface_render_method = 'BLENDED'
    except Exception: pass
    gt.use_backface_culling = False; gt.show_transparent_back = False
    mat("glass_warm", '#4d2d14', rough=0.1, metal=0.2, emit='#ff9d3d', estr=1.1)
    mat("metal_light", None, rough=0.42, metal=0.25, tex=tbrush)
    mat("steel_painted", '#566075', rough=0.5, metal=0.1)
    mat("steel_teal", '#2b6f80', rough=0.5, metal=0.1)
    mat("rubber", '#15171c', rough=0.95)
    mat("polymer", '#262b36', rough=0.6)
    mat("solar", '#12305a', rough=0.3, metal=0.2)
    mat("hazard", None, rough=0.6, tex=thaz)
    # warm amber interior shell (emissive walls/floor read as lit rooms from the game camera)
    mat("int_floor", '#8a7355', rough=0.7, emit='#ff9a3a', estr=0.22)
    mat("int_wall", '#b08a58', rough=0.8, emit='#ff9a3a', estr=0.36)
    mat("int_ceiling", '#7a6246', rough=0.9, emit='#ffb765', estr=0.5)
    mat("int_panel", '#ffd9a0', rough=0.6, emit='#ffc27a', estr=1.6)
    mat("int_dark", '#3a2e24', rough=0.8, emit='#ff9a3a', estr=0.15)
    mat("cabinet_orange", '#d46a1c', rough=0.5, metal=0.2)
    mat("cabinet_blue", '#2d5fa8', rough=0.5, metal=0.2)
    mat("tire", '#0f1013', rough=0.9)
    mat("terrace", '#566073', rough=0.6)
    mat("planter", '#464e5c', rough=0.7)
    mat("lawn", '#1f5a3c', rough=0.9)
    mat("foliage", '#176a40', rough=0.8)
    mat("foliage_b", '#1f8552', rough=0.8)
    mat("palm_leaf", '#1f8048', rough=0.7)
    mat("trunk", '#6d5b49', rough=0.9)
    mat("mark_white", '#cfd8e2', rough=0.5, emit='#cfd8e2', estr=0.35)
    mat("mark_yellow", '#e6b422', rough=0.5, emit='#e6b422', estr=0.8)
    for n, c in dict(cyan='#17e3ff', blue='#2d6bff', magenta='#ff2cd2', violet='#8d3cff', amber='#ffa52a', white='#eaf7ff').items():
        mat("neon_" + n, c, rough=0.4, emit=c, estr=1.7 if n != 'white' else 1.5)
    for n, c in dict(cyan='#17e3ff', magenta='#ff2cd2', amber='#ffa52a', violet='#8d3cff').items():
        mat("refl_" + n, c, rough=0.4, emit=c, estr=0.6)
    mat("lamp_warm", '#ffd9a0', rough=0.5, emit='#ffc27a', estr=5.0)
    return M
