// Garage City V3 - quality modes (Full desktop / Balanced / Low-end) for Three.js (r160+; developed against r169).
// ES module. Usage: see environment_manifest.md ("Loading & quality modes").
import * as THREE from 'three';

// ----- light values (taken from the Blender scene; tuned for Three's physical lights + AgX tone mapping)
export const LIGHTS = {
  sun:  { color: 0xffb083, intensity: 2.0, direction_to_light_gltf: [-0.545, 0.309, -0.779] },  // warm key, low sunset sun
  fill: { skyColor: 0x3b6fd6, groundColor: 0x10161f, intensity: 1.25 },                         // cool hemisphere fill
  exposure: 1.0, toneMapping: 'AgX',
  // authored scene light: Blender sun (1.0,0.55,0.32) E=3.4, rot (72deg,0,215deg); blue sky-fill sun; World_BlueHour ambient.
};

// ----- per-mode configuration
export const QUALITY = {
  full: {      // modern desktop / 60 fps-capable GPUs
    pixelRatioCap: 2.0, antialias: true,
    shadows: { enabled: true, mapSize: 2048, extent_m: 110, type: 'PCFSoft' },
    cullDistances_m: { props: 700, city_chunks: Infinity, far_skyline: Infinity, distant_chunks: Infinity },
    toneMapping: true,
  },
  balanced: {  // mid-range laptops / integrated GPUs
    pixelRatioCap: 1.25, antialias: true,
    shadows: { enabled: true, mapSize: 1024, extent_m: 90, type: 'PCF' },
    cullDistances_m: { props: 320, city_chunks: 900, far_skyline: Infinity, distant_chunks: 1400 },
    toneMapping: true,
  },
  low: {       // low-end / mobile target (30 fps minimum goal - UNVERIFIED on real hardware)
    pixelRatioCap: 1.0, antialias: false,
    shadows: { enabled: false },
    cullDistances_m: { props: 190, city_chunks: 520, far_skyline: 900, distant_chunks: 700 },
    toneMapping: false,   // Standard sRGB output, cheapest path (no post-processing in any mode)
  },
};

// object-name rules (the GLB node names are stable: they come from the Blender object names)
const RULES = [
  [/^(Inst_)?(palm|tree|cypress|bush|shrub|planter|plazalight|bollard|sign|streetlight)/i, 'props'],
  [/^(Skyline_(South|East|West)_Distant|Mountain_Ridge)/, 'distant_chunks'],
  [/^(Skyline_FarShore_L[34]|Landmark_Towers_FarShore|FarShore)/, 'far_skyline'],
  [/^Chunk_City_Background_/, 'city_chunks'],
];

export class DistanceLOD {
  /** hide-by-distance scheme: every matching object gets a bounding sphere once; update(camera) toggles .visible */
  constructor(root, cullDistances) {
    this.items = []; this.cfg = cullDistances;
    const box = new THREE.Box3(), sph = new THREE.Sphere();
    root.updateMatrixWorld(true);
    const visit = (o) => {
      for (const [re, key] of RULES) if (re.test(o.name || '')) {
        box.setFromObject(o); if (box.isEmpty()) return; box.getBoundingSphere(sph);
        this.items.push({ o, key, c: sph.center.clone(), r: sph.radius }); return;   // do not descend (children follow the parent)
      }
      for (const c of o.children) visit(c);
    };
    visit(root);
    this._frame = 0;
  }
  update(camera, every = 8) {
    if ((this._frame++ % every) !== 0) return 0;
    let hidden = 0; const p = camera.position;
    for (const it of this.items) {
      const lim = this.cfg[it.key]; const vis = !(isFinite(lim) && p.distanceTo(it.c) - it.r > lim);
      it.o.visible = vis; if (!vis) hidden++;
    }
    return hidden;
  }
}

export function applyQuality(renderer, scene, camera, key, opts = {}) {
  const q = QUALITY[key]; if (!q) throw new Error('unknown quality ' + key);
  renderer.setPixelRatio(Math.min(opts.devicePixelRatio ?? (globalThis.devicePixelRatio || 1), q.pixelRatioCap));
  renderer.toneMapping = q.toneMapping ? THREE.AgXToneMapping : THREE.NoToneMapping;
  renderer.toneMappingExposure = LIGHTS.exposure;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  // lights (one directional + one hemisphere; nothing else is needed - emissives are authored into the materials)
  const sun = new THREE.DirectionalLight(LIGHTS.sun.color, LIGHTS.sun.intensity);
  const d = new THREE.Vector3(...LIGHTS.sun.direction_to_light_gltf).normalize();
  sun.position.copy(d.clone().multiplyScalar(300)); sun.target.position.set(0, 0, 0);
  const hemi = new THREE.HemisphereLight(LIGHTS.fill.skyColor, LIGHTS.fill.groundColor, LIGHTS.fill.intensity);
  scene.add(sun, sun.target, hemi);
  renderer.shadowMap.enabled = !!q.shadows.enabled;
  if (q.shadows.enabled) {
    renderer.shadowMap.type = q.shadows.type === 'PCFSoft' ? THREE.PCFSoftShadowMap : THREE.PCFShadowMap;
    sun.castShadow = true; sun.shadow.mapSize.set(q.shadows.mapSize, q.shadows.mapSize);
    const e = q.shadows.extent_m, c = sun.shadow.camera;
    c.left = -e; c.right = e; c.top = e; c.bottom = -e; c.near = 10; c.far = 700; sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.4;
    // only the garage compound casts/receives real-time shadows (everything else is baked-AO + emissive)
    scene.traverse((o) => {
      if (!o.isMesh) return;
      const n = o.name || '', p = o.parent?.name || '';
      const near = /^(Chunk_Garage_Core|PropChunk_Garage_Core|Bld_|Yard_Ground|Showcase|Display|Lifts|Fuel|EV_|Gate|N1_|Facade|Skybridge|Elevators)/.test(n) || /^(Chunk_Garage_Core|PropChunk_Garage_Core|Bld_|Yard_|Inst_(palm|tree|cypress|bush))/.test(p);
      o.castShadow = near; o.receiveShadow = near;
    });
  }
  const lod = new DistanceLOD(scene, q.cullDistances_m);
  return { sun, hemi, lod, config: q };
}
