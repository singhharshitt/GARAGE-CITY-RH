"""Export-time batching.  The saved .blend keeps every editable object/instance; right before the GLBs are written the
live scene is merged into per-material spatial chunks (static small props, instanced palms/lamps/bollards, buildings ...).
Slot Empties, cameras and a short list of key named components are never merged."""
import bpy, bmesh, re, math
from mathutils import Vector

KEEP = re.compile(r'^(Showcase_Platform_Central|Display_Platforms|Lifts_Repair_Bays|Fuel_Canopy_Pumps|EV_Canopy_Chargers|Skybridge|Elevators|'
                  r'Sky_Dome|Water_Surface|Mountain_Ridge|Landmark_|Skyline_|FarShore|HWY|RAMP|Bridge_|Ground_Base|Road_|Canal_|Bridges_|Promenade_Quay)')

def _bbox(ob):
    pts = [ob.matrix_world @ Vector(c) for c in ob.bound_box]
    lo = Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts)))
    hi = Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts)))
    return lo, hi

import gc_ao
def merge_collection_chunks(colls, core_names=('01_Garage_Core',), big_core=60.0, big_other=260.0, cell=600.0, log=None,
                            props='keep'):
    """props='keep'  -> repeated props (palms/trees/lamps/...) are left as separate nodes sharing one mesh (for GPU instancing)
       props='only'  -> merge ONLY the repeated props (second pass, for the non-instanced compatibility export)
       props='merge' -> merge everything (V2 behaviour)"""
    dg = bpy.context.evaluated_depsgraph_get()
    report = {}
    for top in colls:
        is_core = top.name in core_names
        groups = {}
        for ob in list(top.all_objects):
            if ob.type != 'MESH' or ob.name.startswith('SLOT_') or KEEP.match(re.sub(r'\.\d+$', '', ob.name)):
                continue
            is_prop = bool(gc_ao.PROP.match(ob.name))
            if (props == 'keep' and is_prop) or (props == 'only' and not is_prop):
                continue
            lo, hi = _bbox(ob)
            size = max(hi.x - lo.x, hi.y - lo.y)
            if size > (big_core if is_core else big_other):
                continue
            c = (lo + hi) / 2
            if is_core:
                key = 'ALL'   # V3: the compound is one batch (always on screen in both game cameras)
            else:
                key = '%d_%d' % (math.floor(c.x / cell), math.floor(c.y / cell))
            groups.setdefault(key, []).append(ob)
        n_before = sum(len(v) for v in groups.values()); n_after = 0
        for key, obs in sorted(groups.items()):
            if len(obs) < 2:
                continue
            bm = bmesh.new(); mats = []; names = []
            for ob in obs:
                ev = ob.evaluated_get(dg)
                me = bpy.data.meshes.new_from_object(ev, preserve_all_data_layers=True, depsgraph=dg)
                me.transform(ob.matrix_world)
                remap = []
                for m in me.materials:
                    if m not in mats: mats.append(m)
                    remap.append(mats.index(m))
                n0 = len(bm.faces)
                bm.from_mesh(me)
                bm.faces.ensure_lookup_table()
                for f in bm.faces[n0:]:
                    f.material_index = remap[f.material_index] if f.material_index < len(remap) else 0
                bpy.data.meshes.remove(me)
                names.append(ob.name)
            me = bpy.data.meshes.new("%s_%s_%s" % ("PropChunk" if props == "only" else "Chunk", top.name[3:] if top.name[:2].isdigit() else top.name, key))
            bm.to_mesh(me); bm.free()
            for m in mats: me.materials.append(m)
            ob2 = bpy.data.objects.new(me.name, me)
            host = obs[0].users_collection[0]
            host.objects.link(ob2)
            ob2['merged_chunk'] = True; ob2['merged_object_count'] = len(obs)
            ob2['merged_sources_sample'] = ", ".join(sorted(set(re.sub(r'[._]?\d+$', '', n) for n in names))[:24])
            ob2['chunk_key'] = key
            for ob in obs:
                bpy.data.objects.remove(ob, do_unlink=True)
            n_after += 1
        report[top.name] = dict(objects_merged=n_before, chunks=n_after)
        if log: log(top.name, report[top.name])
    # purge orphan meshes so the exporter / stats don't see them
    for me in [m for m in bpy.data.meshes if m.users == 0]:
        bpy.data.meshes.remove(me)
    return report
