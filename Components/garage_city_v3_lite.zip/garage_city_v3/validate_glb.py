"""python3 validate_glb.py   (needs numpy; trimesh optional; node + gltf-validator optional)
Parses each GLB itself (instances counted), re-loads with trimesh, runs gltf-validator, checks Y-up, vehicle names, SLOT empties."""
import json, struct, sys, os, re, subprocess, numpy as np
D = os.path.dirname(os.path.abspath(__file__))
BASE = ['garage_city_environment', 'garage_core', 'roads_and_highways', 'city_background', 'waterfront']
FILES = [b + '.glb' for b in BASE] + ['optimized/%s.opt.glb' % b for b in BASE] + ['optimized/%s.opt.ktx2.glb' % b for b in BASE] + ['optimized/garage_city_environment.opt.draco.glb']
BAD = re.compile(r'(\bcar\b|_car_|^car|vehicle|truck|\bbus\b|\bvan\b|motor|bike|bicycle|scooter|taxi|sedan|suv|coupe|wheel|tyre|chassis|traffic|automobile|lorry|pickup|limo)', re.I)
def load(path):
    b = open(path, 'rb').read()
    magic, ver, ln = struct.unpack('<4sII', b[:12])
    assert magic == b'glTF' and ver == 2 and ln == len(b)
    cl, ct = struct.unpack('<II', b[12:20]); js = json.loads(b[20:20 + cl])
    return js, len(b)
def mats(n):
    t = np.array(n.get('matrix', np.eye(4).T.flatten()), float).reshape(4, 4).T if 'matrix' in n else None
    if t is None:
        T = np.eye(4); T[:3, 3] = n.get('translation', [0, 0, 0])
        x, y, z, w = n.get('rotation', [0, 0, 0, 1])
        Rm = np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)], [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)], [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])
        S = np.diag(list(n.get('scale', [1, 1, 1])) + [1]); R4 = np.eye(4); R4[:3, :3] = Rm
        t = T @ R4 @ S
    return t
def analyse(js):
    nodes = js['nodes']; acc = js['accessors']
    parent = {}
    for i, n in enumerate(nodes):
        for c in n.get('children', []): parent[c] = i
    def world(i):
        m = mats(nodes[i]); 
        while i in parent:
            i = parent[i]; m = mats(nodes[i]) @ m
        return m
    tris = 0; lo = np.full(3, 1e18); hi = np.full(3, -1e18); ninst = 0
    for i, n in enumerate(nodes):
        if 'mesh' not in n: continue
        W = world(i); ninst += 1
        for p in js['meshes'][n['mesh']]['primitives']:
            tris += (acc[p['indices']]['count'] if 'indices' in p else acc[p['attributes']['POSITION']]['count']) // 3
            a = acc[p['attributes']['POSITION']]
            mn, mx = np.array(a['min']), np.array(a['max'])
            cs = np.array([[x, y, z, 1] for x in (mn[0], mx[0]) for y in (mn[1], mx[1]) for z in (mn[2], mx[2])])
            wc = (W @ cs.T).T[:, :3]; lo = np.minimum(lo, wc.min(0)); hi = np.maximum(hi, wc.max(0))
    return tris, lo, hi, ninst
out = {}; total_unique = {}
for f in FILES:
    p = os.path.join(D, f)
    if not os.path.exists(p): out[f] = 'MISSING'; continue
    js, size = load(p)
    optimized = 'optimized/' in f
    if optimized:
        tris, lo, hi, ninst = 0, np.zeros(3), np.zeros(3), 0     # quantized + instanced: geometry is verified by the three.js loader tests instead
    else:
        tris, lo, hi, ninst = analyse(js)
    if True:
        names = [n.get('name', '') for n in js['nodes']] + [m.get('name', '') for m in js.get('materials', [])] + [m.get('name', '') for m in js['meshes']]
    r = dict(bytes=size, triangles_rendered=int(tris), mesh_nodes=ninst, nodes=len(js['nodes']), meshes=len(js['meshes']), materials=len(js.get('materials', [])),
             images=len(js.get('images', [])), cameras=len(js.get('cameras', [])),
             bounds_min_xyz_yup=[round(float(v), 1) for v in lo], bounds_max_xyz_yup=[round(float(v), 1) for v in hi],
             vehicle_name_hits=sorted({n for n in names if BAD.search(n)}),
             slot_nodes=sum(1 for n in js['nodes'] if n.get('name', '').startswith('SLOT_')),
             extensions=js.get('extensionsUsed', []))
    # image sizes (decode PNG header from bufferView)
    bl = open(p, 'rb').read(); cl = struct.unpack('<I', bl[12:16])[0]; binoff = 20 + cl + 8
    mx = 0
    for im in js.get('images', []):
        bv = js['bufferViews'][im['bufferView']]; o = binoff + bv.get('byteOffset', 0)
        if im.get('mimeType') == 'image/png':
            w, h = struct.unpack('>II', bl[o + 16:o + 24]); mx = max(mx, w, h)
        elif im.get('mimeType') == 'image/ktx2':
            w, h = struct.unpack('<II', bl[o + 20:o + 28]); mx = max(mx, w, h)     # KTX2 header: pixelWidth/pixelHeight at byte 20/24
    r['max_image_px'] = mx
    r['textures_all_embedded'] = all('bufferView' in im for im in js.get('images', []))
    acc = js['accessors']
    r['uses_EXT_mesh_gpu_instancing'] = 'EXT_mesh_gpu_instancing' in js.get('extensionsUsed', [])
    r['instanced_nodes'] = sum(1 for n in js['nodes'] if 'EXT_mesh_gpu_instancing' in n.get('extensions', {}))
    r['instances_total'] = sum(acc[n['extensions']['EXT_mesh_gpu_instancing']['attributes']['TRANSLATION']]['count'] for n in js['nodes'] if 'EXT_mesh_gpu_instancing' in n.get('extensions', {}))
    try:
        if optimized: raise RuntimeError('trimesh cannot decode meshopt/draco/instancing - skipped')
        import trimesh
        sc = trimesh.load(p, force='scene')
        r['trimesh_loaded'] = True; r['trimesh_geometries'] = len(sc.geometry)
        r['trimesh_bounds'] = [[round(float(v), 1) for v in row] for row in sc.bounds]
    except Exception as e:
        r['trimesh_loaded'] = 'n/a: %s' % e
    try:
        g = subprocess.run(['node', os.path.join(D, 'validate_glb.js'), p], capture_output=True, text=True, timeout=300)
        r['gltf_validator'] = json.loads(g.stdout) if g.stdout.strip() else g.stderr[:300]
    except Exception as e:
        r['gltf_validator'] = 'n/a: %s' % e
    out[f] = r
json.dump(out, open(os.path.join(D, 'validation_glb.json'), 'w'), indent=1)
for f, r in out.items():
    if isinstance(r, str): print(f, r); continue
    gv = r['gltf_validator']
    print(f, r['bytes'], 'tris', r['triangles_rendered'], 'nodes', r['nodes'], 'slots', r['slot_nodes'], 'cams', r['cameras'], 'maxpx', r['max_image_px'],
          'bounds', r['bounds_min_xyz_yup'], r['bounds_max_xyz_yup'], 'trimesh', r['trimesh_loaded'], 'veh', r['vehicle_name_hits'],
          'validator', (gv['numErrors'], gv['numWarnings']) if isinstance(gv, dict) else gv)
