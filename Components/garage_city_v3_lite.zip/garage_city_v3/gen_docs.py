"""python3 gen_docs.py  -> environment_manifest.md, COMPARISON_V1_V2_V3.md, validation_report.md  (reads the JSON outputs of the build/validators/perf runs).
Hand-written prose lives here; every number comes from a JSON file or a file size on disk."""
import json, os
D = os.path.dirname(os.path.abspath(__file__)); J = lambda p: json.load(open(f'{D}/{p}'))
sz = lambda p: os.path.getsize(f'{D}/{p}'); mb = lambda b: f'{b/1048576:.2f} MB'
S = J('slots.json'); I = J('scene_info.json'); VB = J('validation_blend.json'); VG = J('validation_glb.json'); VR = J('validation_glb_blender.json'); VT = J('validation_threejs_node.json')['files']
VC = J('validation_glb_three_clearance.json')['files']; NC = J('validation_negative_control.json'); OR = J('optimization_report.json')['files']; PF = J('perf_results.json')
SD1 = J('slot_diff_vs_v1.json'); SD2 = J('slot_diff_vs_v2.json'); SE = J('slot_empties_diff_vs_v1_v2.json'); ID = J('perf_results/image_diff_variants.json')['results']
ST = {v: {e['file']: e for e in J(f'stats_glb_{v}.json')} for v in ('V1', 'V2', 'V3')}
GL = ['garage_city_environment.glb', 'garage_core.glb', 'roads_and_highways.glb', 'city_background.glb', 'waterfront.glb']
OPTN = lambda f: 'optimized/' + f.replace('.glb', '.opt.glb'); KTXN = lambda f: 'optimized/' + f.replace('.glb', '.opt.ktx2.glb')
def pr(sect, key):
    for r in PF[sect]:
        if r['key'] == key: return r
q0 = lambda v, w: pr('baseline_quality0', f'q0_{v}_{w}'); md = lambda m, v, w: pr('quality_modes', f'mode_{m}_{v}_{w}')

# ------------------------------------------------------------------ manifest
L = []; A = L.append
A("# Garage City RH — V3 3D environment pack (empty, vehicle-free)\n")
A("V3 = polish pass on V2 (same layout, same 57 slot anchors, same coordinate system). Built by `run.sh` (Blender 4.2.3 LTS, Python/bmesh, fully procedural) + `tools/postprocess_glb.mjs` (gltf-transform). **No vehicles, motorcycles, traffic or silhouettes anywhere; all 57 slots are empty and unobstructed** (checked, §11). **No real-device performance testing was done — see `validation_report.md`.**\n")
A("## 1. Scene description\n")
A("* **Garage core (hierarchy 1):** walled compound around an open paved yard; glazed amber-lit showroom/workshop frontages with interiors (benches, cabinets, racks), taller workshop volumes with roof silhouettes (parapets, roof plant, vents), service block with stairs/skybridge elements, fuel and EV canopies, gate, planters and boundary hedges. **Central showcase:** layered circular platform with inset light rings, framing arches and lighting masts, strong contrast against the yard floor — still empty (the single `showcase` slot).\n"
  "* **Roads / highways:** road grid with lane markings, kerbs, sidewalks, junction crosswalks, elevated highway with pillars, barriers, expansion joints and ramps, roadside lights.\n"
  "* **City:** near blocks (rooftop mechanicals, some roof gardens), parks with a varied tree/palm/bush mix, layered far-shore skyline (landmark towers with distinct silhouettes, progressively simpler/less emissive with distance), distant chunks and mountain ridge, gradient sky dome tuned to sunset→blue hour.\n"
  "* **Waterfront:** quay/promenade edges and basin; water is a calm cheap material (no reflections). The basin is visible in the gameplay camera (a low north row and basin were added in V3 without touching slots or the original game cameras).\n")
A("Colour deviation from the concept brief: the four zone colours of the bay markings (cyan / amber / violet / magenta) are kept because they are gameplay readability cues from V1/V2; violet/magenta elsewhere is restricted to distant skyline accents.\n")
A("## 2. Files — which one to load (READ THIS)\n")
A("**Two interchangeable sets. Load exactly one set. Never load a combined file together with split files, and never load a compat file together with an optimized file** (they contain the same world content in the same coordinates; loading both duplicates everything).\n")
A("| set | files | extensions | decoders needed |\n|---|---|---|---|\n| **A. compat (V2-style, safest)** | `garage_city_environment.glb` (combined) or the 4 split: `garage_core.glb`, `roads_and_highways.glb`, `city_background.glb`, `waterfront.glb` | KHR_materials_emissive_strength, KHR_materials_specular only | none |\n| **B. optimized** | `optimized/garage_city_environment.opt.glb` (combined) or `optimized/{garage_core,roads_and_highways,city_background,waterfront}.opt.glb` | + KHR_mesh_quantization, EXT_mesh_gpu_instancing, EXT_meshopt_compression | MeshoptDecoder (+ three r150+ GLTFLoader) |\n| B+KTX2 | `optimized/*.opt.ktx2.glb` | + KHR_texture_basisu | MeshoptDecoder + KTX2Loader (basis transcoder) |\n| B+Draco (combined only) | `optimized/garage_city_environment.opt.draco.glb` | KHR_draco_mesh_compression (no meshopt) | DRACOLoader |\n")
A("| file | bytes | triangles (static) | primitives | materials | notes |\n|---|---:|---:|---:|---:|---|")
for f in GL:
    e = ST['V3'][f]; A(f"| {f} | {e['bytes']:,} | {e['triangles']:,} | {e['primitives_drawcalls_est']} | {e['materials']} | compat; props merged into spatial chunks |")
for f in GL:
    o = OR[f.replace('.glb', '')]; A(f"| {OPTN(f)} | {o['optimized']['bytes']:,} | {VT[OPTN(f)]['triangles']:,} (three.js, instances expanded) | – | – | instanced props + quantization + meshopt |")
for f in GL:
    k = OR[f.replace('.glb', '')]['optimized_ktx2']; A(f"| {KTXN(f)} | {k['bytes']:,} | same as opt | – | – | textures as KTX2 (UASTC/ETC1S via toktx) |")
A(f"| optimized/garage_city_environment.opt.draco.glb | {OR['garage_city_environment']['optimized_draco']['bytes']:,} | ≈ same (Draco is lossy-quantized) | – | – | Draco mesh compression |")
A(f"| garage_city_environment.blend | {sz('garage_city_environment.blend'):,} | {I['total_tris_rendered']:,} (unmerged) | – | {len(I['materials'])} | editable source, packed textures ≤512 px, slot empties intact |")
A("\n`slots.json` (independent file, 57 entries), `slots_v1.json`/`slots_v2.json` (baselines), `textures/` (19 PNG, ≤512 px; embedded in the compat GLBs). Slots are **never merged into render meshes**: they are empty nodes named `SLOT_*` in every GLB variant.\n")
A("Previews (all rendered from the shipped optimized GLB in three.js with SwiftShader software GL, full quality mode, 1600×900): `preview_game_camera.png` (CAM_Game_Perspective), `preview_iso_ortho.png` (CAM_Game_Isometric_Ortho), `preview_close_detail.png` (CAM_V3_Close_Detail), `preview_skyline_wide.png` (CAM_Preview_Skyline), `preview_hero_skyline.png` (CAM_V3_Hero_Skyline). The old Eevee previews were replaced; Eevee/.blend does not contain the baked vertex AO.\n")
A("## 3. Coordinate system & slots (unchanged from V1/V2)\n")
A("* Blender: 1 unit = 1 m, **+Z up**, +X east, +Y north, compound centred on the origin. glTF/three.js: **+Y up**; Blender (x, y, z) → glTF (x, z, −y). Slot local **+Y is the nose (glTF −Z)**.\n* Slot empties carry `extras` (slot_type, zone, note, nose_dir, envelope_width/length/height_m, forward axis); three.js exposes them in `userData`. Counts: 26 parking, 4 VIP, 6 display, 6 EV, 6 fuel, 8 lift, 1 showcase.\n")
A("| name | type | zone | Blender x, y, z | glTF pos | yaw° | env W×L×H |\n|---|---|---|---|---|---:|---|")
for s in S:
    g = s['gltf_yup']['position_m']; A(f"| {s['name']} | {s['type']} | {s['zone']} | {s['x']:.2f}, {s['y']:.2f}, {s['z']:.2f} | {g[0]:.2f}, {g[1]:.2f}, {g[2]:.2f} | {s['yaw']:.0f} | {s['w']}×{s['l']}×{s['h']} |")
A("\n## 4. Collections (.blend)\n\n| collection | objects | triangles |\n|---|---:|---:|")
for k, v in I['collections'].items(): A(f"| {'&nbsp;&nbsp;' * v['depth']}{k} | {v['objects']} | {v['tris']:,} |")
A("\n`Core_Car_Slots` is the V1 collection name of the (empty) slot anchors; kept so the hierarchy is unchanged.\n")
A("## 5. Materials & textures\n")
A(f"{len(I['materials'])} materials (Principled BSDF → glTF PBR, emissive via emissiveFactor + KHR_materials_emissive_strength). Textures (≤512 px, tileable/atlas): " + ", ".join(f"`{k}` {v[0]}×{v[1]}" for k, v in I['images'].items()) + ".\n")
A("**Baked vertex AO:** each GLB carries a `COLOR_0` (uint8 normalized) vertex colour = ray-cast ambient occlusion (BVH, large up-facing faces subdivided ≈2.6 m first), multiplied into baseColor only (emissives unaffected). Zero runtime cost. The .blend keeps white vertex colour. Materials use `vertexColors` automatically in three.js when COLOR_0 exists.\n")
A("## 6. Cameras\n")
for n in ('CAM_Game_Perspective', 'CAM_Game_Isometric_Ortho', 'CAM_Preview_Skyline', 'CAM_V3_Hero_Skyline', 'CAM_V3_Close_Detail'):
    c = I[n]; A(f"* **{n}** ({c['type']}): Blender location {c['loc']}, rotation° {c['rot_deg']}" + (f", horizontal FOV {c['hfov_deg']}°" if c['type'] == 'PERSP' else f", ortho_scale {c['ortho_scale']}"))
A("\n`CAM_Game_Perspective` and `CAM_Game_Isometric_Ortho` are **unchanged from V1/V2**. `CAM_Preview_Skyline`, `CAM_V3_Hero_Skyline`, `CAM_V3_Close_Detail` are non-gameplay preview cameras. **Layout/camera note:** the gameplay camera's top-of-frame is ≈10° below the horizon, so it can never show the skyline; the waterfront (basin + water row) was brought into the gameplay frame by layout changes (not by moving the camera). The skyline is shown by the hero/skyline cameras only.\n")
A("## 7. Quality modes, LOD and loading code\n")
A("`web/quality_modes.js` (ES module, three r160+, developed against r169) exports `QUALITY`, `LIGHTS`, `DistanceLOD`, `applyQuality(renderer, scene, camera, 'full'|'balanced'|'low')`. No post-processing in any mode.\n")
A("| mode | pixel ratio cap | AA | shadows | hide-by-distance (m): props / city chunks / far skyline / distant chunks | tone mapping |\n|---|---|---|---|---|---|\n| full (desktop) | 2.0 | on | 2048 map, ±110 m, PCFSoft (compound only) | 700 / ∞ / ∞ / ∞ | AgX |\n| balanced | 1.25 | on | 1024 map, ±90 m, PCF | 320 / 900 / ∞ / 1400 | AgX |\n| low (target 30 fps min — UNVERIFIED) | 1.0 | off | none | 190 / 520 / 900 / 700 | none (sRGB) |\n")
A("**Runtime LOD scheme:** documented *hide-by-distance* (`DistanceLOD`): object-name rules (props/vegetation, city chunks, far skyline, distant skyline/ridge) get a bounding sphere once; `update(camera)` toggles `.visible` every 8 frames. Frustum culling stays on (default). Instanced props are culled per InstancedMesh (one bounding sphere per chunk-cell).\n")
A("**Light values (not exported in the GLB):** warm key `DirectionalLight(0xffb083, 2.0)` direction-to-light (−0.545, 0.309, −0.779) (glTF space) placed ×300 m; cool fill `HemisphereLight(sky 0x3b6fd6, ground 0x10161f, 1.25)`; exposure 1.0; AgX tone mapping (full/balanced). Background/fog: sky dome in the GLB (`Sky_Dome`, fog=false); optional `Fog(0x1a2a5c, 300, 1800)`. Blender authoring values: Sun (1.0, 0.55, 0.32) E=3.4 rot (72°,0°,215°), sky-fill sun E=2.2, world ambient.\n")
A("### Three.js (set A or B; one combined file OR four split files)\n")
A("""```js
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js';   // set B / B+KTX2
import { KTX2Loader } from 'three/addons/loaders/KTX2Loader.js';                  // only for *.opt.ktx2.glb
import { DRACOLoader } from 'three/addons/loaders/DRACOLoader.js';                // only for *.opt.draco.glb
import { applyQuality } from './web/quality_modes.js';

const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
const scene = new THREE.Scene(), loader = new GLTFLoader().setMeshoptDecoder(MeshoptDecoder);
// decoder setup (copy these folders from three/examples/jsm/libs to your public dir):
loader.setKTX2Loader(new KTX2Loader().setTranscoderPath('/libs/basis/').detectSupport(renderer));      // KTX2 variant only
loader.setDRACOLoader(new DRACOLoader().setDecoderPath('/libs/draco/gltf/'));                          // Draco variant only
const gltf = await loader.loadAsync('/optimized/garage_city_environment.opt.glb');   // OR '/garage_city_environment.glb' (compat, no decoders)
scene.add(gltf.scene);
const cam = gltf.cameras.find(c => c.parent?.name === 'CAM_Game_Perspective' || c.name === 'CAM_Game_Perspective'); // cameras are in the combined file only
cam.aspect = innerWidth / innerHeight; cam.updateProjectionMatrix();
const { lod } = applyQuality(renderer, scene, cam, 'balanced');   // lights, shadows, pixel ratio, tone mapping, LOD
renderer.setAnimationLoop(() => { lod.update(cam); renderer.render(scene, cam); });
const slot = gltf.scene.getObjectByName('SLOT_bay_01');            // empty anchor; nose = local -Z; userData = slot metadata
```
""")
A("Sky dome: `Sky_Dome` radius 1300 m — keep camera far ≥ 2500 (game cameras: 2600/2500), `frustumCulled=false`, `depthWrite=false`, `renderOrder=-10`, `material.fog=false`. Glow decals (`glow_*` materials): consider `depthWrite=false` + small polygonOffset if z-fighting appears (not needed in the harness previews).\n")
A("### React Three Fiber\n")
A("""```jsx
import { useEffect, useRef } from 'react';
import { useThree, useFrame } from '@react-three/fiber';
import { useGLTF } from '@react-three/drei';   // drei's useGLTF enables the Meshopt decoder by default (Draco optional)
import { applyQuality } from './web/quality_modes.js';
function City({ mode = 'balanced' }) {
  const { scene } = useGLTF('/optimized/garage_city_environment.opt.glb');      // or the compat file
  const { gl, camera } = useThree(), lodRef = useRef();
  useEffect(() => { const q = applyQuality(gl, scene, camera, mode); lodRef.current = q.lod; return () => scene.remove(q.sun, q.sun.target, q.hemi); }, [mode]);
  useFrame(() => lodRef.current?.update(camera));
  return <primitive object={scene} />;
}
```
(R3F snippet is illustrative and **not executed** in this build; the vanilla three.js path is what the harness runs.)
""")
A("## 8. Integration rules (duplication guard)\n")
A("* Loading config must reference **either** `garage_city_environment[.opt].glb` **or** the four split files of the same set, never both, never A+B. The perf harness (`tools/perf/perf.html`) takes a single GLB list and the quality-mode code assumes one scene copy. Split files do not contain cameras; the combined file contains 5 cameras.\n* Split files share one world coordinate system (no offsets).\n")
A("## 9. Optimization techniques actually used\n")
oe = OR['garage_city_environment']
A(f"* Shared materials (75 in combined compat file), textures ≤512 px, vertex-colour AO instead of lightmaps.\n* Spatial batching of non-interactive static props into per-material chunks (compat set; cell 200–600 m); interactive/slot-related objects are not merged.\n* **EXT_mesh_gpu_instancing** (optimized set): {oe['instancing']['source_nodes_replaced']} repeated prop nodes → {oe['instancing']['instanced_nodes']} instanced nodes in the combined file; verified in three.js (243 InstancedMesh, 2,423 instances, triangle count identical to the compat file: {VT[OPTN('garage_city_environment.glb')]['triangles']:,}).\n* KHR_mesh_quantization + EXT_meshopt_compression (set B); Draco and KTX2 variants. KTX2: {oe['ktx2_textures']['png_bytes']:,} → {oe['ktx2_textures']['ktx2_bytes']:,} bytes of texture payload (toktx 4.3.x). Texcoords are not quantized below 16-bit.\n* Hide-by-distance runtime LOD, minimal real-time shadows (compound only), no post-processing, calm water (no reflections), reduced bright window grids.\n* **Not done:** material/texture atlasing (draw calls are driven by chunks × materials), geometry LOD meshes, occlusion culling.\n")
A("## 10. Measured performance (software rendering only)\n")
A("All numbers: SwiftShader CPU WebGL in headless Chrome, 8-core box — **relative only, NOT device FPS; real-device 30 fps minimum / 60 fps capability is UNVERIFIED.** Full tables: `perf_report.md`, `perf_results.json`.\n")
A("| gameplay cam, quality 0 (no shadow/LOD) | V1 | V2 | V3 compat | V3 optimized |\n|---|---:|---:|---:|---:|")
def cell(v, w, k): r = q0(v, w); return r[k] if r else 'n/a'
for lab, k in (('GLB MB', 'glb_mb'), ('download ms (localhost)', 'download_ms'), ('parse+tex ms', 'parse_ms'), ('heap Δ after load MB', 'heap_delta_load_mb'), ('draw calls (renderer.info)', 'draw_calls'), ('triangles drawn', 'triangles'), ('geometries', 'geometries'), ('textures', 'textures')):
    A(f"| {lab} (1280×720) | {cell('V1', 1280, k)} | {cell('V2', 1280, k)} | {cell('V3C', 1280, k)} | {cell('V3O', 1280, k)} |")
for w in (1280, 800): A(f"| frame median ms @ {w}×{'720' if w == 1280 else '450'} (software) | {cell('V1', w, 'frame_ms_median')} | {cell('V2', w, 'frame_ms_median')} | {cell('V3C', w, 'frame_ms_median')} | {cell('V3O', w, 'frame_ms_median')} |")
A("\n## 11. Validation summary (details in `validation_report.md`)\n")
A("57/57 slots identical to V1 and V2 (Blender world matrices, custom props, collections and slots.json; also GLB node transforms/userData). gltf-validator: 0 errors on all 16 GLBs. Keep-clear boxes and sight-line rays (285 per camera) vs all geometry: 0 overlaps, 0 blocked, with negative controls that are detected. Name-based vehicle scan: 0 hits (no shape detector exists; the visual review found no vehicle shapes).\n")
A("## 12. Known limitations\n")
A("* Real-device performance is unverified. In software rendering V3 is *not* faster than V2 per frame (§10); the wins are download size / heap, not draw calls.\n* Draw calls are still ~500 (chunks × materials); the optimized set has *more* draw calls than the compat set because each instanced prop proto×material is a separate InstancedMesh.\n* No atlasing; Eevee vs three.js looks differ; no reflections/rain; skyline in the hero view is brighter/taller than the reference hierarchy would ideally allow, though it is outside the gameplay frame.\n* Vehicle absence rests on construction + name scan + visual review; no shape-based detector.\n* Draco/KTX2 variants: loaded and rendered in the browser harness; keep-clear/LOS checked on the meshopt files only (same geometry as KTX2; Draco geometry is lossy-quantized and was not re-run through the clearance test). gltf-validator reports KTX2 warnings (§validation_report) because it does not know KHR_texture_basisu.\n")
open(f'{D}/environment_manifest.md', 'w').write("\n".join(L))

# ------------------------------------------------------------------ comparison
C = []; B = C.append
B("# V1 → V2 → V3 comparison\n\nAll V1/V2 numbers re-measured from the V1/V2 folders (untouched). 'Draw-call estimate' = glTF primitives (static). 'Measured' = three.js `renderer.info` of the last frame at CAM_Game_Perspective, 1280×720, quality 0 (no shadows/LOD), SwiftShader software GL.\n")
B("## Geometry, materials, size (compat GLBs)\n\n| file | tris V1 / V2 / V3 | primitives (est.) V1 / V2 / V3 | materials V1 / V2 / V3 | size V1 / V2 / V3 |\n|---|---|---|---|---|")
for f in GL:
    a, b, c = (ST[v][f] for v in ('V1', 'V2', 'V3'))
    B(f"| {f} | {a['triangles']:,} / {b['triangles']:,} / {c['triangles']:,} | {a['primitives_drawcalls_est']} / {b['primitives_drawcalls_est']} / {c['primitives_drawcalls_est']} | {a['materials']} / {b['materials']} / {c['materials']} | {mb(a['bytes'])} / {mb(b['bytes'])} / {mb(c['bytes'])} |")
B(f"\nV3 optimized combined: {mb(OR['garage_city_environment']['optimized']['bytes'])} (meshopt+instancing), {mb(OR['garage_city_environment']['optimized_ktx2']['bytes'])} (+KTX2), {mb(OR['garage_city_environment']['optimized_draco']['bytes'])} (Draco). V2 combined: {mb(ST['V2'][GL[0]]['bytes'])}.\n")
B("## Measured renderer numbers (software rendering, gameplay camera, quality 0)\n\n| | V1 | V2 | V3 compat | V3 optimized |\n|---|---:|---:|---:|---:|")
for lab, k in (('draw calls', 'draw_calls'), ('triangles drawn', 'triangles'), ('geometries', 'geometries'), ('textures', 'textures'), ('download ms', 'download_ms'), ('parse+texture ms', 'parse_ms'), ('JS heap Δ load (MB)', 'heap_delta_load_mb')):
    B(f"| {lab} @1280×720 | {cell('V1', 1280, k)} | {cell('V2', 1280, k)} | {cell('V3C', 1280, k)} | {cell('V3O', 1280, k)} |")
for w in (1280, 800): B(f"| frame median ms @{w}×{'720' if w == 1280 else '450'} | {cell('V1', w, 'frame_ms_median')} | {cell('V2', w, 'frame_ms_median')} | {cell('V3C', w, 'frame_ms_median')} | {cell('V3O', w, 'frame_ms_median')} |")
B("\nReading: V3 draws ~14% more triangles than V2 (richer detail) and is ~10–25% slower per frame in software rendering; compat V3 has slightly fewer draw calls than V2, the optimized V3 slightly more (instanced prop meshes). The clear V3 win is transfer size/heap (3.5 MB vs 10.9 MB). One run per row, no repeats → ±~10% noise. **None of this is device FPS.**\n")
B("## Shipped quality modes, V2 file vs V3 optimized (same quality_modes.js on both; software rendering)\n\n| mode | res | V2 draw calls / tris / median ms | V3 opt draw calls / tris / median ms |\n|---|---|---|---|")
for w in (1280, 800):
    for m in ('full', 'balanced', 'low'):
        a, b = md(m, 'V2', w), md(m, 'V3O', w)
        if a and b: B(f"| {m} | {w}×{'720' if w == 1280 else '450'} | {a['draw_calls']} / {a['triangles']:,} / {a['frame_ms_median']} | {b['draw_calls']} / {b['triangles']:,} / {b['frame_ms_median']} |")
B("\n(`full` mode includes a shadow pass; 'full' used 12 frames only; the `V3 full 800×450` row was re-run standalone after the matrix script missed it.)\n")
B("## Qualitative\n\n| aspect | V1 | V2 | V3 |\n|---|---|---|---|\n| garage | basic compound | enclosed workshop hall, glazed showroom | same layout, more detail (core 38.6k → 48.8k tris), calmer lighting, baked AO, showcase rings/arches as focal point |\n| city | uniform boxes, bright window grid | tower generator, 4-layer skyline | fewer/dimmer lit windows, lower far-shore, roof gardens/mechanicals, varied vegetation |\n| roads/water | flat | markings, highway | kerbs/sidewalks/joints refined, basin visible in gameplay camera, calm water |\n| export | 2.7k primitives | merged chunks | + instancing/meshopt/KTX2/Draco variants, vertex AO, quality modes |\n")
open(f'{D}/COMPARISON_V1_V2_V3.md', 'w').write("\n".join(C))

# ------------------------------------------------------------------ validation report
V = []; E = V.append
E("# V3 validation report\n\nSeparated into **MEASURED/RUN** (a script or tool produced the number), **VISUALLY INSPECTED** (by eye on previews) and **UNVERIFIED** (not tested). No device-target pass is claimed.\n")
E("## 1. MEASURED / RUN (reproduce with `./run_validate.sh`, `tools/perf/run_matrix.sh`)\n")
E(f"* `.blend` reopened headless (Blender 4.2.3): {VB['objects_total']} objects, {VB['materials']} materials, images packed={VB['all_images_packed']}, max texture {VB['max_texture_px']} px (`validation_blend.json`).")
E("* **gltf-validator** (Khronos, npm), every GLB — errors/warnings: " + "; ".join(f"{k.split('/')[-1]} {v['gltf_validator']['numErrors']}/{v['gltf_validator']['numWarnings']}" for k, v in VG.items() if isinstance(v, dict) and 'gltf_validator' in v) + ". **0 errors on all files.** Warnings are only on the `*.opt.ktx2.glb` files (8–36 each): `VALUE_NOT_IN_LIST /images/N/mimeType` (image/ktx2) because the validator does not implement KHR_texture_basisu; extension-unsupported INFO messages on all optimized files (EXT_meshopt/instancing/etc. are unknown to the validator, so their payloads were not validated by it).")
E(f"* **Slots 57/57 identical** to V1 and V2: `slots.json` JSON-equal to V2; `slot_diff_vs_v1/v2.json` identical={SD1['identical']}/{SD2['identical']}; Blender empties (world matrix @5dp, all custom props, collection, display type/size) V3 vs V1 identical={SE['v3_vs_v1']['identical']}, V3 vs V2 identical={SE['v3_vs_v2']['identical']} (`slot_empties_diff_vs_v1_v2.json`); 57 `SLOT_*` nodes in every combined/core GLB variant (incl. KTX2/Draco); three.js node load: slot position error {VT['garage_city_environment.glb']['slot_max_position_err_m']} m, nose-vector error {VT['garage_city_environment.glb']['slot_max_nose_vector_err']}, userData == slots.json: {VT['garage_city_environment.glb']['slot_userData_matches_slots_json']}; same for the optimized combined file; Blender re-import round-trip max error 0.0 m / 0.0°.")
E(f"* **three.js (r169) headless Node `GLTFLoader.parse`** (`threejs_load_test.mjs`, no GPU) loads all 10 compat+meshopt GLBs; optimized combined: {VT[OPTN('garage_city_environment.glb')]['triangles']:,} tris (= compat {VT['garage_city_environment.glb']['triangles']:,}), {VT[OPTN('garage_city_environment.glb')]['instanced_meshes']} InstancedMesh / {VT[OPTN('garage_city_environment.glb')]['instances']:,} instances (EXT_mesh_gpu_instancing verified).")
E("* **Browser loads** (headless Chrome + SwiftShader, `perf_results/load_*.json`): V2, V3 compat, V3 opt (meshopt), V3 opt+KTX2 (KTX2Loader with basis transcoder), V3 opt+Draco (DRACOLoader) all load and render with no exceptions recorded by the harness (Chrome logs one harmless favicon 404) → KTX2Loader and DRACOLoader verified headlessly. Screenshot diff vs V3 compat (mean abs diff, 0–255 scale): " + ", ".join(f"{k.replace('_vs_V3C','')} {v['mean_abs_diff_0_255']} ({v['pct_pixels_diff_gt16']}% px >16)" for k, v in ID.items() if k != 'V2_vs_V3C') + " — differences come from quantization/LOD hide-by-distance and compressed textures, small but non-zero.")
E("* **Texture references resolve:** compat GLBs embed all 18–19 images (`textures_all_embedded` true, max 512 px); KTX2 variants embed KTX2 images and rendered in the browser.")
E("* **Keep-clear + sight-line on the shipped GLB geometry** (`validate_glb_three.mjs`, every triangle incl. expanded instances vs each slot's oriented envelope box, floor tolerance 0.15 m; 285 rays slot→camera per camera): " + "; ".join(f"{k}: overlaps {len(v['slots_overlapping'])}, blocked {sum(x['blocked'] for x in v['los_blocked'].values()) if v['los_blocked'] else 'n/a (no cameras in file)'}, negative control PASS={v['negative_control']['PASS']}" for k, v in VC.items()) + ".")
E(f"* Same checks in Blender (BVH) on the reopened .blend: overlaps {len(VB['slots_overlapping'])}, LOS blocked {VB['line_of_sight']['CAM_Game_Perspective']['blocked']}/{VB['line_of_sight']['CAM_Game_Isometric_Ortho']['blocked']}, misaligned slots {len(VB['slots_misaligned'])}. **Negative control** (`negative_control.py` injects a cube into SLOT_bay_01 and a wall in front of SLOT_bay_05 into a /tmp copy): validator flags {NC['slots_overlapping']} and blocks {NC['line_of_sight']['CAM_Game_Perspective']['blocked']}/285 perspective rays → checker works.")
E("* **Vehicle scan:** name scan of objects/meshes/materials/collections in the .blend and every GLB: 0 hits (the collection name `Core_Car_Slots` is the legacy V1 slot-anchor collection and contains only empties). **There is no shape-based vehicle detector.**")
E("* Bounds/scale: Sky_Dome ±1300 m dominates combined bounds (validated Y-up); scene content bbox (three.js) x −1000…1100, y −3.5…332, z −875…538 m.")
E("* Combined/split duplication: loading code (`web/quality_modes.js`, `perf.html`, manifest snippets) loads one GLB list; harness never passes combined+split. Checked by reading the configs (no automated test).")
E("* **Perf harness** (software rendering): see `perf_report.md` / `perf_results.json` / `COMPARISON_V1_V2_V3.md`. Settings: puppeteer-core + headless Chrome 156, `--use-angle=swiftshader`, three r169, static local server, gameplay camera, 1280×720 and 800×450, 30 frames (12 for full mode) after 5 warm-ups, 1 run per row.\n")
E("## 2. VISUALLY INSPECTED (by eye, not automated)\n")
E("* Previews (`preview_*.png`) compared against the concept image over several iterations: glazed amber workshops, central ringed showcase with arches, canopies, palms, elevated highway, basin water visible in the gameplay frame, blue-hour sky; skyline layering in hero/wide cameras. No vehicle-like shapes were seen in the five previews or in the Eevee/three.js iteration renders.\n* Known visual gaps vs the reference: no rain/reflections, flatter lighting, hero view skyline is bright/tall and competes with the garage (hierarchy only holds in the gameplay/iso frames).\n")
E("## 3. UNVERIFIED / NOT DONE\n")
E("* **Real-device performance: NOT tested** — no 30 fps (low-end) or 60 fps (capable hardware) result exists; software-rendering frame times are not device-representative. The pack is therefore **not** claimed to be 'low-end optimized'; it provides the tools (quantization, instancing, KTX2/Draco, LOD/quality modes) and byte/heap savings only.\n* In software rendering V3 is ~10–25% slower per frame than V2 and draws more triangles; draw calls only ±10% vs V2.\n* R3F snippet not executed. Runtime LOD effect on frame time not isolated beyond the mode runs.\n* Keep-clear/LOS not re-run on Draco geometry; KHR_texture_basisu/meshopt/instancing payloads not validated by gltf-validator itself (loaded by three.js instead).\n* No shape-based vehicle detector; no automated duplication test of user loading configs.\n")
open(f'{D}/validation_report.md', 'w').write("\n".join(V))
print('docs written')
