"""Garage City RH V2 - architecture module: enclosed workshops, glazed service centres with warm interiors,
multi-level volumes, varied roofs, loading docks, fuel + EV station buildings, utility yards.
All geometry here is NEW static geometry; nothing here touches the SLOT_* empties or their keep-clear boxes
(every free-standing item is checked with free_xy()).
"""
from gc_lib import *
import gc_props as P

# ------------------------------------------------------------------ wall-local placement helper
class Wall:
    """Local frame for a wall running along world X (axis='x', outward normal -Y, i.e. facing south)
    or along world Y (axis='y', outward normal -X, i.e. facing west).  u = along the wall, v = outward distance."""
    def __init__(self, mb, axis, base):
        self.mb, self.axis, self.base = mb, axis, base      # base = y (axis x) or x (axis y) of the wall plane
    def xy(self, u, v):
        return (u, self.base - v) if self.axis == 'x' else (self.base - v, u)
    def box(self, u, v, z, su, sv, sz, m, **kw):
        x, y = self.xy(u, v)
        if self.axis == 'x':
            self.mb.box(x, y, z, su, sv, sz, m, **kw)
        else:
            self.mb.box(x, y, z, sv, su, sz, m, **kw)
    def cyl(self, u, v, z, r, h, m, **kw):
        x, y = self.xy(u, v)
        self.mb.cyl(x, y, z, r, h, m, **kw)

def facade(w, u0, u1, z0, z1, doors=(), pier=3.8, glass=True, door_h=3.8, door_m='steel_painted', lights=True, mid_rail=True,
           trim='neon_cyan', plinth=0.55, roll_up=True):
    """glazed curtain-wall bay row between u0..u1 with optional door openings [(uc, width)]."""
    L = u1 - u0
    n = max(1, int(round(L / pier)))
    step = L / n
    # door intervals
    ivs = [(uc - dw / 2, uc + dw / 2) for uc, dw in doors]
    def in_door(a, b):
        return any(a < d1 - 0.05 and b > d0 + 0.05 for d0, d1 in ivs)
    # plinth + head beam
    w.box((u0 + u1) / 2, 0.15, 0, L, 0.7, plinth, 'graphite_dark')
    w.box((u0 + u1) / 2, 0.30, z1 - 0.45, L, 0.9, 0.45, 'graphite')
    if trim:
        w.box((u0 + u1) / 2, 0.78, z1 - 0.42, L, 0.04, 0.07, trim)
    if mid_rail:
        w.box((u0 + u1) / 2, 0.06, (z0 + z1) / 2 + 0.3, L, 0.1, 0.07, 'metal_light')
    for i in range(n + 1):
        u = u0 + step * i
        if any(d0 - 0.05 < u < d1 + 0.05 for d0, d1 in ivs):
            continue
        w.box(u, 0.12, z0, 0.32, 0.5, z1 - z0 - 0.45, 'graphite')
        if lights and i % 2 == 0 and z1 - z0 > 3.5:
            w.box(u, 0.42, z1 - 1.25, 0.14, 0.12, 0.28, 'lamp_warm')       # exterior wall light
    for i in range(n):
        a, b = u0 + step * i, u0 + step * (i + 1)
        if in_door(a, b):
            continue
        if glass:
            w.box((a + b) / 2, 0.05, z0 + plinth, step - 0.34, 0.04, z1 - z0 - plinth - 0.45, 'glass_tint')
    # door portals
    for uc, dw in doors:
        w.box(uc - dw / 2 - 0.17, 0.2, z0, 0.34, 0.6, door_h + 0.4, 'graphite_dark')
        w.box(uc + dw / 2 + 0.17, 0.2, z0, 0.34, 0.6, door_h + 0.4, 'graphite_dark')
        w.box(uc, 0.2, z0 + door_h, dw + 0.68, 0.6, 0.4, 'graphite_dark')
        if roll_up:
            w.box(uc, 0.34, z0 + door_h - 0.7, dw - 0.2, 0.3, 0.7, door_m)         # rolled-up shutter slats (door is open)
            w.box(uc, 0.34, z0 + door_h - 0.12, dw - 0.2, 0.32, 0.08, 'hazard')     # hazard bottom bar
        w.box(uc, 0.52, z0 + door_h + 0.05, dw + 0.5, 0.05, 0.1, 'neon_amber')
        # threshold + floor hazard stripe
        w.box(uc, 0.3, z0, dw, 0.5, 0.04, 'hazard')

def awning(w, u0, u1, z, depth, trim='neon_cyan', col='graphite'):
    w.box((u0 + u1) / 2, depth / 2 + 0.3, z, u1 - u0, depth, 0.25, col)
    w.box((u0 + u1) / 2, depth + 0.3, z + 0.02, u1 - u0, 0.1, 0.35, trim)
    # tie rods + posts at ends
    for u in (u0 + 0.2, u1 - 0.2):
        w.box(u, depth, 0, 0.25, 0.25, z, 'graphite')

# ------------------------------------------------------------------ interior kit (all positions are world x,y; rot in degrees)
def _c(rot): return math.cos(math.radians(rot)), math.sin(math.radians(rot))

def tool_cabinet(mb, x, y, rot, h=1.4, col='cabinet_orange'):
    mb.box(x, y, 0.2, 1.1, 0.6, h, col, rot=rot, mtop='graphite_dark')
    c, s = _c(rot)
    for k in range(4):
        mb.box(x - 0.31 * s * -1 if False else x, y, 0.35 + k * (h - 0.3) / 4, 1.12, 0.62, 0.025, 'graphite_dark', rot=rot)

def workbench(mb, x, y, rot, L=2.6):
    mb.box(x, y, 0.88, L, 0.8, 0.07, 'metal_light', rot=rot)
    c, s = _c(rot)
    for sg in (-1, 1):
        mb.box(x + sg * (L / 2 - 0.15) * c, y + sg * (L / 2 - 0.15) * s, 0.2, 0.12, 0.7, 0.68, 'graphite_dark', rot=rot)
    mb.box(x, y, 0.45, L - 0.3, 0.7, 0.05, 'graphite_dark', rot=rot)
    # vice + monitor-less terminal + pegboard
    mb.box(x + 0.8 * c, y + 0.8 * s, 0.95, 0.2, 0.2, 0.2, 'steel_teal', rot=rot)
    mb.box(x - 0.2 * s - 0.0, y + 0.2 * c * 0 + 0.28 * c, 1.0, 0.5, 0.05, 0.35, 'neon_blue', rot=rot) if False else None

def tire_rack(mb, x, y, rot, rows=3):
    c, s = _c(rot)
    for sg in (-1, 1):
        mb.box(x + sg * 0.95 * c, y + sg * 0.95 * s, 0, 0.08, 0.7, rows * 0.62 + 0.3, 'graphite_dark', rot=rot)
    for r in range(rows):
        mb.box(x, y, 0.28 + r * 0.62, 1.9, 0.7, 0.05, 'graphite', rot=rot)
        for k in range(2):
            off = (k - 0.5) * 0.85
            tx, ty = x + off * c, y + off * s
            ax = 'y' if abs(c) > 0.5 else 'x'
            mb.hcyl(tx, ty, 0.34 + 0.3 + r * 0.62 - 0.05, 0.3, 0.32, 'rubber', axis=ax, seg=8)

def shelf_unit(mb, x, y, rot, L=2.2, levels=4, hgt=2.4, boxes=True):
    c, s = _c(rot)
    for sg in (-1, 1):
        mb.box(x + sg * (L / 2) * c, y + sg * (L / 2) * s, 0, 0.07, 0.5, hgt, 'steel_teal', rot=rot)
    for k in range(levels):
        z = 0.25 + k * (hgt - 0.3) / levels
        mb.box(x, y, z, L, 0.5, 0.04, 'graphite_dark', rot=rot)
        if boxes:
            for q in (-0.65, 0.0, 0.65):
                if (k + int(q * 10)) % 3 == 0:
                    continue
                mb.box(x + q * c, y + q * s, z + 0.04, 0.45, 0.38, 0.3, 'cabinet_blue' if (k % 2) else 'cabinet_orange', rot=rot)

def hoist(mb, x, y, rot=0):
    """empty two-post hydraulic hoist (workshop-interior decoration; NOT a game slot)."""
    c, s = _c(rot)
    for sg in (-1, 1):
        px, py = x + sg * 1.7 * -s, y + sg * 1.7 * c
        mb.box(px, py, 0, 0.5, 0.5, 0.12, 'graphite_dark', rot=rot)
        mb.box(px, py, 0.12, 0.34, 0.34, 3.3, 'steel_teal', rot=rot)
        mb.box(px, py, 3.42, 0.4, 0.4, 0.1, 'neon_cyan', rot=rot)
        # carriage + swing arms (low)
        mb.box(px, py, 0.5, 0.42, 0.42, 0.25, 'graphite', rot=rot)
        for a in (-0.5, 0.5):
            mb.box(px + a * c * 0.9, py + a * s * 0.9, 0.5, 1.2, 0.12, 0.08, 'metal_light', rot=rot + 90)
    mb.box(x, y, 3.45, 3.7, 0.18, 0.18, 'graphite', rot=rot + 90)          # overhead tie beam
    mb.box(x, y, 0.0, 3.6, 4.6, 0.015, 'mark_yellow', rot=rot, top=True) if False else None

def pendant(mb, x, y, z, L=2.0, rot=0):
    mb.box(x, y, z, L, 0.28, 0.06, 'int_panel', rot=rot)
    mb.box(x, y, z + 0.06, 0.06, 0.06, 0.6, 'graphite_dark', rot=rot)

def drum(mb, x, y, col='steel_teal'):
    mb.cyl(x, y, 0.2, 0.28, 0.85, col, seg=8)
    mb.cyl(x, y, 0.55, 0.285, 0.05, 'graphite_dark', seg=8)

def compressor(mb, x, y, rot=0):
    c, s = _c(rot)
    mb.hcyl(x, y, 0.75, 0.38, 1.4, 'steel_painted', axis='x' if abs(c) > 0.5 else 'y', seg=10)
    for sg in (-1, 1):
        mb.box(x + sg * 0.55 * c, y + sg * 0.55 * s, 0.2, 0.12, 0.5, 0.35, 'graphite_dark', rot=rot)
    mb.box(x, y, 1.15, 0.3, 0.3, 0.25, 'cabinet_orange', rot=rot)

def tool_cart(mb, x, y, rot):
    mb.box(x, y, 0.22, 0.9, 0.55, 0.7, 'cabinet_orange', rot=rot, mtop='graphite_dark')
    mb.box(x, y, 0.92, 0.95, 0.6, 0.05, 'metal_light', rot=rot)
    c, s = _c(rot)
    for sx_ in (-1, 1):
        for sy_ in (-1, 1):
            mb.box(x + sx_ * 0.38 * c - sy_ * 0.2 * s, y + sx_ * 0.38 * s + sy_ * 0.2 * c, 0.05, 0.1, 0.06, 0.17, 'rubber', rot=rot)
    mb.box(x - 0.45 * c, y - 0.45 * s, 0.7, 0.05, 0.5, 0.35, 'graphite_dark', rot=rot)

def terminal(mb, x, y, rot):
    """blank service terminal: pedestal + angled blank dark screen (no text)."""
    mb.box(x, y, 0, 0.5, 0.4, 1.0, 'graphite_dark', rot=rot)
    mb.box(x, y, 1.0, 0.62, 0.12, 0.42, 'polymer', rot=rot)
    c, s = _c(rot)
    mb.box(x + 0.065 * -s * -1 * 0, y, 1.04, 0.5, 0.02, 0.32, 'neon_blue', rot=rot) if False else None

def bench(mb, x, y, rot, L=1.8):
    mb.box(x, y, 0.42, L, 0.45, 0.06, 'metal_light', rot=rot)
    c, s = _c(rot)
    for sg in (-1, 1):
        mb.box(x + sg * (L / 2 - 0.15) * c, y + sg * (L / 2 - 0.15) * s, 0, 0.08, 0.4, 0.42, 'graphite_dark', rot=rot)

def trench_grate(mb, x0, y0, x1, y1, z=0.045):
    """floor drain / trench grate: dark channel + light bars"""
    gq(mb, x0, y0, x1, y1, z, 'polymer')
    if abs(x1 - x0) > abs(y1 - y0):
        n = int((x1 - x0) / 0.5)
        for i in range(n):
            gq(mb, x0 + 0.1 + i * 0.5, y0 + 0.02, x0 + 0.2 + i * 0.5, y1 - 0.02, z + 0.005, 'metal_light')
    else:
        n = int((y1 - y0) / 0.5)
        for i in range(n):
            gq(mb, x0 + 0.02, y0 + 0.1 + i * 0.5, x1 - 0.02, y0 + 0.2 + i * 0.5, z + 0.005, 'metal_light')

def drain(mb, x, y, r=0.3, z=0.047):
    mb.ring_flat(x, y, z, 0.0, r, 'polymer', seg=8)
    mb.ring_flat(x, y, z + 0.004, r * 0.35, r * 0.55, 'metal_light', seg=8)

def hvac_unit(mb, x, y, z, rot=0, sx=2.6, sy=1.7):
    mb.box(x, y, z, sx, sy, 1.1, 'steel_painted', rot=rot, mtop='graphite_dark')
    c, s = _c(rot)
    for k in range(3):
        mb.box(x + (k - 1) * 0.75 * c, y + (k - 1) * 0.75 * s, z + 1.1, 0.7, 0.7, 0.04, 'polymer', rot=rot)
        mb.cyl(x + (k - 1) * 0.75 * c, y + (k - 1) * 0.75 * s, z + 1.14, 0.3, 0.08, 'metal_light', seg=8)
    for k in range(5):
        mb.box(x - (sx / 2 - 0.02) * s * 0 + 0, y, z + 0.2 + k * 0.17, sx * 0.9, sy + 0.04, 0.05, 'graphite_dark', rot=rot) if False else None

def vent_stack(mb, x, y, z, h=2.4, r=0.3):
    mb.cyl(x, y, z, r, h, 'metal_light', seg=8, top=False)
    mb.cyl(x, y, z + h, r * 1.7, 0.12, 'graphite_dark', seg=8)
    mb.cyl(x, y, z + h + 0.12, r * 0.4, 0.5, 'graphite_dark', seg=6)

def solar_row(mb, x0, y0, n, dx, w=2.2, d=3.0, z=0.0, tilt=0.5, rot=0):
    """tilted solar panels (4 verts each, 2 tris) with a rear stand"""
    for i in range(n):
        cx = x0 + i * dx
        a = (cx - w / 2, y0 - d / 2, z + 0.15); b = (cx + w / 2, y0 - d / 2, z + 0.15)
        c_ = (cx + w / 2, y0 + d / 2, z + 0.15 + tilt); d_ = (cx - w / 2, y0 + d / 2, z + 0.15 + tilt)
        mb.quad(a, b, c_, d_, 'solar')
        mb.box(cx, y0 + d / 2 - 0.1, z, 0.1, 0.1, 0.15 + tilt, 'graphite_dark')

def ladder(mb, x, y, z0, h, rot=0):
    c, s = _c(rot)
    for sg in (-1, 1):
        mb.box(x - sg * 0.2 * s, y + sg * 0.2 * c, z0, 0.04, 0.04, h, 'metal_light')
    for k in range(int(h / 0.35)):
        mb.box(x, y, z0 + 0.3 + k * 0.35, 0.04 + abs(s) * 0.4, 0.04 + abs(c) * 0.4, 0.03, 'metal_light')

def cable_tray(mb, x0, y0, x1, y1, z, w=0.4):
    L = math.hypot(x1 - x0, y1 - y0); ang = math.degrees(math.atan2(y1 - y0, x1 - x0))
    mb.box((x0 + x1) / 2, (y0 + y1) / 2, z, L, w, 0.05, 'graphite_dark', rot=ang)
    mb.box((x0 + x1) / 2, (y0 + y1) / 2, z + 0.05, L, w * 0.5, 0.05, 'neon_blue', rot=ang) if False else None

def pipe_run(mb, pts, r=0.07, m='steel_teal'):
    for a, b in zip(pts[:-1], pts[1:]):
        mb.pipe(a, b, r, m, seg=6)
