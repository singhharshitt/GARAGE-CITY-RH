"""Run:  blender -b garage_city_environment.blend --python validate_blend.py
Checks (inside Blender, on the reopened .blend):
  1 inventory, packed images, texture sizes
  2 no vehicle-like object / mesh / material names
  3 slot envelopes free of geometry (BVH surface overlap + vertex-in-box)
  4 line-of-sight from every slot to both game cameras (ray cast, sky dome hidden)
  5 slot clearance above (ray up)
Writes validation_blend.json"""
import bpy, bmesh, json, math, os, re
from mathutils import Vector, Matrix
from mathutils.bvhtree import BVHTree
OUT = os.environ.get('VAL_OUT') or os.path.dirname(bpy.data.filepath)
OUTNAME = os.environ.get('VAL_NAME', 'validation_blend.json')
R = {}
objs = list(bpy.data.objects)
R['objects_total'] = len(objs)
R['by_type'] = {}
for o in objs: R['by_type'][o.type] = R['by_type'].get(o.type, 0) + 1
R['collections'] = [c.name for c in bpy.data.collections]
imgs = {i.name: dict(size=list(i.size), packed=i.packed_file is not None) for i in bpy.data.images if i.name not in ('Render Result',)}
R['images'] = imgs
R['max_texture_px'] = max(max(v['size']) for v in imgs.values())
R['all_images_packed'] = all(v['packed'] for v in imgs.values())
R['materials'] = len(bpy.data.materials)
# --- 2 vehicle names
BAD = re.compile(r'(\bcar\b|_car_|^car|vehicle|truck|\bbus\b|\bvan\b|motor|bike|bicycle|scooter|taxi|sedan|suv|coupe|wheel|tyre|chassis|traffic|automobile|lorry|pickup|limo)', re.I)
names = [o.name for o in objs] + [m.name for m in bpy.data.meshes] + [m.name for m in bpy.data.materials]
hits = sorted({n for n in names if BAD.search(n)})
R['vehicle_name_hits'] = hits
R['collections_with_car_in_name'] = [c.name for c in bpy.data.collections if BAD.search(c.name)]
# --- build world-space triangle soup (exclude sky dome, empties)
dg = bpy.context.evaluated_depsgraph_get()
verts, tris = [], []
owner = []
for o in objs:
    if o.type != 'MESH' or o.name.startswith('Sky_Dome'): continue
    me = o.data
    mw = o.matrix_world
    base = len(verts)
    verts.extend([tuple(mw @ v.co) for v in me.vertices])
    me.calc_loop_triangles()
    for t in me.loop_triangles:
        tris.append((base + t.vertices[0], base + t.vertices[1], base + t.vertices[2]))
        owner.append(o.name)
R['triangles_world_soup_excl_sky'] = len(tris)
scene_bvh = BVHTree.FromPolygons(verts, tris, epsilon=1e-4)
# --- 3 slot envelope overlap
FLOOR_TOL = 0.15   # geometry whose top is within 15 cm of the slot floor = paint/decal, allowed
slots = [o for o in objs if o.name.startswith('SLOT_')]
R['slot_count'] = len(slots)
import numpy as np
V = np.array(verts, dtype=np.float64)
T = np.array(tris, dtype=np.int64)
tri_min = np.minimum(np.minimum(V[T[:, 0], 2], V[T[:, 1], 2]), V[T[:, 2], 2])
tri_max = np.maximum(np.maximum(V[T[:, 0], 2], V[T[:, 1], 2]), V[T[:, 2], 2])
res = []
for s in slots:
    w, l, h = s['envelope_width_m'], s['envelope_length_m'], s['envelope_height_m']
    m = s.matrix_world
    z0, z1 = FLOOR_TOL, h
    corners = [Vector((sx * w / 2, sy * l / 2, sz)) for sx in (-1, 1) for sy in (-1, 1) for sz in (z0, z1)]
    bverts = [tuple(m @ c) for c in corners]
    # box faces
    idx = [(0,1,3),(0,3,2),(4,6,7),(4,7,5),(0,4,5),(0,5,1),(2,3,7),(2,7,6),(0,2,6),(0,6,4),(1,5,7),(1,7,3)]
    bb = BVHTree.FromPolygons(bverts, idx, epsilon=1e-5)
    pairs = bb.overlap(scene_bvh)
    # filter out surface triangles that lie entirely at/below floor tolerance (cannot intersect anyway) -> all pairs are real
    bad_tris = sorted({p[1] for p in pairs})
    # vertex-in-box (fully contained tris)
    inv = m.inverted()
    loc = np.array([tuple(inv @ Vector(v)) for v in V[(V[:,0]>m.translation.x-6)&(V[:,0]<m.translation.x+6)&(V[:,1]>m.translation.y-6)&(V[:,1]<m.translation.y+6)]]) if len(V) else np.zeros((0,3))
    inside = 0
    if len(loc):
        inside = int(((abs(loc[:,0])<w/2-1e-4)&(abs(loc[:,1])<l/2-1e-4)&(loc[:,2]>z0+1e-4)&(loc[:,2]<z1-1e-4)).sum())
    own = sorted({owner[i] for i in bad_tris})
    res.append(dict(slot=s.name, overlapping_triangles=len(bad_tris), vertices_inside=inside, objects=own[:6]))
R['slot_overlap'] = res
R['slots_overlapping'] = [r['slot'] for r in res if r['overlapping_triangles'] or r['vertices_inside']]
# --- 4 line of sight to cameras (sky dome hidden)
for o in objs:
    if o.name.startswith('Sky_Dome'): o.hide_viewport = True
bpy.context.view_layer.update()
dg = bpy.context.evaluated_depsgraph_get()
sc = bpy.context.scene
cams = {n: bpy.data.objects[n] for n in ('CAM_Game_Perspective', 'CAM_Game_Isometric_Ortho')}
los = {}
for cn, cam in cams.items():
    blocked = []
    for s in slots:
        w, l = s['envelope_width_m'], s['envelope_length_m']
        m = s.matrix_world
        pts = [Vector((0, 0, 1.0))] + [Vector((sx * w / 2, sy * l / 2, 0.5)) for sx in (-1, 1) for sy in (-1, 1)]
        for k, p in enumerate(pts):
            wp = m @ p
            if cam.data.type == 'PERSP':
                d = cam.location - wp
            else:
                d = -(cam.matrix_world.to_quaternion() @ Vector((0, 0, -1)))   # towards camera
            dist = d.length if cam.data.type == 'PERSP' else 400.0
            hit, loc_, nrm, idx_, ob, mx = sc.ray_cast(dg, wp, d.normalized(), distance=dist)
            if hit:
                blocked.append((s.name, k, ob.name, round((loc_ - wp).length, 1)))
    los[cn] = dict(rays=len(slots) * 5, blocked=len(blocked), blocked_detail=blocked[:40])
R['line_of_sight'] = los
# --- 5 clearance above slot centre
clear = {}
for s in slots:
    wp = s.matrix_world @ Vector((0, 0, 0.1))
    hit, loc_, nrm, idx_, ob, mx = sc.ray_cast(dg, wp, Vector((0, 0, 1)), distance=100)
    clear[s.name] = round((loc_.z - s.location.z), 2) if hit else None
R['overhead_clearance_m'] = clear
R['min_overhead_clearance_m'] = min((v for v in clear.values() if v is not None), default=None)

# --- 6 ground alignment: ray down from 1 m above centre + 4 corners; hit height must be within 0.15 m of the slot origin z
align = []
for s in slots:
    w, l = s['envelope_width_m'], s['envelope_length_m']; m = s.matrix_world
    worst = 0.0; miss = 0
    for p in [Vector((0, 0, 0))] + [Vector((sx * w / 2 * 0.9, sy * l / 2 * 0.9, 0)) for sx in (-1, 1) for sy in (-1, 1)]:
        wp = m @ Vector((p.x, p.y, 0)); wp.z = s.location.z + 1.0
        hit, loc_, nrm, idx_, ob, mx = sc.ray_cast(dg, wp, Vector((0, 0, -1)), distance=20)
        if not hit: miss += 1; continue
        worst = max(worst, abs(loc_.z - s.location.z))
    align.append(dict(slot=s.name, worst_dz=round(worst, 3), misses=miss))
R['ground_alignment'] = align
R['slots_misaligned'] = [a['slot'] for a in align if a['worst_dz'] > 0.15 or a['misses']]
# slot summary
R['slot_types'] = {}
for s in slots: R['slot_types'][s['slot_type']] = R['slot_types'].get(s['slot_type'], 0) + 1
json.dump(R, open(os.path.join(OUT, OUTNAME), 'w'), indent=1)
print("VALIDATION_DONE")
print(json.dumps({k: R[k] for k in ('objects_total','vehicle_name_hits','max_texture_px','all_images_packed','slot_count','slots_overlapping','min_overhead_clearance_m','slot_types','slots_misaligned')}, indent=1))
print({k: (v['blocked'], v['rays']) for k, v in los.items()})
