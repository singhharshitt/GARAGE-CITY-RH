# CHANGELOG V3 (vs V2)

V1 (`/workspace/garage_city/`) and V2 (`/workspace/garage_city_v2/`) are untouched (no file in either folder is newer than the V3 folder's creation time). V3 is `/workspace/garage_city_v3/`, evolved from a copy of V2. Same layout, same 57 SLOT_* anchors, same coordinate system, same two game cameras.

## Added / changed
* **Garage/showcase polish:** calmer, more intentional emissives (amber interiors, cyan EV/technical), baked AO and lighting tuned so the compound and the ringed showcase read as the focal point; see previews. (Geometry of the garage core was kept from V2; triangles 38,600 → 48,834 in `garage_core.glb`.)
* **City:** window emissive reduced (lit probabilities 0.18–0.24, estr 0.20–0.70), fewer rooftop gardens (probability gated), lower far-shore heights, new park generator (lawn + hedges + bush/tree/palm mix, or paved plaza with planters/benches), layered lumpy tree canopies (`tree0/tree1`).
* **Waterfront in gameplay frame:** basin + low north row added so water is visible in `CAM_Game_Perspective` without touching slots/cameras; calm water texture, restrained highlights.
* **Sky:** gradient moved toward sunset→blue-hour (see `gc_lib.py`).
* **Baked vertex AO** (`gc_ao.py`): ray-cast AO in `COLOR_0` (uint8) in every GLB, baseColor only.
* **Export (`gc_export.py`, `tools/postprocess_glb.mjs`):** compat set (no extensions beyond emissive/specular) + optimized set (instancing, quantization, meshopt) + KTX2 and Draco variants; spatial batching; `prune(keepLeaves)` so SLOT empties survive.
* **Runtime:** `web/quality_modes.js` (full / balanced / low: pixel ratio, AA, shadows, tone mapping, hide-by-distance LOD, light values).
* **Cameras:** added non-gameplay `CAM_V3_Hero_Skyline` and `CAM_V3_Close_Detail` (the gameplay camera cannot see the skyline by geometry).
* **Tooling/validation:** `validate_glb_three.mjs` (keep-clear + sight-line on shipped GLB geometry, negative control), `run_validate.sh`, perf harness `tools/perf/` (puppeteer + SwiftShader), `gen_docs.py`, `COMPARISON_V1_V2_V3.md`, `PROGRESS.md`.

## Numbers (see COMPARISON_V1_V2_V3.md)
Combined compat GLB 11.38 MB → 11.30 MB, 153,832 → 166,305 triangles, 656 → 582 primitives; optimized 3.70 MB (KTX2 3.64, Draco 2.14). Measured (software GL, gameplay cam, quality 0): draw calls V2 532 / V3 compat 493 / V3 optimized 577; frame time V3 ≈ +12–24% vs V2. **Real-device performance not tested.**

## Honest notes
* No texture/material atlasing was done; draw-call reduction is therefore small and the optimized set has slightly more draw calls than the compat set.
* Zone colours of bay markings (cyan/amber/violet/magenta) kept for gameplay readability, a deliberate deviation from "violet/magenta only in the distant skyline".
* The hero skyline view is brighter/taller than ideal against the reference; gameplay/iso views carry the intended hierarchy.
