# Garage City RH — V3 3D environment pack (empty, vehicle-free)

V3 = polish pass on V2 (same layout, same 57 slot anchors, same coordinate system). Built by `run.sh` (Blender 4.2.3 LTS, Python/bmesh, fully procedural) + `tools/postprocess_glb.mjs` (gltf-transform). **No vehicles, motorcycles, traffic or silhouettes anywhere; all 57 slots are empty and unobstructed** (checked, §11). **No real-device performance testing was done — see `validation_report.md`.**

## 1. Scene description

* **Garage core (hierarchy 1):** walled compound around an open paved yard; glazed amber-lit showroom/workshop frontages with interiors (benches, cabinets, racks), taller workshop volumes with roof silhouettes (parapets, roof plant, vents), service block with stairs/skybridge elements, fuel and EV canopies, gate, planters and boundary hedges. **Central showcase:** layered circular platform with inset light rings, framing arches and lighting masts, strong contrast against the yard floor — still empty (the single `showcase` slot).
* **Roads / highways:** road grid with lane markings, kerbs, sidewalks, junction crosswalks, elevated highway with pillars, barriers, expansion joints and ramps, roadside lights.
* **City:** near blocks (rooftop mechanicals, some roof gardens), parks with a varied tree/palm/bush mix, layered far-shore skyline (landmark towers with distinct silhouettes, progressively simpler/less emissive with distance), distant chunks and mountain ridge, gradient sky dome tuned to sunset→blue hour.
* **Waterfront:** quay/promenade edges and basin; water is a calm cheap material (no reflections). The basin is visible in the gameplay camera (a low north row and basin were added in V3 without touching slots or the original game cameras).

Colour deviation from the concept brief: the four zone colours of the bay markings (cyan / amber / violet / magenta) are kept because they are gameplay readability cues from V1/V2; violet/magenta elsewhere is restricted to distant skyline accents.

## 2. Files — which one to load (READ THIS)

**Two interchangeable sets. Load exactly one set. Never load a combined file together with split files, and never load a compat file together with an optimized file** (they contain the same world content in the same coordinates; loading both duplicates everything).

| set | files | extensions | decoders needed |
|---|---|---|---|
| **A. compat (V2-style, safest)** | `garage_city_environment.glb` (combined) or the 4 split: `garage_core.glb`, `roads_and_highways.glb`, `city_background.glb`, `waterfront.glb` | KHR_materials_emissive_strength, KHR_materials_specular only | none |
| **B. optimized** | `optimized/garage_city_environment.opt.glb` (combined) or `optimized/{garage_core,roads_and_highways,city_background,waterfront}.opt.glb` | + KHR_mesh_quantization, EXT_mesh_gpu_instancing, EXT_meshopt_compression | MeshoptDecoder (+ three r150+ GLTFLoader) |
| B+KTX2 | `optimized/*.opt.ktx2.glb` | + KHR_texture_basisu | MeshoptDecoder + KTX2Loader (basis transcoder) |
| B+Draco (combined only) | `optimized/garage_city_environment.opt.draco.glb` | KHR_draco_mesh_compression (no meshopt) | DRACOLoader |

| file | bytes | triangles (static) | primitives | materials | notes |
|---|---:|---:|---:|---:|---|
| garage_city_environment.glb | 11,300,088 | 166,305 | 582 | 75 | compat; props merged into spatial chunks |
| garage_core.glb | 3,521,000 | 48,834 | 210 | 47 | compat; props merged into spatial chunks |
| roads_and_highways.glb | 3,429,060 | 47,971 | 104 | 18 | compat; props merged into spatial chunks |
| city_background.glb | 4,183,940 | 55,662 | 221 | 53 | compat; props merged into spatial chunks |
| waterfront.glb | 1,017,108 | 13,838 | 47 | 17 | compat; props merged into spatial chunks |
| optimized/garage_city_environment.opt.glb | 3,704,932 | 166,305 (three.js, instances expanded) | – | – | instanced props + quantization + meshopt |
| optimized/garage_core.opt.glb | 1,700,588 | 48,834 (three.js, instances expanded) | – | – | instanced props + quantization + meshopt |
| optimized/roads_and_highways.opt.glb | 915,768 | 47,971 (three.js, instances expanded) | – | – | instanced props + quantization + meshopt |
| optimized/city_background.opt.glb | 1,645,032 | 55,662 (three.js, instances expanded) | – | – | instanced props + quantization + meshopt |
| optimized/waterfront.opt.glb | 350,532 | 13,838 (three.js, instances expanded) | – | – | instanced props + quantization + meshopt |
| optimized/garage_city_environment.opt.ktx2.glb | 3,642,324 | same as opt | – | – | textures as KTX2 (UASTC/ETC1S via toktx) |
| optimized/garage_core.opt.ktx2.glb | 1,536,132 | same as opt | – | – | textures as KTX2 (UASTC/ETC1S via toktx) |
| optimized/roads_and_highways.opt.ktx2.glb | 857,660 | same as opt | – | – | textures as KTX2 (UASTC/ETC1S via toktx) |
| optimized/city_background.opt.ktx2.glb | 1,642,924 | same as opt | – | – | textures as KTX2 (UASTC/ETC1S via toktx) |
| optimized/waterfront.opt.ktx2.glb | 329,288 | same as opt | – | – | textures as KTX2 (UASTC/ETC1S via toktx) |
| optimized/garage_city_environment.opt.draco.glb | 2,135,520 | ≈ same (Draco is lossy-quantized) | – | – | Draco mesh compression |
| garage_city_environment.blend | 2,409,827 | 158,763 (unmerged) | – | 75 | editable source, packed textures ≤512 px, slot empties intact |

`slots.json` (independent file, 57 entries), `slots_v1.json`/`slots_v2.json` (baselines), `textures/` (19 PNG, ≤512 px; embedded in the compat GLBs). Slots are **never merged into render meshes**: they are empty nodes named `SLOT_*` in every GLB variant.

Previews (all rendered from the shipped optimized GLB in three.js with SwiftShader software GL, full quality mode, 1600×900): `preview_game_camera.png` (CAM_Game_Perspective), `preview_iso_ortho.png` (CAM_Game_Isometric_Ortho), `preview_close_detail.png` (CAM_V3_Close_Detail), `preview_skyline_wide.png` (CAM_Preview_Skyline), `preview_hero_skyline.png` (CAM_V3_Hero_Skyline). The old Eevee previews were replaced; Eevee/.blend does not contain the baked vertex AO.

## 3. Coordinate system & slots (unchanged from V1/V2)

* Blender: 1 unit = 1 m, **+Z up**, +X east, +Y north, compound centred on the origin. glTF/three.js: **+Y up**; Blender (x, y, z) → glTF (x, z, −y). Slot local **+Y is the nose (glTF −Z)**.
* Slot empties carry `extras` (slot_type, zone, note, nose_dir, envelope_width/length/height_m, forward axis); three.js exposes them in `userData`. Counts: 26 parking, 4 VIP, 6 display, 6 EV, 6 fuel, 8 lift, 1 showcase.

| name | type | zone | Blender x, y, z | glTF pos | yaw° | env W×L×H |
|---|---|---|---|---|---:|---|
| SLOT_bay_01 | parking | A | -64.50, -44.00, 0.00 | -64.50, 0.00, 44.00 | 180 | 2.5×5.0×1.9 |
| SLOT_bay_02 | parking | A | -64.50, -30.00, 0.00 | -64.50, 0.00, 30.00 | 0 | 2.5×5.0×1.9 |
| SLOT_bay_03 | parking | A | -61.20, -44.00, 0.00 | -61.20, 0.00, 44.00 | 180 | 2.5×5.0×1.9 |
| SLOT_bay_04 | parking | A | -61.20, -30.00, 0.00 | -61.20, 0.00, 30.00 | 0 | 2.5×5.0×1.9 |
| SLOT_bay_05 | parking | A | -57.90, -44.00, 0.00 | -57.90, 0.00, 44.00 | 180 | 2.5×5.0×1.9 |
| SLOT_bay_06 | parking | A | -57.90, -30.00, 0.00 | -57.90, 0.00, 30.00 | 0 | 2.5×5.0×1.9 |
| SLOT_bay_07 | parking | A | -54.60, -44.00, 0.00 | -54.60, 0.00, 44.00 | 180 | 2.5×5.0×1.9 |
| SLOT_bay_08 | parking | A | -54.60, -30.00, 0.00 | -54.60, 0.00, 30.00 | 0 | 2.5×5.0×1.9 |
| SLOT_bay_09 | parking | A | -51.30, -44.00, 0.00 | -51.30, 0.00, 44.00 | 180 | 2.5×5.0×1.9 |
| SLOT_bay_10 | parking | A | -51.30, -30.00, 0.00 | -51.30, 0.00, 30.00 | 0 | 2.5×5.0×1.9 |
| SLOT_bay_11 | parking | A | -48.00, -44.00, 0.00 | -48.00, 0.00, 44.00 | 180 | 2.5×5.0×1.9 |
| SLOT_bay_12 | parking | A | -48.00, -30.00, 0.00 | -48.00, 0.00, 30.00 | 0 | 2.5×5.0×1.9 |
| SLOT_bay_13 | parking | B | -64.50, -18.00, 0.00 | -64.50, 0.00, 18.00 | 180 | 2.5×5.0×1.9 |
| SLOT_bay_14 | parking | B | -64.50, -4.00, 0.00 | -64.50, 0.00, 4.00 | 0 | 2.5×5.0×1.9 |
| SLOT_bay_15 | parking | B | -61.20, -18.00, 0.00 | -61.20, 0.00, 18.00 | 180 | 2.5×5.0×1.9 |
| SLOT_bay_16 | parking | B | -61.20, -4.00, 0.00 | -61.20, 0.00, 4.00 | 0 | 2.5×5.0×1.9 |
| SLOT_bay_17 | parking | B | -57.90, -18.00, 0.00 | -57.90, 0.00, 18.00 | 180 | 2.5×5.0×1.9 |
| SLOT_bay_18 | parking | B | -57.90, -4.00, 0.00 | -57.90, 0.00, 4.00 | 0 | 2.5×5.0×1.9 |
| SLOT_bay_19 | parking | B | -54.60, -18.00, 0.00 | -54.60, 0.00, 18.00 | 180 | 2.5×5.0×1.9 |
| SLOT_bay_20 | parking | B | -54.60, -4.00, 0.00 | -54.60, 0.00, 4.00 | 0 | 2.5×5.0×1.9 |
| SLOT_bay_21 | parking | C | -48.00, -18.00, 0.00 | -48.00, 0.00, 18.00 | 180 | 2.5×5.0×1.9 |
| SLOT_bay_22 | parking | C | -48.00, -4.00, 0.00 | -48.00, 0.00, 4.00 | 0 | 2.5×5.0×1.9 |
| SLOT_bay_23 | parking | C | -44.40, -18.00, 0.00 | -44.40, 0.00, 18.00 | 180 | 2.5×5.0×1.9 |
| SLOT_bay_24 | parking | C | -44.40, -4.00, 0.00 | -44.40, 0.00, 4.00 | 0 | 2.5×5.0×1.9 |
| SLOT_bay_25 | parking | C | -40.80, -18.00, 0.00 | -40.80, 0.00, 18.00 | 180 | 2.5×5.0×1.9 |
| SLOT_bay_26 | parking | C | -40.80, -4.00, 0.00 | -40.80, 0.00, 4.00 | 0 | 2.5×5.0×1.9 |
| SLOT_bay_27 | parking_vip | D | -9.00, 13.00, 0.12 | -9.00, 0.12, -13.00 | 180 | 2.5×5.0×1.9 |
| SLOT_bay_28 | parking_vip | D | -3.00, 13.00, 0.12 | -3.00, 0.12, -13.00 | 180 | 2.5×5.0×1.9 |
| SLOT_bay_29 | parking_vip | D | 3.00, 13.00, 0.12 | 3.00, 0.12, -13.00 | 180 | 2.5×5.0×1.9 |
| SLOT_bay_30 | parking_vip | D | 9.00, 13.00, 0.12 | 9.00, 0.12, -13.00 | 180 | 2.5×5.0×1.9 |
| SLOT_showcase_01 | showcase | S | 0.00, 0.00, 0.50 | 0.00, 0.50, -0.00 | 28 | 2.7×5.4×2.2 |
| SLOT_display_01 | display | E | -51.00, 22.00, 0.45 | -51.00, 0.45, -22.00 | 162 | 2.5×5.0×1.9 |
| SLOT_display_02 | display | E | -43.00, 22.00, 0.45 | -43.00, 0.45, -22.00 | 198 | 2.5×5.0×1.9 |
| SLOT_display_03 | display | E | -35.00, 22.00, 0.45 | -35.00, 0.45, -22.00 | 162 | 2.5×5.0×1.9 |
| SLOT_display_04 | display | E | -27.00, 22.00, 0.45 | -27.00, 0.45, -22.00 | 198 | 2.5×5.0×1.9 |
| SLOT_display_05 | display | E | -19.00, 22.00, 0.45 | -19.00, 0.45, -22.00 | 162 | 2.5×5.0×1.9 |
| SLOT_display_06 | display | E | -11.00, 22.00, 0.45 | -11.00, 0.45, -22.00 | 198 | 2.5×5.0×1.9 |
| SLOT_lift_01 | lift | W | 46.00, -14.00, 0.28 | 46.00, 0.28, 14.00 | -90 | 2.5×5.0×2.0 |
| SLOT_lift_02 | lift | W | 46.00, -7.60, 0.28 | 46.00, 0.28, 7.60 | -90 | 2.5×5.0×2.0 |
| SLOT_lift_03 | lift | W | 46.00, -1.20, 0.28 | 46.00, 0.28, 1.20 | -90 | 2.5×5.0×2.0 |
| SLOT_lift_04 | lift | W | 46.00, 5.20, 0.28 | 46.00, 0.28, -5.20 | -90 | 2.5×5.0×2.0 |
| SLOT_lift_05 | lift | W | 16.00, 29.00, 0.28 | 16.00, 0.28, -29.00 | 0 | 2.5×5.0×2.0 |
| SLOT_lift_06 | lift | W | 22.40, 29.00, 0.28 | 22.40, 0.28, -29.00 | 0 | 2.5×5.0×2.0 |
| SLOT_lift_07 | lift | W | 28.80, 29.00, 0.28 | 28.80, 0.28, -29.00 | 0 | 2.5×5.0×2.0 |
| SLOT_lift_08 | lift | W | 35.20, 29.00, 0.28 | 35.20, 0.28, -29.00 | 0 | 2.5×5.0×2.0 |
| SLOT_fuel_01 | fuel | F | -33.60, -37.50, 0.00 | -33.60, 0.00, 37.50 | 0 | 2.5×5.0×1.9 |
| SLOT_fuel_02 | fuel | F | -28.40, -37.50, 0.00 | -28.40, 0.00, 37.50 | 0 | 2.5×5.0×1.9 |
| SLOT_fuel_03 | fuel | F | -23.60, -37.50, 0.00 | -23.60, 0.00, 37.50 | 0 | 2.5×5.0×1.9 |
| SLOT_fuel_04 | fuel | F | -18.40, -37.50, 0.00 | -18.40, 0.00, 37.50 | 0 | 2.5×5.0×1.9 |
| SLOT_fuel_05 | fuel | F | -13.60, -37.50, 0.00 | -13.60, 0.00, 37.50 | 0 | 2.5×5.0×1.9 |
| SLOT_fuel_06 | fuel | F | -8.40, -37.50, 0.00 | -8.40, 0.00, 37.50 | 0 | 2.5×5.0×1.9 |
| SLOT_ev_01 | ev_charge | V | 27.00, -40.00, 0.00 | 27.00, 0.00, 40.00 | 0 | 2.5×5.0×1.9 |
| SLOT_ev_02 | ev_charge | V | 31.50, -40.00, 0.00 | 31.50, 0.00, 40.00 | 0 | 2.5×5.0×1.9 |
| SLOT_ev_03 | ev_charge | V | 36.00, -40.00, 0.00 | 36.00, 0.00, 40.00 | 0 | 2.5×5.0×1.9 |
| SLOT_ev_04 | ev_charge | V | 40.50, -40.00, 0.00 | 40.50, 0.00, 40.00 | 0 | 2.5×5.0×1.9 |
| SLOT_ev_05 | ev_charge | V | 45.00, -40.00, 0.00 | 45.00, 0.00, 40.00 | 0 | 2.5×5.0×1.9 |
| SLOT_ev_06 | ev_charge | V | 49.50, -40.00, 0.00 | 49.50, 0.00, 40.00 | 0 | 2.5×5.0×1.9 |

## 4. Collections (.blend)

| collection | objects | triangles |
|---|---:|---:|
| Garage_City_RH | 1076 | 158,763 |
| &nbsp;&nbsp;01_Garage_Core | 232 | 41,292 |
| &nbsp;&nbsp;&nbsp;&nbsp;Core_Buildings | 20 | 20,262 |
| &nbsp;&nbsp;&nbsp;&nbsp;Core_Parking | 2 | 596 |
| &nbsp;&nbsp;&nbsp;&nbsp;Core_Showcase_Display | 3 | 3,536 |
| &nbsp;&nbsp;&nbsp;&nbsp;Core_Workshops_Lifts | 3 | 3,132 |
| &nbsp;&nbsp;&nbsp;&nbsp;Core_Fuel_EV | 39 | 5,200 |
| &nbsp;&nbsp;&nbsp;&nbsp;Core_Circulation | 5 | 1,168 |
| &nbsp;&nbsp;&nbsp;&nbsp;Core_Details | 35 | 3,616 |
| &nbsp;&nbsp;&nbsp;&nbsp;Core_Walls_Yard | 3 | 332 |
| &nbsp;&nbsp;&nbsp;&nbsp;Core_Vegetation | 65 | 3,450 |
| &nbsp;&nbsp;&nbsp;&nbsp;Core_Car_Slots | 57 | 0 |
| &nbsp;&nbsp;02_Roads_Highways | 302 | 47,971 |
| &nbsp;&nbsp;&nbsp;&nbsp;Road_Network | 6 | 5,760 |
| &nbsp;&nbsp;&nbsp;&nbsp;Road_Road_Props | 201 | 13,965 |
| &nbsp;&nbsp;&nbsp;&nbsp;Road_Highways | 95 | 28,246 |
| &nbsp;&nbsp;03_City_Background | 326 | 54,636 |
| &nbsp;&nbsp;&nbsp;&nbsp;City_Blocks_Near | 43 | 17,918 |
| &nbsp;&nbsp;&nbsp;&nbsp;City_Vegetation | 270 | 21,196 |
| &nbsp;&nbsp;&nbsp;&nbsp;City_Skyline | 13 | 15,522 |
| &nbsp;&nbsp;04_Waterfront | 207 | 13,838 |
| &nbsp;&nbsp;&nbsp;&nbsp;Water_Main | 5 | 4,326 |
| &nbsp;&nbsp;&nbsp;&nbsp;Water_Props | 202 | 9,512 |
| &nbsp;&nbsp;05_Atmosphere | 2 | 1,026 |
| &nbsp;&nbsp;06_Camera_Lights | 7 | 0 |

`Core_Car_Slots` is the V1 collection name of the (empty) slot anchors; kept so the hierarchy is unchanged.

## 5. Materials & textures

75 materials (Principled BSDF → glTF PBR, emissive via emissiveFactor + KHR_materials_emissive_strength). Textures (≤512 px, tileable/atlas): `tex_asphalt` 256×256, `tex_brushed_steel` 256×256, `tex_concrete_dark` 256×256, `tex_concrete_light` 256×256, `tex_concrete_warm` 256×256, `tex_floor_yard` 256×256, `tex_glow_soft` 128×128, `tex_graphite_panel` 256×256, `tex_hazard` 128×128, `tex_paving` 256×256, `tex_sky_gradient` 8×512, `tex_water_ripple` 256×256, `tex_windows_bands` 512×512, `tex_windows_cool` 512×512, `tex_windows_curtain` 512×512, `tex_windows_fins` 512×512, `tex_windows_neon` 512×512, `tex_windows_punched` 512×512, `tex_windows_warm` 512×512.

**Baked vertex AO:** each GLB carries a `COLOR_0` (uint8 normalized) vertex colour = ray-cast ambient occlusion (BVH, large up-facing faces subdivided ≈2.6 m first), multiplied into baseColor only (emissives unaffected). Zero runtime cost. The .blend keeps white vertex colour. Materials use `vertexColors` automatically in three.js when COLOR_0 exists.

## 6. Cameras

* **CAM_Game_Perspective** (PERSP): Blender location [-111.37, -114.37, 83.39], rotation° [61.0, -0.0, -45.0], horizontal FOV 62.0°
* **CAM_Game_Isometric_Ortho** (ORTHO): Blender location [-346.41, -338.41, 346.41], rotation° [54.74, 0.0, -45.0], ortho_scale 215.0
* **CAM_Preview_Skyline** (PERSP): Blender location [-296.77, -236.77, 145.8], rotation° [76.0, 0.0, -45.0], horizontal FOV 72.0°
* **CAM_V3_Hero_Skyline** (PERSP): Blender location [-150.0, -118.0, 44.0], rotation° [91.27, 0.0, -46.05], horizontal FOV 64.0°
* **CAM_V3_Close_Detail** (PERSP): Blender location [-30.0, -27.0, 8.5], rotation° [84.71, 0.0, -36.63], horizontal FOV 60.0°

`CAM_Game_Perspective` and `CAM_Game_Isometric_Ortho` are **unchanged from V1/V2**. `CAM_Preview_Skyline`, `CAM_V3_Hero_Skyline`, `CAM_V3_Close_Detail` are non-gameplay preview cameras. **Layout/camera note:** the gameplay camera's top-of-frame is ≈10° below the horizon, so it can never show the skyline; the waterfront (basin + water row) was brought into the gameplay frame by layout changes (not by moving the camera). The skyline is shown by the hero/skyline cameras only.

## 7. Quality modes, LOD and loading code

`web/quality_modes.js` (ES module, three r160+, developed against r169) exports `QUALITY`, `LIGHTS`, `DistanceLOD`, `applyQuality(renderer, scene, camera, 'full'|'balanced'|'low')`. No post-processing in any mode.

| mode | pixel ratio cap | AA | shadows | hide-by-distance (m): props / city chunks / far skyline / distant chunks | tone mapping |
|---|---|---|---|---|---|
| full (desktop) | 2.0 | on | 2048 map, ±110 m, PCFSoft (compound only) | 700 / ∞ / ∞ / ∞ | AgX |
| balanced | 1.25 | on | 1024 map, ±90 m, PCF | 320 / 900 / ∞ / 1400 | AgX |
| low (target 30 fps min — UNVERIFIED) | 1.0 | off | none | 190 / 520 / 900 / 700 | none (sRGB) |

**Runtime LOD scheme:** documented *hide-by-distance* (`DistanceLOD`): object-name rules (props/vegetation, city chunks, far skyline, distant skyline/ridge) get a bounding sphere once; `update(camera)` toggles `.visible` every 8 frames. Frustum culling stays on (default). Instanced props are culled per InstancedMesh (one bounding sphere per chunk-cell).

**Light values (not exported in the GLB):** warm key `DirectionalLight(0xffb083, 2.0)` direction-to-light (−0.545, 0.309, −0.779) (glTF space) placed ×300 m; cool fill `HemisphereLight(sky 0x3b6fd6, ground 0x10161f, 1.25)`; exposure 1.0; AgX tone mapping (full/balanced). Background/fog: sky dome in the GLB (`Sky_Dome`, fog=false); optional `Fog(0x1a2a5c, 300, 1800)`. Blender authoring values: Sun (1.0, 0.55, 0.32) E=3.4 rot (72°,0°,215°), sky-fill sun E=2.2, world ambient.

### Three.js (set A or B; one combined file OR four split files)

```js
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js';   // set B / B+KTX2
import { KTX2Loader } from 'three/addons/loaders/KTX2Loader.js';                  // only for *.opt.ktx2.glb
import { DRACOLoader } from 'three/addons/loaders/DRACOLoader.js';                // only for *.opt.draco.glb
import { applyQuality } from './web/quality_modes.js';

const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
const scene = new THREE.Scene(), loader = new GLTFLoader().setMeshoptDecoder(MeshoptDecoder);
// decoder setup (copy these folders from three/examples/jsm/libs to your public dir):
loader.setKTX2Loader(new KTX2Loader().setTranscoderPath('/libs/basis/').detectSupport(renderer));      // KTX2 variant only
loader.setDRACOLoader(new DRACOLoader().setDecoderPath('/libs/draco/gltf/'));                          // Draco variant only
const gltf = await loader.loadAsync('/optimized/garage_city_environment.opt.glb');   // OR '/garage_city_environment.glb' (compat, no decoders)
scene.add(gltf.scene);
const cam = gltf.cameras.find(c => c.parent?.name === 'CAM_Game_Perspective' || c.name === 'CAM_Game_Perspective'); // cameras are in the combined file only
cam.aspect = innerWidth / innerHeight; cam.updateProjectionMatrix();
const { lod } = applyQuality(renderer, scene, cam, 'balanced');   // lights, shadows, pixel ratio, tone mapping, LOD
renderer.setAnimationLoop(() => { lod.update(cam); renderer.render(scene, cam); });
const slot = gltf.scene.getObjectByName('SLOT_bay_01');            // empty anchor; nose = local -Z; userData = slot metadata
```

Sky dome: `Sky_Dome` radius 1300 m — keep camera far ≥ 2500 (game cameras: 2600/2500), `frustumCulled=false`, `depthWrite=false`, `renderOrder=-10`, `material.fog=false`. Glow decals (`glow_*` materials): consider `depthWrite=false` + small polygonOffset if z-fighting appears (not needed in the harness previews).

### React Three Fiber

```jsx
import { useEffect, useRef } from 'react';
import { useThree, useFrame } from '@react-three/fiber';
import { useGLTF } from '@react-three/drei';   // drei's useGLTF enables the Meshopt decoder by default (Draco optional)
import { applyQuality } from './web/quality_modes.js';
function City({ mode = 'balanced' }) {
  const { scene } = useGLTF('/optimized/garage_city_environment.opt.glb');      // or the compat file
  const { gl, camera } = useThree(), lodRef = useRef();
  useEffect(() => { const q = applyQuality(gl, scene, camera, mode); lodRef.current = q.lod; return () => scene.remove(q.sun, q.sun.target, q.hemi); }, [mode]);
  useFrame(() => lodRef.current?.update(camera));
  return <primitive object={scene} />;
}
```
(R3F snippet is illustrative and **not executed** in this build; the vanilla three.js path is what the harness runs.)

## 8. Integration rules (duplication guard)

* Loading config must reference **either** `garage_city_environment[.opt].glb` **or** the four split files of the same set, never both, never A+B. The perf harness (`tools/perf/perf.html`) takes a single GLB list and the quality-mode code assumes one scene copy. Split files do not contain cameras; the combined file contains 5 cameras.
* Split files share one world coordinate system (no offsets).

## 9. Optimization techniques actually used

* Shared materials (75 in combined compat file), textures ≤512 px, vertex-colour AO instead of lightmaps.
* Spatial batching of non-interactive static props into per-material chunks (compat set; cell 200–600 m); interactive/slot-related objects are not merged.
* **EXT_mesh_gpu_instancing** (optimized set): 859 repeated prop nodes → 93 instanced nodes in the combined file; verified in three.js (243 InstancedMesh, 2,423 instances, triangle count identical to the compat file: 166,305).
* KHR_mesh_quantization + EXT_meshopt_compression (set B); Draco and KTX2 variants. KTX2: 743,443 → 680,122 bytes of texture payload (toktx 4.3.x). Texcoords are not quantized below 16-bit.
* Hide-by-distance runtime LOD, minimal real-time shadows (compound only), no post-processing, calm water (no reflections), reduced bright window grids.
* **Not done:** material/texture atlasing (draw calls are driven by chunks × materials), geometry LOD meshes, occlusion culling.

## 10. Measured performance (software rendering only)

All numbers: SwiftShader CPU WebGL in headless Chrome, 8-core box — **relative only, NOT device FPS; real-device 30 fps minimum / 60 fps capability is UNVERIFIED.** Full tables: `perf_report.md`, `perf_results.json`.

| gameplay cam, quality 0 (no shadow/LOD) | V1 | V2 | V3 compat | V3 optimized |
|---|---:|---:|---:|---:|
| GLB MB (1280×720) | 4.56 | 10.85 | 10.78 | 3.53 |
| download ms (localhost) (1280×720) | 37.4 | 66.2 | 56.4 | 27.3 |
| parse+tex ms (1280×720) | 72.4 | 60 | 66 | 72.1 |
| heap Δ after load MB (1280×720) | 23.9 | 36.7 | 36.2 | 19.7 |
| draw calls (renderer.info) (1280×720) | 1124 | 532 | 493 | 577 |
| triangles drawn (1280×720) | 74457 | 138331 | 157925 | 144137 |
| geometries (1280×720) | 352 | 525 | 489 | 438 |
| textures (1280×720) | 6 | 14 | 18 | 18 |
| frame median ms @ 1280×720 (software) | 104.6 | 120.1 | 134.6 | 138.7 |
| frame median ms @ 800×450 (software) | 59.8 | 75.5 | 93.6 | 91.9 |

## 11. Validation summary (details in `validation_report.md`)

57/57 slots identical to V1 and V2 (Blender world matrices, custom props, collections and slots.json; also GLB node transforms/userData). gltf-validator: 0 errors on all 16 GLBs. Keep-clear boxes and sight-line rays (285 per camera) vs all geometry: 0 overlaps, 0 blocked, with negative controls that are detected. Name-based vehicle scan: 0 hits (no shape detector exists; the visual review found no vehicle shapes).

## 12. Known limitations

* Real-device performance is unverified. In software rendering V3 is *not* faster than V2 per frame (§10); the wins are download size / heap, not draw calls.
* Draw calls are still ~500 (chunks × materials); the optimized set has *more* draw calls than the compat set because each instanced prop proto×material is a separate InstancedMesh.
* No atlasing; Eevee vs three.js looks differ; no reflections/rain; skyline in the hero view is brighter/taller than the reference hierarchy would ideally allow, though it is outside the gameplay frame.
* Vehicle absence rests on construction + name scan + visual review; no shape-based detector.
* Draco/KTX2 variants: loaded and rendered in the browser harness; keep-clear/LOS checked on the meshopt files only (same geometry as KTX2; Draco geometry is lossy-quantized and was not re-run through the clearance test). gltf-validator reports KTX2 warnings (§validation_report) because it does not know KHR_texture_basisu.
