// node threejs_load_test.mjs   (needs `npm i three` ; headless GLTFLoader.parse of every GLB, no rendering)
import fs from 'fs'; import path from 'path'; import { fileURLToPath } from 'url';
import { createRequire } from 'module';
const here = path.dirname(fileURLToPath(import.meta.url));
const THREE_DIR = process.env.THREE_DIR || '/workspace/threetest/node_modules/three';
globalThis.self = globalThis;
globalThis.createImageBitmap = async () => ({ width: 8, height: 8, close() {} });   // stub: textures are not decoded in node
const THREE = await import(THREE_DIR + '/build/three.module.js');
const { GLTFLoader } = await import(THREE_DIR + '/examples/jsm/loaders/GLTFLoader.js');
const BASE = ['garage_city_environment', 'garage_core', 'roads_and_highways', 'city_background', 'waterfront'];
// compat GLBs + meshopt-optimized GLBs (draco + KTX2 variants need DRACOLoader workers / WebGL: those are verified in the browser harness instead)
const files = BASE.map(b => b + '.glb').concat(BASE.map(b => 'optimized/' + b + '.opt.glb'));
const { MeshoptDecoder } = await import(THREE_DIR + '/examples/jsm/libs/meshopt_decoder.module.js');
const slotsJson = JSON.parse(fs.readFileSync(path.join(here, 'slots.json'), 'utf8'));
const out = { three_revision: THREE.REVISION, files: {} };
for (const f of files) {
  if (!fs.existsSync(path.join(here, f))) { out.files[f] = { loaded: false, error: 'missing' }; continue; }
  const buf = fs.readFileSync(path.join(here, f));
  const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
  const r = await new Promise((res) => new GLTFLoader().setMeshoptDecoder(MeshoptDecoder).parse(ab, '', (g) => res({ ok: true, g }), (e) => res({ ok: false, e: String(e && e.message || e) })));
  if (!r.ok) { out.files[f] = { loaded: false, error: r.e }; continue; }
  const scene = r.g.scene; let meshes = 0, tris = 0, prims = 0, inst = 0, instMeshes = 0; const mats = new Set(); const slots = [];
  scene.traverse((o) => {
    if (o.isMesh) { meshes++; prims++; const idx = o.geometry.index; tris += ((idx ? idx.count : o.geometry.attributes.position.count) / 3) * (o.isInstancedMesh ? o.count : 1); if (o.isInstancedMesh) { inst += o.count; instMeshes++; } mats.add(o.material.uuid); }
    if (o.name && o.name.startsWith('SLOT_')) slots.push(o);
  });
  scene.updateMatrixWorld(true);
  const box = new THREE.Box3();
  scene.traverse((o) => { if (o.isMesh && !o.name.startsWith('Sky_Dome')) { if (o.isInstancedMesh) { o.computeBoundingBox(); const b = o.boundingBox.clone().applyMatrix4(o.matrixWorld); box.union(b); } else { box.union(new THREE.Box3().setFromObject(o)); } } });
  const rec = { loaded: true, meshes_objects: meshes, triangles: tris, materials: mats.size, cameras: r.g.cameras.length, bbox_min: box.min.toArray().map(v => +v.toFixed(1)), bbox_max: box.max.toArray().map(v => +v.toFixed(1)), slot_count: slots.length, instanced_meshes: instMeshes, instances: inst, three_primitives: prims };
  if (slots.length) {
    let maxPos = 0, maxNose = 0, extras_ok = true;
    for (const s of slots) {
      const ref = slotsJson.find(x => x.name === s.name); const p = new THREE.Vector3(); s.getWorldPosition(p);
      const g = ref.gltf_yup.position_m; maxPos = Math.max(maxPos, Math.abs(p.x - g[0]), Math.abs(p.y - g[1]), Math.abs(p.z - g[2]));
      const nose = new THREE.Vector3(0, 0, -1).applyQuaternion(s.getWorldQuaternion(new THREE.Quaternion()));   // glTF/three forward = -Z
      const n = ref.gltf_yup.nose_vector; maxNose = Math.max(maxNose, Math.abs(nose.x - n[0]), Math.abs(nose.y - n[1]), Math.abs(nose.z - n[2]));
      if (!(s.userData && s.userData.slot_type === ref.type && s.userData.envelope_width_m === ref.w && s.userData.zone === ref.zone)) extras_ok = false;
    }
    rec.slot_max_position_err_m = +maxPos.toFixed(5); rec.slot_max_nose_vector_err = +maxNose.toFixed(5); rec.slot_userData_matches_slots_json = extras_ok;
    rec.slot0_userData = slots[0].userData;
  }
  out.files[f] = rec;
}
fs.writeFileSync(path.join(here, 'validation_threejs_node.json'), JSON.stringify(out, null, 1));
console.log(JSON.stringify(out, null, 1));
