"""Garage City RH - full scene generator.   blender -b --python build_scene.py
Outputs (next to this script): garage_city_environment.blend + GLBs + stats.json"""
import sys, os, json, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gc_lib import *
import gc_materials, gc_props as P, build_garage as G, build_city as BC, gc_ao

t0 = time.time()
rng = random.Random(1337)
bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
sc.unit_settings.system = 'METRIC'; sc.unit_settings.scale_length = 1.0
sc.name = "Garage_City_RH"

# ---------------------------------------------------------------- collections
core = coll("01_Garage_Core")
roads = coll("02_Roads_Highways")
city = coll("03_City_Background")
water = coll("04_Waterfront")
atmo = coll("05_Atmosphere")
rig = coll("06_Camera_Lights")
C = {}
for n in ('Buildings', 'Parking', 'Showcase_Display', 'Workshops_Lifts', 'Fuel_EV', 'Circulation', 'Details', 'Walls_Yard', 'Vegetation', 'Car_Slots'):
    C[n] = coll("Core_" + n, core)
for n in ('Roads', 'Road_Props', 'Highways'):
    C[n] = coll("Road_" + n if n != 'Roads' else "Road_Network", roads)
C['Blocks'] = coll("City_Blocks_Near", city)
C['Block_Veg'] = coll("City_Vegetation", city)
C['Skyline'] = coll("City_Skyline", city)
C['Waterfront'] = coll("Water_Main", water)
C['Waterfront_Props'] = coll("Water_Props", water)
C['Atmosphere'] = atmo
CG = {k: C[k] for k in ('Buildings', 'Parking', 'Showcase_Display', 'Workshops_Lifts', 'Fuel_EV', 'Circulation', 'Details', 'Walls_Yard', 'Vegetation')}

gc_materials.build_materials()
P.build_protos()
for _me in P.PROTO.values(): gc_ao.proto_height_ao(_me)
print('vertex-colour nodes installed on', gc_ao.install_vcol_nodes(list(bpy.data.materials)), 'materials')

# camera numbers (also used for shadow/occlusion-aware height fitting)
T = Vector((-5.0, -8.0, 0.0))
az = math.radians(45.0)
ELEV_P, DIST_P = math.radians(29.0), 172.0
campos = T + Vector((-math.cos(az) * math.cos(ELEV_P) * DIST_P, -math.sin(az) * math.cos(ELEV_P) * DIST_P, math.sin(ELEV_P) * DIST_P))
BC.CAM_PERSP = (campos.x, campos.y, campos.z)

# ---------------------------------------------------------------- garage
slots = G.build_garage(CG, rng)
BC.SLOT_PTS = [(s['x'], s['y']) for s in slots]
print("garage built, slots:", len(slots), "t=%.1f" % (time.time() - t0))

# ---------------------------------------------------------------- roads / highways
segs = BC.build_roads(C, rng)
def in_water(x, y):
    return (124 < y < 253) or (140 < x < 160 and y < 253) or BC.in_basin(x, y)
H = C['Highways']
BC.highway("HWY1_North_Expressway", [(-440, 100, 11), (-300, 100, 11), (-200, 100, 11), (-100, 100, 11), (0, 100, 11), (100, 100, 11), (150, 102, 11), (190, 116, 11.5),
            (225, 150, 12.5), (262, 205, 14), (298, 262, 15), (326, 330, 15), (350, 420, 15)], 20, H, H, 'neon_cyan', rng, water_fn=in_water)
BC.highway("HWY2_West_Flyover", [(-150, -190, 0), (-150, -150, 1), (-150, -100, 6), (-150, -30, 12), (-150, 40, 17), (-150, 100, 19), (-150, 150, 19),
            (-150, 260, 19), (-150, 330, 19), (-150, 420, 19)], 20, H, H, 'neon_magenta', rng, water_fn=in_water)
BC.highway("HWY3_East_Elevated", [(192, -190, 0), (192, -150, 0.5), (192, -100, 5), (192, -30, 9), (192, 40, 10.5), (192, 95, 11.3), (200, 124, 12.2), (212, 138, 12.6)],
           18, H, H, 'neon_blue', rng, water_fn=in_water)
BC.highway("RAMP_A_North_West", [(-260, 100, 11), (-232, 98, 9.6), (-212, 90, 7.6), (-201, 72, 4.9), (-200, 46, 2.3), (-200, 22, 0.35), (-200, 8, 0.0)],
           12, H, H, 'neon_amber', rng, pillar_every=18, lamp_every=60)
BC.highway("RAMP_B_South_West", [(-150, -90, 7), (-132, -94, 6), (-110, -108, 3.8), (-90, -128, 1.3), (-84, -146, 0.3), (-84, -162, 0.0)],
           12, H, H, 'neon_violet', rng, pillar_every=18, lamp_every=60)
BC.highway("RAMP_C_North_East", [(60, 100, 11), (86, 103, 8.8), (110, 110, 5.2), (128, 116, 2.2), (137, 117, 0.35)],
           12, H, H, 'neon_amber', rng, pillar_every=18, lamp_every=60, water_fn=in_water)
print("roads built t=%.1f" % (time.time() - t0))

# ---------------------------------------------------------------- city
stats = {}
BC.bridge_pylons(C, rng)
BC.build_blocks(C, rng, stats)
BC.build_promenade(C, rng)
BC.build_basin(C, rng)
BC.build_far(C, rng, stats)
BC.build_sky(C)
print("city built t=%.1f" % (time.time() - t0), stats)

# ---------------------------------------------------------------- slot empties
for s in slots:
    e = bpy.data.objects.new(s['name'], None)
    e.empty_display_type = 'ARROWS'; e.empty_display_size = 1.2
    e.location = (s['x'], s['y'], s['z'])
    e.rotation_euler = (0, 0, math.radians(s['yaw']))
    e["slot_type"] = s['type']; e["zone"] = s['zone']; e["note"] = s['note']; e["nose_dir"] = s['nose']
    e["envelope_width_m"] = s['w']; e["envelope_length_m"] = s['l']; e["envelope_height_m"] = s['h']
    e["forward_local_axis_blender"] = "+Y (nose) ; glTF/three.js: -Z"
    C['Car_Slots'].objects.link(e)
def _slot_record(s):
    th = math.radians(s['yaw']); r3 = lambda v: [round(a, 4) for a in v]
    nb = (-math.sin(th), math.cos(th), 0.0)            # nose (local +Y) in Blender Z-up world
    ng = (nb[0], nb[2], -nb[1])                          # same vector in glTF Y-up  (x, z, -y)
    rec = dict(s)                                        # legacy flat keys kept (x,y,z,yaw,nose,w,l,h,note,type,zone) -> V1 compatible
    rec.update({
        "blender_zup": {"position_m": r3((s['x'], s['y'], s['z'])), "rotation_euler_deg": [0.0, 0.0, s['yaw']],
                         "quaternion_wxyz": r3((math.cos(th / 2), 0, 0, math.sin(th / 2))), "nose_vector": r3(nb),
                         "envelope_size_m": {"x_width": s['w'], "y_length": s['l'], "z_height": s['h']}},
        "gltf_yup": {"position_m": r3((s['x'], s['z'], -s['y'])), "rotation_euler_deg": [0.0, s['yaw'], 0.0],
                      "quaternion_xyzw": r3((0, math.sin(th / 2), 0, math.cos(th / 2))), "nose_vector": r3(ng),
                      "envelope_size_m": {"x_width": s['w'], "y_height": s['h'], "z_length": s['l']},
                      "forward_axis": "-Z (nose)"},
        "nose_direction": s['nose'],
        "metadata": {"slot_type": s['type'], "zone": s['zone'], "note": s['note'], "nose_dir": s['nose'],
                     "envelope_width_m": s['w'], "envelope_length_m": s['l'], "envelope_height_m": s['h']},
    })
    return rec
json.dump([_slot_record(s) for s in slots], open(os.path.join(OUT, "slots.json"), "w"), indent=1)

# ---------------------------------------------------------------- cameras
def make_cam(name, persp, loc, target, **kw):
    cd = bpy.data.cameras.new(name)
    if persp:
        cd.type = 'PERSP'; cd.sensor_width = 36; cd.lens = kw['lens']
    else:
        cd.type = 'ORTHO'; cd.ortho_scale = kw['scale']
    cd.clip_start = kw.get('near', 1.0); cd.clip_end = kw.get('far', 3000)
    ob = bpy.data.objects.new(name, cd)
    ob.location = loc
    d = Vector(target) - Vector(loc)
    ob.rotation_euler = d.to_track_quat('-Z', 'Y').to_euler()
    rig.objects.link(ob)
    return ob
# focal for 45deg horizontal FOV on a 36mm sensor
lens = 18.0 / math.tan(math.radians(31.0))   # 62 deg horizontal FOV
camP = make_cam("CAM_Game_Perspective", True, campos, T, lens=lens, near=5, far=2600)
oel = math.radians(35.264)
odir = Vector((-math.cos(az) * math.cos(oel), -math.sin(az) * math.cos(oel), math.sin(oel))) * 600
OT = Vector((0.0, 8.0, 0.0))
camO = make_cam("CAM_Game_Isometric_Ortho", False, OT + odir, OT, scale=215.0, near=1, far=2500)
# extra camera, only for a skyline/sky preview (not a game camera)
_wd = Vector((-math.cos(az) * math.cos(math.radians(14)), -math.sin(az) * math.cos(math.radians(14)), math.sin(math.radians(14)))) * 520
camW = make_cam("CAM_Preview_Skyline", True, Vector((60, 120, 20)) + _wd, Vector((60, 120, 20)), lens=18.0 / math.tan(math.radians(36.0)), near=5, far=3000)
# V3: documented hero camera - the original gameplay camera looks ~10 deg below the horizon so the skyline/sky can never be in it;
# this extra (non-gameplay) camera shows garage + harbour + skyline together. The two gameplay cameras are unchanged.
camH = make_cam("CAM_V3_Hero_Skyline", True, Vector((-150.0, -118.0, 44.0)), Vector((45.0, 70.0, 50.0)), lens=18.0 / math.tan(math.radians(32.0)), near=5, far=3000)
camD = make_cam("CAM_V3_Close_Detail", True, Vector((-30.0, -27.0, 8.5)), Vector((-1.0, 12.0, 4.0)), lens=18.0 / math.tan(math.radians(30.0)), near=1, far=1500)
sc.camera = camP
sc.render.resolution_x = 1920; sc.render.resolution_y = 1080

# ---------------------------------------------------------------- lights + world
sun = bpy.data.lights.new("Sun_Sunset", 'SUN')
sun.energy = 3.4; sun.color = (1.0, 0.55, 0.32); sun.angle = math.radians(4)
so = bpy.data.objects.new("Sun_Sunset", sun)
so.rotation_euler = (math.radians(72), 0, math.radians(215))   # low sun from the north-west
rig.objects.link(so)
fill = bpy.data.lights.new("Sky_Fill_Blue", 'SUN')
fill.energy = 2.2; fill.color = (0.45, 0.5, 1.0)
fo = bpy.data.objects.new("Sky_Fill_Blue", fill)
fo.rotation_euler = (math.radians(35), 0, math.radians(40))
rig.objects.link(fo)
world = bpy.data.worlds.new("World_BlueHour"); sc.world = world
world.use_nodes = True
nt = world.node_tree
for n in list(nt.nodes):
    if n.type not in ('OUTPUT_WORLD',):
        nt.nodes.remove(n)
out = nt.nodes['World Output']
bg = nt.nodes.new("ShaderNodeBackground")
tc = nt.nodes.new("ShaderNodeTexCoord")
sep = nt.nodes.new("ShaderNodeSeparateXYZ")
ramp = nt.nodes.new("ShaderNodeValToRGB")
cr = ramp.color_ramp
cr.elements[0].position = 0.0; cr.elements[0].color = srgb('#1a2a5c')
cr.elements[1].position = 1.0; cr.elements[1].color = srgb('#1a2a5c')
nt.links.new(tc.outputs['Generated'], sep.inputs[0]); nt.links.new(sep.outputs['Z'], ramp.inputs[0])
nt.links.new(ramp.outputs[0], bg.inputs[0]); nt.links.new(bg.outputs[0], out.inputs[0])
bg.inputs[1].default_value = 1.4
# the real sky for the game is Sky_Dome (emissive gradient mesh); the world only provides soft ambient
sc.eevee.use_shadows = True
sc.render.film_transparent = False
sc.view_settings.view_transform = 'AgX' if 'AgX' in sc.view_settings.bl_rna.properties['view_transform'].enum_items.keys() else 'Standard'
sc.view_settings.look = 'None'

# ---------------------------------------------------------------- keep slots + camera sight-lines free of soft props
import re as _re
_SOFT = _re.compile(r'^(palm|tree|shrub|planter_s|plazalight|bollard|sign|streetlight)')
def clear_soft_props():
    removed = []
    bpy.context.view_layer.update()
    for it in range(6):
        for o in bpy.data.objects:
            if o.name.startswith('Sky_Dome'): o.hide_viewport = True
        bpy.context.view_layer.update()
        dg = bpy.context.evaluated_depsgraph_get()
        kill = set()
        for e in [o for o in bpy.data.objects if o.name.startswith('SLOT_')]:
            m = e.matrix_world
            w, l = e['envelope_width_m'], e['envelope_length_m']
            pts = [Vector((0, 0, 1.0))] + [Vector((sx * w / 2, sy * l / 2, 0.5)) for sx in (-1, 1) for sy in (-1, 1)]
            for cam in (camP, camO):
                for p in pts:
                    wp = m @ p
                    if cam.data.type == 'PERSP':
                        d = cam.location - wp; dist = d.length
                    else:
                        d = -(cam.matrix_world.to_quaternion() @ Vector((0, 0, -1))); dist = 400.0
                    hit, loc_, nrm, idx_, ob, mx = sc.ray_cast(dg, wp, d.normalized(), distance=dist)
                    if hit and _SOFT.match(ob.name):
                        kill.add(ob.name)
            # soft props standing inside / right next to the slot footprint
            inv = m.inverted()
            for o in bpy.data.objects:
                if _SOFT.match(o.name):
                    q = inv @ o.matrix_world.translation
                    if abs(q.x) < w / 2 + 1.2 and abs(q.y) < l / 2 + 1.2:
                        kill.add(o.name)
        if not kill:
            break
        for n in kill:
            bpy.data.objects.remove(bpy.data.objects[n], do_unlink=True)
        removed += sorted(kill)
    for o in bpy.data.objects:
        if o.name.startswith('Sky_Dome'): o.hide_viewport = False
    return removed
_rm = clear_soft_props()
print("removed soft props blocking slots/sightlines:", len(_rm))

# ---------------------------------------------------------------- tri stats
def coll_stats(c):
    uniq, inst, nobj, meshes = 0, 0, 0, set()
    for ob in c.all_objects:
        if ob.type != 'MESH':
            continue
        nobj += 1
        t = tri_count_obj(ob)
        inst += t
        if ob.data.name not in meshes:
            meshes.add(ob.data.name); uniq += t
    return dict(objects=nobj, tris_rendered=inst, tris_unique_meshes=uniq)
cs = {c.name: coll_stats(c) for c in (core, roads, city, water, atmo)}
print(json.dumps(cs, indent=1))

# ---------------------------------------------------------------- save blend
gc_ao.ensure_all_cols()          # every mesh carries the 'Col' attribute (white in the .blend; baked AO only goes into the GLBs)
bpy.ops.file.pack_all()
blend = os.path.join(OUT, "garage_city_environment.blend")
bpy.ops.wm.save_as_mainfile(filepath=blend, compress=True)
print("saved blend t=%.1f" % (time.time() - t0))

# ---------------------------------------------------------------- GLB exports
def export(fn, colls, cams=False, extra_objs=(), outdir=None):
    bpy.ops.object.select_all(action='DESELECT')
    objs = set()
    for c in colls:
        objs.update(c.all_objects)
    objs.update(extra_objs)
    for ob in objs:
        if ob.type == 'CAMERA' and not cams:
            continue
        if ob.type == 'LIGHT':
            continue
        ob.select_set(True)
    bpy.context.view_layer.objects.active = next(iter(o for o in objs if o.select_get()))
    path = os.path.join(outdir or OUT, fn)
    bpy.ops.export_scene.gltf(filepath=path, export_format='GLB', use_selection=True, export_yup=True,
                              export_apply=False, export_cameras=cams, export_lights=False, export_extras=True,
                              export_image_format='AUTO', export_texcoords=True, export_normals=True, export_materials='EXPORT',
                              export_vertex_color='ACTIVE', export_all_vertex_colors=False,
                              export_attributes=False, export_animations=False, export_skins=False, export_morph=False)
    print("exported", fn, os.path.getsize(path))
def export_set(outdir):
    os.makedirs(outdir, exist_ok=True)
    export("garage_city_environment.glb", (core, roads, city, water, atmo, rig), cams=True, outdir=outdir)
    export("garage_core.glb", (core,), outdir=outdir)
    export("roads_and_highways.glb", (roads,), outdir=outdir)
    export("city_background.glb", (city, atmo), outdir=outdir)
    export("waterfront.glb", (water,), outdir=outdir)
import gc_export
colls5 = (core, roads, city, water, atmo)
# pass 1: batch everything EXCEPT the repeated props (palms, trees, lamps, bollards, planters ...): those stay separate nodes that
# share one mesh each -> intermediate GLBs in build_inst/ which optimize_glb.mjs turns into EXT_mesh_gpu_instancing
_mr = gc_export.merge_collection_chunks(colls5, log=lambda n, r: print("merge", n, r), props='keep')
bpy.context.view_layer.update()
_sub = gc_ao.subdivide_up_faces([o for o in bpy.data.objects if o.type == 'MESH' and (o.name == 'Yard_Ground_Slab' or
                                (o.users_collection and o.users_collection[0].name.startswith('Core_') and not gc_ao.SKIP_OBJ.match(o.name)))])
print("AO: subdivided large up-facing faces, +%d polys" % _sub)
bpy.context.view_layer.update()
_all = [o for o in bpy.data.objects if o.type == 'MESH' and not o.name.startswith('SLOT_') and not gc_ao.PROP.match(o.name)]
_tg = [o for o in _all if not gc_ao.SKIP_OBJ.match(o.name)]
_oc = [o for o in _all if not o.name.startswith(('Sky_Dome', 'Water_Surface', 'Floor_Glow'))]
_ao = gc_ao.bake_vertex_ao(_tg, _oc, log=print)
json.dump(dict(merge=_mr, ao=_ao, subdivided_polys=_sub), open(os.path.join(OUT, "export_merge_report.json"), "w"), indent=1)
export_set(os.path.join(OUT, "build_inst"))
# pass 2: merge the props too -> the plain, extension-free compatibility GLBs
_mr2 = gc_export.merge_collection_chunks(colls5, log=lambda n, r: print("merge props", n, r), props='only')
export_set(OUT)
stats.update(cs)
stats['slots'] = len(slots)
json.dump(stats, open(os.path.join(OUT, "stats.json"), "w"), indent=1)
print("DONE t=%.1f" % (time.time() - t0))
