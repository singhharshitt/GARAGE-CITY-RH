"""blender -b --python validate_glb_blender.py : re-imports every GLB with Blender's importer, reports tris/objects and slot round-trip."""
import bpy, os, json
D = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else '/workspace/garage_city'
slots = {s['name']: s for s in json.load(open(os.path.join(D, 'slots.json')))}
res = {}
for f in ['garage_city_environment.glb', 'garage_core.glb', 'roads_and_highways.glb', 'city_background.glb', 'waterfront.glb']:
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.gltf(filepath=os.path.join(D, f))
    meshes = [o for o in bpy.data.objects if o.type == 'MESH']
    tris = sum(len(p.vertices) - 2 for o in meshes for p in o.data.polygons)
    r = dict(objects=len(bpy.data.objects), meshes=len(meshes), tris=tris, empties=sum(1 for o in bpy.data.objects if o.type == 'EMPTY'), cameras=sum(1 for o in bpy.data.objects if o.type == 'CAMERA'))
    sl = [o for o in bpy.data.objects if o.name.startswith('SLOT_')]
    if sl:
        err = max(max(abs(o.matrix_world.translation.x - slots[o.name]['x']), abs(o.matrix_world.translation.y - slots[o.name]['y']), abs(o.matrix_world.translation.z - slots[o.name]['z'])) for o in sl)
        yerr = max(abs(((o.matrix_world.to_euler('XYZ').z * 57.29578 - slots[o.name]['yaw'] + 180) % 360) - 180) for o in sl)
        r['slot_roundtrip_max_yaw_err_deg'] = round(yerr, 4)
        r['slot_roundtrip_max_err_m'] = round(err, 5); r['slot_extras_example'] = {k: (v if isinstance(v, (int, float, str)) else str(v)) for k, v in dict(sl[0]).items()}
    res[f] = r
    if f == 'garage_city_environment.glb':
        # run the same BVH keep-clear / sight-line / ground-alignment checks on the re-imported (merged) GLB
        os.environ['VAL_OUT'] = D; os.environ['VAL_NAME'] = 'validation_glb_reimport_slots.json'
        import runpy, io, contextlib
        with contextlib.redirect_stdout(io.StringIO()):
            runpy.run_path(os.path.join(D, 'validate_blend.py'))
        v = json.load(open(os.path.join(D, 'validation_glb_reimport_slots.json')))
        r['reimport_slot_checks'] = dict(slot_count=v['slot_count'], slots_overlapping=v['slots_overlapping'], slots_misaligned=v['slots_misaligned'],
                                          los_blocked={k: x['blocked'] for k, x in v['line_of_sight'].items()}, vehicle_name_hits=v['vehicle_name_hits'])
json.dump(res, open(os.path.join(D, 'validation_glb_blender.json'), 'w'), indent=1)
print(json.dumps(res, indent=1))
