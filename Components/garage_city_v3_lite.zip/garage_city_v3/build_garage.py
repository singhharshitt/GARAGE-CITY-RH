from gc_lib import *
import gc_props as P

SLOTS = []   # dicts

NOSE_YAW = {'N': 0, 'E': -90, 'S': 180, 'W': 90}
ZONES = {
    'A': dict(rarity='Common', mat='neon_amber'),
    'B': dict(rarity='Rare', mat='neon_cyan'),
    'C': dict(rarity='Epic', mat='neon_violet'),
    'D': dict(rarity='Legendary', mat='neon_magenta'),
}

def add_slot(name, typ, zone, x, y, zb, nose, w=2.5, l=5.0, h=1.9, yaw_extra=0.0, note=''):
    register_slot_footprint(x, y, w, l, NOSE_YAW[nose] + yaw_extra)
    SLOTS.append(dict(name=name, type=typ, zone=zone, x=x, y=y, z=zb, nose=nose, yaw=NOSE_YAW[nose] + yaw_extra,
                      w=w, l=l, h=h, note=note))

def bay2(mb, cx, cy, nose, border, four=False, bw=3.0, bl=5.8, t=0.12, z=0.06, stop=True, stopm='graphite'):
    """marked bay: 3 (or 4) illuminated lines + wheel stop at nose end."""
    if nose in 'NS':
        wx, wy = bw, bl
    else:
        wx, wy = bl, bw
    x0, x1, y0, y1 = cx - wx / 2, cx + wx / 2, cy - wy / 2, cy + wy / 2
    lines = {'left': (x0, y0, x0 + t, y1), 'right': (x1 - t, y0, x1, y1),
             'bot': (x0, y0, x1, y0 + t), 'top': (x0, y1 - t, x1, y1)}
    rear = {'N': 'top', 'S': 'bot', 'E': 'right', 'W': 'left'}[nose]
    front = {'top': 'bot', 'bot': 'top', 'left': 'right', 'right': 'left'}[rear]
    for k, v in lines.items():
        if k == front and not four:
            continue
        gq(mb, v[0], v[1], v[2], v[3], z, border)
    if stop:
        # wheel stop inside the 0.4 m rear margin, outside the 5.0 m car envelope
        if nose == 'N':
            mb.box(cx, y1 - 0.30, 0, 1.8, 0.2, 0.12, stopm)
        elif nose == 'S':
            mb.box(cx, y0 + 0.30, 0, 1.8, 0.2, 0.12, stopm)
        elif nose == 'E':
            mb.box(x1 - 0.30, cy, 0, 0.2, 1.8, 0.12, stopm)
        else:
            mb.box(x0 + 0.30, cy, 0, 0.2, 1.8, 0.12, stopm)

def planter_row(mb, x0, y0, x1, y1, z=0.0, h=0.6, w=1.0, shrub=True, rng=random):
    L = math.hypot(x1 - x0, y1 - y0)
    ang = math.degrees(math.atan2(y1 - y0, x1 - x0))
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    mb.box(cx, cy, z, L, w, h, 'planter', rot=ang, mtop='foliage')
    mb.box(cx, cy, z + h + 0.01, L - 0.2, w - 0.2, 0.25, 'foliage_b', rot=ang, top=True)

def neon_edge(mb, x, y, z, sx, sy, m='neon_cyan', t=0.08):
    mb.box(x, y, z, sx, sy, t, m)

def build_garage(C, rng):
    """C: dict of collections"""
    cb, cp, cs, cw, cf, cc, cd, cwall, cv = [C[k] for k in
        ('Buildings', 'Parking', 'Showcase_Display', 'Workshops_Lifts', 'Fuel_EV', 'Circulation', 'Details', 'Walls_Yard', 'Vegetation')]
    veg = cv
    # =============================================================== YARD SLAB + PAVING
    mb = MB()
    mb.box(0, 0, -0.5, 144, 104, 0.5, 'yard_dark')                     # top at z=0
    # lighter paving plates
    def plate(x0, y0, x1, y1, m='paving', z=0.03):
        gq(mb, x0, y0, x1, y1, z, m)
    plate(-68, -48.5, -42.5, -25.5)           # zone A
    plate(-68, -22.5, -52, 0.5)               # zone B
    plate(-51, -22.5, -38, 0.5)               # zone C
    plate(-12, 8.5, 12, 17.5)                 # VIP zone D
    plate(-54, 16.5, -8, 27.5)                # display plinth terrace
    plate(-37, -41, -3, -27.5)                # fuel
    plate(21, -43.5, 57, -30)                 # EV
    plate(41, -18, 57, 11)                    # lifts E
    plate(12, 24.5, 39.5, 37.5)               # lifts N
    ob = mb.finish("Yard_Ground_Slab", cwall)
    # lane markings (dashed centre lines, arrows, zone outlines)
    mb = MB()
    def dash_x(y, x0, x1, m='mark_yellow', dl=3.0, gap=3.0, t=0.14):
        x = x0
        while x < x1:
            gq(mb, x, y - t / 2, min(x + dl, x1), y + t / 2, 0.05, m); x += dl + gap
    def dash_y(x, y0, y1, m='mark_yellow', dl=3.0, gap=3.0, t=0.14):
        y = y0
        while y < y1:
            gq(mb, x - t / 2, y, x + t / 2, min(y + dl, y1), 0.05, m); y += dl + gap
    dash_x(-37, -69, 69); dash_x(-11, -69, -12); dash_y(0, -48, -10, 'mark_white'); dash_y(0, 12, 48, 'mark_white')
    dash_x(-24.5, -3, 20, 'mark_white'); dash_y(13.5, -48, -9, 'mark_white')
    dash_y(20, -28, 10, 'mark_white'); dash_x(21, 20, 69, 'mark_white')
    # entrance arrows (chevrons) at south gate x in [-1,13]
    for yy in (-47, -43, -39):
        for dx in (0,):
            mb.tri((6 - 2.0, yy, 0.05), (6 + 2.0, yy, 0.05), (6, yy + 2.0, 0.05), 'mark_white')
            mb.tri((6 - 1.2, yy - 0.01, 0.055), (6 + 1.2, yy - 0.01, 0.055), (6, yy + 1.0, 0.055), 'asphalt')
    # zone outlines (illuminated) - thin
    def outline(x0, y0, x1, y1, m, t=0.18, z=0.05):
        gq(mb, x0, y0, x1, y0 + t, z, m); gq(mb, x0, y1 - t, x1, y1, z, m)
        gq(mb, x0, y0, x0 + t, y1, z, m); gq(mb, x1 - t, y0, x1, y1, z, m)
    outline(-68, -48.5, -42.5, -25.5, 'neon_amber')
    outline(-68, -22.5, -52, 0.5, 'neon_cyan')
    outline(-51, -22.5, -38, 0.5, 'neon_violet')
    outline(-12, 8.5, 12, 17.5, 'neon_magenta')
    outline(-54, 16.5, -8, 27.5, 'neon_blue')
    outline(41, -18, 57, 11, 'neon_amber')
    outline(12, 24.5, 39.5, 37.5, 'neon_amber')
    mb.finish("Yard_Markings", cwall)

    # =============================================================== PARKING BAYS
    mb = MB()
    n = 0
    def mk(zone, cx, cy, nose, four=False, zb=0.0, typ='parking', bw=3.0):
        nonlocal n
        n += 1
        bay2(mb, cx, cy, nose, ZONES[zone]['mat'], four=four, bw=bw)
        add_slot("SLOT_bay_%02d" % n, typ, zone, cx, cy, zb, nose, note=ZONES[zone]['rarity'])
    # zone A (12)
    for i in range(6):
        mk('A', -64.5 + 3.3 * i, -44, 'S')
        mk('A', -64.5 + 3.3 * i, -30, 'N')
    # zone B (8)
    for i in range(4):
        mk('B', -64.5 + 3.3 * i, -18, 'S', four=True)
        mk('B', -64.5 + 3.3 * i, -4, 'N', four=True)
    # zone C (6)  premium
    for i in range(3):
        mk('C', -48 + 3.6 * i, -18, 'S', four=True, bw=3.4)
        mk('C', -48 + 3.6 * i, -4, 'N', four=True, bw=3.4)
    mb.finish("Parking_Bays_ZoneABC", cp)
    # zone D VIP pads (raised 0.12)
    mb = MB()
    for i in range(4):
        cx = -9 + 6 * i
        mb.box(cx, 13, 0.03, 3.9, 6.4, 0.09, 'graphite', mtop='paving')
        bay2(mb, cx, 13, 'S', 'neon_magenta', four=True, bw=3.5, bl=6.0, z=0.125, stop=False)
        n += 1
        add_slot("SLOT_bay_%02d" % n, 'parking_vip', 'D', cx, 13, 0.12, 'S', note='Legendary VIP pad')
        # twin light posts
        mb.box(cx - 2.0, 15.9, 0, 0.14, 0.14, 1.2, 'graphite_dark'); mb.box(cx - 2.0, 15.9, 1.2, 0.18, 0.18, 0.12, 'neon_magenta')
    mb.finish("Parking_VIP_ZoneD", cp)

    # =============================================================== SHOWCASE
    mb = MB()
    # rings (flat annulus quads)
    def ring(r0, r1, z, m, seg=48):
        for i in range(seg):
            a0, a1 = 2 * math.pi * i / seg, 2 * math.pi * (i + 1) / seg
            mb.quad((r0 * math.cos(a0), r0 * math.sin(a0), z), (r1 * math.cos(a0), r1 * math.sin(a0), z),
                    (r1 * math.cos(a1), r1 * math.sin(a1), z), (r0 * math.cos(a1), r0 * math.sin(a1), z), m)
    import gc_massing as GM
    GM.build_showcase(mb, ring)        # V3 layered showcase + east framing arch (slot SLOT_showcase_01 unchanged)
    mb.finish("Showcase_Platform_Central", cs)
    add_slot("SLOT_showcase_01", 'showcase', 'S', 0.0, 0.0, 0.50, 'N', w=2.7, l=5.4, h=2.2, yaw_extra=28, note='central circular platform, r=5.9m turntable top z=0.50')

    # display plinths
    mb = MB()
    for i in range(6):
        cx = -51 + 8 * i
        mb.box(cx, 22, 0, 4.6, 7.8, 0.45, 'graphite', mtop='paving')
        mb.box(cx, 22, 0.451, 4.1, 7.3, 0.01, 'graphite_dark')
        # neon rim
        t = 0.12
        gq(mb, cx - 2.3, 22 - 3.9, cx + 2.3, 22 - 3.9 + t, 0.46, 'neon_cyan'); gq(mb, cx - 2.3, 22 + 3.9 - t, cx + 2.3, 22 + 3.9, 0.46, 'neon_cyan')
        gq(mb, cx - 2.3, 22 - 3.9, cx - 2.3 + t, 22 + 3.9, 0.46, 'neon_violet'); gq(mb, cx + 2.3 - t, 22 - 3.9, cx + 2.3, 22 + 3.9, 0.46, 'neon_violet')
        mb.box(cx, 22 + 4.35, 0, 3.0, 0.2, 1.4, 'graphite_dark')                # info stele (blank)
        mb.box(cx, 22 + 4.24, 0.7, 2.4, 0.02, 0.5, 'neon_blue')
        add_slot("SLOT_display_%02d" % (i + 1), 'display', 'E', cx, 22, 0.45, 'S', w=2.5, l=5.0, h=1.9, yaw_extra=(18 if i % 2 else -18), note='display platform')
    mb.finish("Display_Platforms", cs)

    # =============================================================== BUILDINGS
    # ---- V2: enclosed buildings (N1 showroom, N2 workshop hall, E1 service centre, W2 utility, D1 studio, fuel shop, EV lounge)
    import gc_buildings as GB
    GB.build_buildings(C, rng)
    import gc_massing as GM2
    GM2.build_massing(C, rng)

    # ---- skybridge N1<->N2 and gate pylons, kiosk
    mb = MB()
    mb.box(-9, 44, 5.2, 7, 3.2, 3.2, 'glass'); mb.box(-9, 44, 5.0, 7.2, 3.4, 0.25, 'graphite_dark'); mb.box(-9, 44, 8.4, 7.2, 3.4, 0.2, 'graphite_dark')
    mb.box(-9, 42.3, 6.0, 7.0, 0.06, 0.1, 'neon_cyan')
    for sx_ in (-10.6, -7.4):
        mb.box(sx_, 44, 0, 0.7, 0.7, 5.0, 'graphite')
    mb.finish("Skybridge_N1_N2", cb)

    # =============================================================== CIRCULATION: stairs, elevators, ramps, loading
    mb = MB()
    # N1 two-flight exterior stair (x -9.3..-10.5 flight1 run +y; flight2 back run)
    mb.stairs(-10.8, 31.0, 0, 1.7, 4.0, 90, 20, 'graphite', tread=0.3, mside='concrete')
    mb.box(-10.8, 38.5, 3.8, 1.9, 2.0, 0.2, 'graphite')        # landing top z=4.0
    mb.stairs(-9.0, 37.8, 4.0, 1.7, 4.0, -90, 20, 'graphite', tread=0.3, mside='concrete')
    mb.box(-10.6, 31.9, 7.8, 4.2, 1.8, 0.2, 'graphite')          # bridge to roof z 7.8..8.0
    mb.finish("Stairs_N1_Exterior", cc)
    mb = MB()
    # panoramic elevators (glass shaft + cyan frame + cap)
    for (ex, ey, h) in [(-2.5, 36.3, 10.0), (60.5, -26.0, 8.0), (-56, 28.8, 8.0)]:
        mb.box(ex, ey, 0, 2.6, 2.6, h, 'glass', mtop='graphite_dark')
        for (ax, ay) in ((-1.3, -1.3), (1.3, -1.3), (1.3, 1.3), (-1.3, 1.3)):
            mb.box(ex + ax, ey + ay, 0, 0.18, 0.18, h + 0.4, 'graphite_dark')
        mb.box(ex, ey, h + 0.4, 2.8, 2.8, 0.2, 'graphite_dark'); mb.box(ex, ey, 0.0, 2.9, 2.9, 0.15, 'neon_cyan')
        mb.box(ex, ey - 1.45, 0.3, 1.6, 0.06, 2.2, 'neon_blue')
    mb.finish("Elevators", cc)
    mb = MB()
    # service ramps (entry to raised loading platform) + loading platform with vents
    mb.box(-28.5, 11, 0, 10.0, 9.0, 1.0, 'concrete', mtop='terrace')
    mb.wedge(-22.0, 11, 0, 4.0, 5.0, 1.0, 'concrete', rot=180)           # ramp down towards +x
    gq(mb, -33.4, 6.6, -23.6, 6.9, 1.02, 'neon_amber'); gq(mb, -33.4, 15.1, -23.6, 15.4, 1.02, 'neon_amber')
    for i in range(3):
        mb.box(-32 + 2.4 * i, 13.5, 1.0, 1.8, 1.4, 1.1, 'metal_light'); mb.cyl(-32 + 2.4 * i, 13.5, 2.1, 0.55, 0.08, 'graphite_dark', seg=8)
    mb.box(-31, 8.2, 1.0, 3.5, 1.2, 1.5, 'graphite_dark'); mb.box(-31, 7.58, 1.6, 3.0, 0.03, 0.4, 'neon_cyan')
    railing(mb, -33.4, 6.6, -33.4, 15.4, 1.0)
    # stairs up to loading platform
    mb.stairs(-26.0, 17.3, 0, 1.6, 1.0, 270, 6, 'graphite', tread=0.3, mside='concrete')
    mb.finish("Ramps_Loading_Platform", cc)
    # =============================================================== WORKSHOPS (lifts + equipment)
    mb = MB()
    cnt = 0
    def lift(cx, cy, nose, name):
        nonlocal cnt
        cnt += 1
        if nose in 'NS':
            wx, wy = 3.2, 5.9
        else:
            wx, wy = 5.9, 3.2
        mb.box(cx, cy, 0, wx, wy, 0.28, 'graphite_dark', mtop='graphite')
        t = 0.1
        gq(mb, cx - wx / 2 + 0.05, cy - wy / 2 + 0.05, cx + wx / 2 - 0.05, cy - wy / 2 + 0.05 + t, 0.285, 'mark_yellow')
        gq(mb, cx - wx / 2 + 0.05, cy + wy / 2 - 0.05 - t, cx + wx / 2 - 0.05, cy + wy / 2 - 0.05, 0.285, 'mark_yellow')
        gq(mb, cx - wx / 2 + 0.05, cy - wy / 2 + 0.05, cx - wx / 2 + 0.05 + t, cy + wy / 2 - 0.05, 0.285, 'mark_yellow')
        gq(mb, cx + wx / 2 - 0.05 - t, cy - wy / 2 + 0.05, cx + wx / 2 - 0.05, cy + wy / 2 - 0.05, 0.285, 'mark_yellow')
        # two columns on the sides (outside the car envelope), cyan caps + overhead lamp arm
        for sgn in (-1, 1):
            if nose in 'NS':
                px_, py_ = cx + sgn * 1.95, cy + 0.6
            else:
                px_, py_ = cx + 0.6, cy + sgn * 1.95
            mb.box(px_, py_, 0, 0.45, 0.45, 3.4, 'graphite')
            mb.box(px_, py_, 3.4, 0.5, 0.5, 0.1, 'neon_cyan')
            mb.box(px_, py_, 0.9, 0.47, 0.47, 0.05, 'neon_amber')
        # swing arms / support pads (<=10 cm above the lift deck = inside the 15 cm floor tolerance)
        for off in (-1.3, 1.3):
            if nose in 'NS':
                mb.box(cx, cy + off, 0.28, 2.3, 0.22, 0.09, 'graphite'); mb.box(cx - 1.0, cy + off, 0.37, 0.3, 0.3, 0.02, 'neon_amber'); mb.box(cx + 1.0, cy + off, 0.37, 0.3, 0.3, 0.02, 'neon_amber')
            else:
                mb.box(cx + off, cy, 0.28, 0.22, 2.3, 0.09, 'graphite'); mb.box(cx + off, cy - 1.0, 0.37, 0.3, 0.3, 0.02, 'neon_amber'); mb.box(cx + off, cy + 1.0, 0.37, 0.3, 0.3, 0.02, 'neon_amber')
        # overhead work-lamp arms (above the car envelope) with emissive panels
        for sgn in (-1, 1):
            if nose in 'NS':
                px_, py_ = cx + sgn * 1.95, cy + 0.6
                mb.box(px_ - sgn * 0.55, py_, 3.2, 1.1, 0.14, 0.14, 'graphite_dark'); mb.box(px_ - sgn * 0.95, py_, 3.12, 0.5, 0.3, 0.05, 'neon_white')
            else:
                px_, py_ = cx + 0.6, cy + sgn * 1.95
                mb.box(px_, py_ - sgn * 0.55, 3.2, 0.14, 1.1, 0.14, 'graphite_dark'); mb.box(px_, py_ - sgn * 0.95, 3.12, 0.3, 0.5, 0.05, 'neon_white')
        n_ = len([s for s in SLOTS if s['type'] == 'lift']) + 1
        add_slot("SLOT_lift_%02d" % n_, 'lift', 'W', cx, cy, 0.28, nose, w=2.5, l=5.0, h=2.0, note='hydraulic lift platform, top z=0.28')
    for i in range(4):
        lift(46, -14 + 6.4 * i, 'E', None)
    for i in range(4):
        lift(16 + 6.4 * i, 29, 'N', None)
    mb.finish("Lifts_Repair_Bays", cw)
    # equipment lines
    def equipment_line(name, pts, facing, kinds):
        mbe = MB()
        for idx, (x, y) in enumerate(pts):
            kind = kinds[idx % len(kinds)]
            rot = facing
            if kind == 'cab':
                mbe.box(x, y, 0, 1.3, 0.7, 1.5, 'cabinet_orange', rot=rot, mtop='graphite_dark')
                mbe.box(x, y, 1.5, 1.4, 0.8, 0.06, 'graphite_dark', rot=rot)
                mbe.box(x, y, 0.2, 1.1, 0.72, 0.06, 'graphite_dark', rot=rot); mbe.box(x, y, 0.8, 1.1, 0.72, 0.06, 'graphite_dark', rot=rot)
            elif kind == 'bench':
                mbe.box(x, y, 0.82, 2.4, 0.9, 0.1, 'metal_light', rot=rot)
                for s in (-1, 1):
                    mbe.box(x + s * 1.0 * math.cos(math.radians(rot)), y + s * 1.0 * math.sin(math.radians(rot)), 0, 0.12, 0.8, 0.82, 'graphite_dark', rot=rot)
                mbe.box(x, y, 0.93, 0.5, 0.35, 0.18, 'cabinet_blue', rot=rot)
            elif kind == 'shelf':
                mbe.box(x, y, 0, 2.2, 0.55, 2.3, 'graphite_dark', rot=rot, top=True)
                for z in (0.5, 1.1, 1.7):
                    mbe.box(x, y, z, 2.1, 0.6, 0.05, 'metal_light', rot=rot)
                    for q in (-0.7, 0.0, 0.7):
                        qx = x + q * math.cos(math.radians(rot)); qy = y + q * math.sin(math.radians(rot))
                        mbe.box(qx, qy, z + 0.05, 0.5, 0.4, 0.3, 'cabinet_blue' if (q > 0) else 'cabinet_orange', rot=rot)
            elif kind == 'tires':
                for r_ in range(3):
                    for c_ in range(2):
                        ax = 'x' if abs(math.cos(math.radians(rot))) < 0.5 else 'y'
                        off = (c_ - 0.5) * 0.75
                        tx = x + (off if ax == 'x' else 0); ty = y + (off if ax == 'y' else 0)
                        mbe.hcyl(tx, ty, 0.4 + r_ * 0.62, 0.3, 0.3, 'tire', axis=('y' if ax == 'x' else 'x'), seg=8)
                mbe.box(x, y, 0, 1.8, 0.9, 0.08, 'graphite_dark', rot=rot)
                for s in (-1, 1):
                    mbe.box(x + s * 0.88 * math.cos(math.radians(rot)), y + s * 0.88 * math.sin(math.radians(rot)), 0, 0.08, 0.08, 2.0, 'graphite_dark')
            elif kind == 'parts':
                mbe.box(x, y, 0, 1.6, 0.6, 1.2, 'graphite', rot=rot)
                for z in (0.35, 0.8):
                    mbe.box(x, y, z, 1.5, 0.5, 0.04, 'metal_light', rot=rot)
                mbe.box(x, y, 1.2, 1.6, 0.6, 0.05, 'neon_blue', rot=rot)
            elif kind == 'lamp':
                mbe.cyl(x, y, 0, 0.07, 4.8, 'graphite', seg=5)
                mbe.box(x, y, 4.8, 2.6 if abs(math.cos(math.radians(rot))) < 0.5 else 0.3, 0.3 if abs(math.cos(math.radians(rot))) < 0.5 else 2.6, 0.1, 'neon_white')
        mbe.finish(name, cw)
    # (V2) workshop equipment lines are generated by gc_detail.build_detail() with keep-clear checks
    # floor markings around lifts: hatch aprons
    mb = MB()
    for i in range(4):
        cy = -14 + 6.4 * i
        gq(mb, 41.5, cy - 3.0, 52.5, cy - 2.85, 0.05, 'mark_white'); gq(mb, 41.5, cy + 3.0, 52.5, cy + 3.15, 0.05, 'mark_white')
        cx = 16 + 6.4 * i
        gq(mb, cx - 3.0, 25.0, cx - 2.85, 33.5, 0.05, 'mark_white'); gq(mb, cx + 3.0, 25.0, cx + 3.15, 33.5, 0.05, 'mark_white')
    mb.finish("Workshop_Floor_Markings", cw)

    # =============================================================== FUEL + EV
    mb = MB()
    pumps_x = [-31, -21, -11]
    for p in pumps_x:
        mb.box(p, -34.2, 0, 1.2, 1.0, 0.22, 'concrete')       # pump island
        mb.box(p, -34.2, 0.22, 0.95, 0.55, 1.5, 'graphite')
        mb.box(p, -34.5, 0.9, 0.55, 0.04, 0.45, 'neon_cyan')    # pump screen (blank)
        mb.box(p - 0.6, -34.2, 0.25, 0.04, 0.2, 1.1, 'cabinet_orange'); mb.box(p + 0.6, -34.2, 0.25, 0.04, 0.2, 1.1, 'cabinet_orange')
        mb.box(p, -34.2, 1.72, 1.0, 0.6, 0.12, 'neon_amber')
    for i in range(6):
        pass
    # fuel bays markings: handled via bay2 into separate mesh
    mb2 = MB()
    fx = [-33.6, -28.4, -23.6, -18.4, -13.6, -8.4]
    for i, x in enumerate(fx):
        bay2(mb2, x, -37.5, 'N', 'neon_amber', four=True, bw=3.0, stop=False)
        add_slot("SLOT_fuel_%02d" % (i + 1), 'fuel', 'F', x, -37.5, 0.0, 'N', note='fuel bay, nose toward pump')
        mb2.box(x, -34.8, 0, 2.0, 0.18, 0.1, 'graphite')
    mb2.finish("Fuel_Bay_Markings", cf)
    # canopy: roof (6 m, NE of the bays), columns, rim lighting
    mb.box(-21.5, -32.6, 6.0, 34.0, 7.2, 0.45, 'graphite_dark', mtop='graphite')
    mb.box(-21.5, -32.6, 5.92, 33.0, 6.2, 0.04, 'neon_white')
    mb.box(-21.5, -36.1, 6.1, 34.0, 0.15, 0.3, 'neon_amber'); mb.box(-21.5, -29.1, 6.1, 34.0, 0.15, 0.3, 'neon_amber')
    mb.box(-4.6, -32.6, 6.1, 0.15, 7.2, 0.3, 'neon_amber'); mb.box(-38.4, -32.6, 6.1, 0.15, 7.2, 0.3, 'neon_amber')
    for cx in (-37.0, -26.0, -16.0, -6.0):
        mb.box(cx, -29.5, 0, 0.6, 0.6, 6.0, 'graphite'); mb.box(cx, -29.5, 0.1, 0.64, 0.64, 0.12, 'neon_cyan')
    # neon bollards at the front edge
    for i in range(14):
        P.place('bollard', cf, -38 + 2.6 * i, -41.6, 0.0, rot=0)
    # price/brand pylon (abstract symbol, no text)
    mb.box(-4.5, -44, 0, 0.6, 0.6, 9.0, 'graphite_dark')
    mb.box(-4.5, -44.4, 6.5, 2.0, 0.15, 2.0, 'graphite')

    mb.finish("Fuel_Canopy_Pumps", cf)
    # abstract neon symbol on pylon (ring + chevron)
    mb = MB()
    for i in range(24):
        a0, a1 = 2 * math.pi * i / 24, 2 * math.pi * (i + 1) / 24
        r0, r1 = 0.7, 0.9
        mb.quad((-4.5 + r0 * math.cos(a0), -44.5, 7.5 + r0 * math.sin(a0)), (-4.5 + r1 * math.cos(a0), -44.5, 7.5 + r1 * math.sin(a0)),
                (-4.5 + r1 * math.cos(a1), -44.5, 7.5 + r1 * math.sin(a1)), (-4.5 + r0 * math.cos(a1), -44.5, 7.5 + r0 * math.sin(a1)), 'neon_cyan')
    mb.tri((-4.9, -44.52, 7.2), (-4.1, -44.52, 7.2), (-4.5, -44.52, 8.0), 'neon_amber')
    mb.finish("Neon_Symbol_Fuel", cd)

    # EV charging
    mb = MB(); mb2 = MB()
    for i in range(6):
        cx = 27 + 4.5 * i
        bay2(mb2, cx, -40, 'N', 'neon_cyan', four=True, bw=3.0, stop=False)
        mb2.box(cx, -37.45, 0, 2.0, 0.18, 0.1, 'graphite')
        add_slot("SLOT_ev_%02d" % (i + 1), 'ev_charge', 'V', cx, -40, 0.0, 'N', note='EV charging bay, nose toward charge post')
    mb2.finish("EV_Bay_Markings", cf)
    for i in range(6):
        px_ = 27 + 4.5 * i + 2.25
        mb.box(px_, -36.3, 0, 0.5, 0.35, 1.5, 'graphite'); mb.box(px_, -36.5, 0.9, 0.34, 0.03, 0.5, 'neon_cyan')
        mb.box(px_, -36.3, 1.5, 0.52, 0.37, 0.08, 'neon_blue')
    mb.box(39, -34.2, 5.2, 36.0, 6.8, 0.4, 'graphite_dark', mtop='graphite')
    mb.box(39, -34.2, 5.1, 35.0, 5.8, 0.04, 'neon_cyan')
    mb.box(39, -37.55, 5.3, 36.0, 0.12, 0.28, 'neon_cyan'); mb.box(39, -30.85, 5.3, 36.0, 0.12, 0.28, 'neon_cyan')
    for cx in (22.0, 30.0, 39.0, 48.0, 56.0):
        mb.box(cx, -31.4, 0, 0.5, 0.5, 5.2, 'graphite'); mb.box(cx, -31.4, 0.1, 0.54, 0.54, 0.1, 'neon_blue')
    # solar-panel hint on roof
    for i in range(8):
        mb.box(23.5 + 4.2 * i, -34.2, 5.6, 3.8, 5.0, 0.05, 'glass')
    for i in range(14):
        P.place('bollard', cf, 25 + 2.6 * i, -45.5, 0.0, rot=0)
    mb.finish("EV_Canopy_Chargers", cf)

    # =============================================================== DETAILS: kiosks, terminals, utility cabinets, vents, bollards, symbols
    mb = MB()
    kiosks = [(-1.5, -26.2, 0), (13.5, -26.2, 0), (-8, -47.2, 0), (46, 14, 90), (-56, 12.5, 0), (-15.5, 17.5, 0), (0, 32.4, 0)]
    for (x, y, r) in kiosks:
        mb.box(x, y, 0, 1.2, 0.8, 1.9, 'graphite', rot=r, mtop='graphite_dark')
        sx_, sy_ = -0.41 * math.sin(math.radians(r)), -0.41 * math.cos(math.radians(r))
        mb.box(x + sx_ * 0.0, y - 0.38 * math.cos(math.radians(r)), 1.0, 0.8 if r == 0 else 0.02, 0.02 if r == 0 else 0.8, 0.6, 'neon_blue', rot=0)
        mb.box(x, y, 1.9, 1.4, 1.0, 0.08, 'neon_cyan', rot=r)
    # utility cabinets along walls
    for i in range(8):
        mb.box(-20 + 3.1 * i, 49.0, 0, 1.3, 0.7, 1.6, 'graphite', mtop='graphite_dark'); mb.box(-20 + 3.1 * i, 48.62, 1.3, 1.2, 0.02, 0.12, 'neon_amber')
    # ventilation / HVAC units along west wall
    for i in range(5):
        mb.box(-68.6, -48 + 11 * i, 0, 1.0, 3.0, 1.5, 'metal_light'); mb.cyl(-68.6, -48 + 11 * i, 1.5, 0.45, 0.06, 'graphite_dark', seg=8)
    # abstract neon symbols on tall stelae in the yard corners
    for (x, y, k) in [(-48, -26, 0), (22, -26, 1), (66, -22, 2), (-26, 28, 3)]:
        mb.box(x, y, 0, 0.5, 0.5, 5.5, 'graphite_dark')
        col = ['neon_violet', 'neon_cyan', 'neon_magenta', 'neon_amber'][k]
        for i in range(4):
            mb.box(x, y, 1.0 + 1.1 * i, 0.55, 0.55, 0.18, col if i % 2 == 0 else 'neon_white')
    mb.finish("Details_Kiosks_Cabinets_Vents", cd)

    # =============================================================== WALLS + gate
    mb = MB()
    for (x0, x1) in ((-72, -2), (14, 72)):
        mb.box((x0 + x1) / 2, -49.5, 0, x1 - x0, 1.0, 1.1, 'planter', mtop='foliage')
        gq(mb, x0, -48.9, x1, -48.8, 1.13, 'neon_cyan')
    mb.box(-70.5, -9.5, 0, 1.0, 80.0, 1.1, 'planter', mtop='foliage')
    gq(mb, -69.9, -49.0, -69.8, 29.5, 1.13, 'neon_cyan')
    # gate pylons
    for gx in (-2.6, 14.6):
        mb.box(gx, -49.5, 0, 1.2, 1.2, 4.5, 'graphite_dark')
        mb.box(gx, -49.5, 4.5, 1.3, 1.3, 0.12, 'neon_cyan')
        mb.box(gx, -49.5, 0.0, 1.3, 1.3, 0.1, 'neon_amber')
    mb.finish("Perimeter_Wall_S_W_Gate", cwall)
    # hedge strips between parking zones
    mb = MB()
    planter_row(mb, -68.5, -26.2, -44.0, -26.2, 0.0, h=0.5, w=0.9)
    planter_row(mb, -68.5, -23.0, -38.0, -23.0, 0.0, h=0.5, w=0.9)
    planter_row(mb, -68.5, 1.4, -38.0, 1.4, 0.0, h=0.5, w=0.9)
    planter_row(mb, 56.0, 15, 56.0, 23, 0.0, h=0.5, w=0.9)
    mb.finish("Hedge_Planters", cd)

    # =============================================================== VEGETATION (shared proto meshes)
    for x in range(-60, 70, 11):
        if -3 < x < 16: continue
        P.palm(veg, x + rng.uniform(-1, 1), -49.5, 1.1, rng)
    for y in range(-40, 30, 12):
        P.palm(veg, -70.5, y, 1.1, rng)
    for (x, y) in [(-44, -27.7), (-60, -27.7), (-52, 1.3), (-40, 1.3), (56, 17), (56, 23)]:
        P.palm(veg, x, y, 0.5, rng)
    # roof / terrace palms (V2 terraces: N1 front z 5.2, N2 front z 5.4, E1 front z 5.4, W2 roof z 5.7)
    for i in range(9):
        P.place('bush', veg, -66 + 5.6 * i + 1.4, 32.2, 5.25, scale=rng.uniform(0.7, 1.0), rng=rng)
    for i in range(12):
        P.place('bush', veg, -2 + 6.4 * i + 1.6, 39.2, 5.45, scale=rng.uniform(0.7, 1.0), rng=rng)
    for i in range(10):
        P.place('bush', veg, 59.2, -20 + 6.4 * i + 1.6, 5.45, scale=rng.uniform(0.7, 1.0), rng=rng)
    for i in range(14):
        a = 2 * math.pi * i / 14 + 0.1
        if 11.0 * math.sin(a) > 5.5 and abs(11.8 * math.cos(a)) < 16:
            continue    # keep the VIP pads (y=13) free
        P.place('planter_s', veg, 11.8 * math.cos(a), 11.0 * math.sin(a), 0.0, rot=math.degrees(a))
    for (x, y) in [(-5, -48.4), (16, -48.4), (-72.3, -52), (72.3, -52)]:
        P.place('planter_s', veg, x, y, 0.0)
    for i, x in enumerate(range(-20, 40, 11)):
        P.place('plazalight', cd, x + 0.5, -29.0, 0.0, rot=0)
    for (x, y) in [(-36, -30), (-36, -5), (20, -28), (60, -28), (-14, 30), (-70, 30), (30, 24), (60, 33)]:
        P.place('plazalight', cd, x, y, 0.0, rot=0)

    import gc_detail as GD
    GD.build_detail(C, rng)

    # soft emissive light pools on the floor (faux bounce light / wet-asphalt glow); alpha-blended decals
    mb = MB()
    ZG = dict(A='glow_amber', B='glow_cyan', C='glow_violet', D='glow_magenta', F='glow_amber', V='glow_cyan')
    for _i, s_ in enumerate(SLOTS):
        zz = 0.072 + (_i % 5) * 0.005
        if s_['zone'] in ZG:
            vert = s_['nose'] in 'NS'
            glow(mb, s_['x'], s_['y'], 7.2 if vert else 9.5, 9.5 if vert else 7.2, ZG[s_['zone']], z=zz)
        elif s_['zone'] == 'E':
            glow(mb, s_['x'], s_['y'], 12, 12, 'glow_blue', z=zz)
        elif s_['zone'] == 'W':
            glow(mb, s_['x'], s_['y'], 11, 11, 'glow_amber', z=zz)
    glow(mb, 0, 0, 40, 40, 'glow_cyan', z=0.066)
    glow(mb, 0, 0, 22, 22, 'glow_amber', z=0.104)
    glow(mb, -21, -37, 40, 16, 'glow_amber', z=0.062)
    glow(mb, 38, -40, 36, 16, 'glow_cyan', z=0.062)
    mb.finish("Floor_Glow_Decals", cd)

    return SLOTS
