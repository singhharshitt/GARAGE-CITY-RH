"""Pure-python GLB statistics: triangles (instances counted), mesh nodes, primitives, draw-call ESTIMATE, materials, textures."""
import json, struct, sys, os
def load(fn):
    b = open(fn, 'rb').read()
    ln = struct.unpack('<I', b[12:16])[0]
    js = json.loads(b[20:20 + ln])
    return js
def stats(fn):
    g = load(fn)
    acc = g.get('accessors', [])
    def prim_tris(p):
        if 'indices' in p: n = acc[p['indices']]['count']
        else: n = acc[p['attributes']['POSITION']]['count']
        mode = p.get('mode', 4)
        return n // 3 if mode == 4 else 0
    meshes = g.get('meshes', [])
    mt = [sum(prim_tris(p) for p in m['primitives']) for m in meshes]
    mp = [len(m['primitives']) for m in meshes]
    tris = nodes = prims = 0
    used_mats = set()
    for nd in g.get('nodes', []):
        if 'mesh' in nd:
            tris += mt[nd['mesh']]; prims += mp[nd['mesh']]; nodes += 1
    used = set(p.get('material', -1) for m in meshes for p in m['primitives'])
    img = g.get('images', [])
    texs = len(img)
    return dict(file=os.path.basename(fn), bytes=os.path.getsize(fn), triangles=tris, mesh_nodes=nodes, unique_meshes=len(meshes),
                primitives_drawcalls_est=prims, materials=len(g.get('materials', [])), textures=texs,
                nodes=len(g.get('nodes', [])), transparent_materials=sum(1 for m in g.get('materials', []) if m.get('alphaMode') == 'BLEND'),
                extensions=g.get('extensionsUsed', []))
if __name__ == '__main__':
    out = [stats(f) for f in sys.argv[1:]]
    print(json.dumps(out, indent=1))
