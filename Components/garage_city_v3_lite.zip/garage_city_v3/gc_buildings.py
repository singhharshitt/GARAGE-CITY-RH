"""V2 buildings: N1 showroom, N2 workshop hall, E1 service centre (+loading dock), W2 utility block, D1 detail studio,
fuel-station shop, EV lounge + battery yard.  Called from build_garage.build_garage()."""
from gc_arch import *
from gc_arch import _c

def railing2(mb, x0, y0, x1, y1, z, h=1.05, neon='neon_cyan', post=2.2):
    L = math.hypot(x1 - x0, y1 - y0)
    n = max(1, int(L / post))
    ang = math.degrees(math.atan2(y1 - y0, x1 - x0))
    for i in range(n + 1):
        t = i / n
        mb.box(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, z, 0.07, 0.07, h, 'graphite_dark', rot=ang)
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    mb.box(cx, cy, z + h, L, 0.09, 0.05, 'metal_light', rot=ang)
    mb.box(cx, cy, z + h * 0.5, L, 0.03, 0.03, 'metal_light', rot=ang)
    if neon:
        mb.box(cx, cy, z + h + 0.05, L, 0.05, 0.025, neon, rot=ang)

def planter_box(mb, x, y, z, L, w=0.9, h=0.5, rot=0):
    mb.box(x, y, z, L, w, h, 'planter', rot=rot, mtop='foliage')
    mb.box(x, y, z + h + 0.01, L - 0.2, w - 0.2, 0.22, 'foliage_b', rot=rot)

def parapet(mb, x0, y0, x1, y1, z, h=0.45, t=0.3, m='graphite', cap='metal_light', skip=()):
    sides = {'S': (x0, y0, x1, y0 + t), 'N': (x0, y1 - t, x1, y1), 'W': (x0, y0, x0 + t, y1), 'E': (x1 - t, y0, x1, y1)}
    for k, (a, b, c, d) in sides.items():
        if k in skip:
            continue
        mb.box((a + c) / 2, (b + d) / 2, z, c - a, d - b, h, m, mtop=cap)

def interior_shell(mb, x0, y0, x1, y1, z0, z1, front='S'):
    """warm lit interior room: floor, back/side walls, ceiling underside is not needed (never visible)."""
    mb.box((x0 + x1) / 2, (y0 + y1) / 2, z0 - 0.2, x1 - x0, y1 - y0, 0.2, 'concrete', mtop='int_floor')
    h = z1 - z0
    if front != 'N':
        mb.box((x0 + x1) / 2, y1 - 0.05, z0, x1 - x0, 0.1, h, 'int_wall', top=False)
    if front != 'S':
        mb.box((x0 + x1) / 2, y0 + 0.05, z0, x1 - x0, 0.1, h, 'int_wall', top=False)
    if front != 'E':
        mb.box(x1 - 0.05, (y0 + y1) / 2, z0, 0.1, y1 - y0, h, 'int_wall', top=False)
    if front != 'W':
        mb.box(x0 + 0.05, (y0 + y1) / 2, z0, 0.1, y1 - y0, h, 'int_wall', top=False)

def build_buildings(C, rng):
    cb, cc, cd, cf = C['Buildings'], C['Circulation'], C['Details'], C['Fuel_EV']
    # =========================================================================================== N2 WORKSHOP HALL
    # ground floor (z 0.2-5.0) workshop with open roll-up doors, glazed front, warm interior; upper office level setback
    mb = MB()
    X0, X1, Y0, Y1 = -6.0, 70.0, 38.0, 50.0
    mb.box(32, 44, 0, 76, 12, 0.2, 'concrete', mtop='int_floor')
    # structure shell: back wall, end walls, ceiling slab
    mb.box(32, 49.8, 0.2, 76, 0.4, 4.8, 'graphite')
    mb.box(-5.8, 44, 0.2, 0.4, 12, 4.8, 'graphite'); mb.box(69.8, 44, 0.2, 0.4, 12, 4.8, 'graphite')
    mb.box(32, 49.55, 0.2, 75, 0.1, 4.7, 'int_wall', top=False)
    mb.box(-5.55, 44, 0.2, 0.1, 11.4, 4.7, 'int_wall', top=False); mb.box(69.55, 44, 0.2, 0.1, 11.4, 4.7, 'int_wall', top=False)
    mb.box(32, 44, 5.0, 76, 12, 0.4, 'concrete', mtop='terrace')
    wF = Wall(mb, 'x', 38.0)
    N2_DOORS = [(4, 6.0), (16, 4.4), (22.4, 4.4), (28.8, 4.4), (35.2, 4.4), (48, 6.0)]
    facade(wF, -6, 70, 0.2, 5.0, doors=N2_DOORS, pier=3.8)
    awning(wF, 13.4, 37.8, 4.55, 3.6)       # service-bay apron canopy (NE of lifts => never over a slot)
    # upper office volume (y 41..50, z 5.4..10) with ribbon glazing
    mb.box(32, 45.5, 5.4, 76, 9, 4.6, 'graphite', mtop='terrace')
    wU = Wall(mb, 'x', 41.0)
    facade(wU, -6, 70, 5.4, 10.0, pier=4.2, plinth=0.9, lights=False, trim='neon_amber')
    mb.box(32, 41.45, 5.9, 75, 0.1, 3.4, 'int_wall', top=False)      # warm office interior seen through the glass
    for i in range(8):
        mb.box(-1 + 9.6 * i, 41.55, 6.4, 3.0, 0.06, 0.1, 'int_panel')
    # west end elevation details (visible from the SW cameras)
    mb.box(-6.2, 40, 0.2, 0.15, 1.6, 3.0, 'steel_painted')                      # side service door
    mb.box(-6.25, 44.5, 6.4, 0.1, 3.0, 2.4, 'glass_tint'); mb.box(-6.25, 47.5, 6.4, 0.1, 2.0, 2.4, 'glass_tint')
    mb.finish("Bld_N2_Shell", cb)

    mb = MB()    # N2 roofs, terraces, rooftop plant
    # front terrace (roof of ground floor) z 5.4
    mb.box(32, 39.5, 5.4, 76, 3.0, 0.05, 'terrace')
    railing2(mb, -5.5, 38.35, 69.5, 38.35, 5.4)
    for i in range(12):
        planter_box(mb, -2 + 6.4 * i, 39.2, 5.45, 3.0, 0.9)
    for i in range(6):
        bench(mb, 1 + 12.4 * i, 40.3, 0)
    mb.box(32, 45.5, 10.0, 76, 9.0, 0.3, 'concrete', mtop='terrace')
    parapet(mb, -6, 41, 70, 50, 10.3, skip=())
    # west: barrel vault (x -6..22)
    mb.vault(8, 45.5, 10.3, 28, 8.2, 1.5, 'metal_light', axis='x', seg=8, mcap='graphite')
    for i in range(8):
        mb.box(-4 + 3.5 * i, 45.5, 10.3, 0.12, 8.2, 0.1, 'graphite_dark')
    mb.box(8, 41.6, 10.32, 27, 0.08, 0.12, 'neon_cyan')
    # middle (x 22..46): V3 -- plant moved onto the new paint & body tower roof (gc_massing); only a low service apron remains here
    mb.box(34, 41.4, 10.3, 24, 0.6, 0.25, 'graphite_dark')
    # east: sawtooth skylights (x 46..70), glazed faces to the south (visible), warm glow behind
    for k in range(3):
        y0 = 42.3 + 2.7 * k
        mb.wedge(58, y0 + 1.35, 10.3, 2.7, 23.0, 1.5, 'metal_light', rot=-90, mside='graphite')
        mb.box(58, y0 - 0.02, 10.9, 23.0, 0.05, 0.85, 'glass_tint')
        mb.box(58, y0 + 0.05, 10.9, 22.8, 0.04, 0.8, 'int_panel')
    solar_row(mb, 49, 49.0, 5, 4.2, w=3.6, d=1.4, z=10.3, tilt=0.35)
    # roof mast + antenna
    mb.cyl(66, 46, 10.3, 0.15, 9, 'metal_light', seg=4); mb.box(66, 46, 19.2, 0.3, 0.3, 0.3, 'neon_amber')
    mb.finish("Roof_N2_Terrace", cb)

    # interior fit-out
    mb = MB()
    for (ux, w_) in N2_DOORS[1:5]:
        hoist(mb, ux, 43.6, rot=90)
        for (a, b, c_, d_) in ((ux - 2.4, 40.3, ux + 2.4, 40.4), (ux - 2.4, 46.9, ux + 2.4, 47.0), (ux - 2.4, 40.3, ux - 2.3, 47.0), (ux + 2.3, 40.3, ux + 2.4, 47.0)):
            gq(mb, a, b, c_, d_, 0.215, 'mark_yellow')
        pendant(mb, ux, 41.2, 4.4, 2.2); pendant(mb, ux, 46.0, 4.4, 2.2)
    for x in (9.8, 41.2):
        workbench(mb, x, 39.4, 0); tool_cabinet(mb, x + 1.6, 39.2, 0)
    for i in range(7):
        tool_cabinet(mb, -4 + 2.4 * i, 49.0, 0)
    for i in range(6):
        shelf_unit(mb, 54 + 2.8 * i, 49.1, 0) if i % 2 == 0 else tire_rack(mb, 54 + 2.8 * i, 49.0, 0)
    for i in range(4):
        tire_rack(mb, 8 + 2.4 * i, 49.0, 0, rows=3)
    for x in (53, 58, 63, 67):
        workbench(mb, x, 40.2, 0, 2.4)
    tool_cart(mb, 56, 42.5, 20); tool_cart(mb, 61.5, 43, -15); tool_cart(mb, 12, 41.5, 10)
    compressor(mb, 68.2, 45, 90); drum(mb, 68.4, 47.2); drum(mb, 67.5, 47.6, 'cabinet_orange')
    pipe_run(mb, [(-5, 49.2, 4.5), (68, 49.2, 4.5)], r=0.1)
    pipe_run(mb, [(-5, 48.6, 4.2), (68, 48.6, 4.2)], r=0.06, m='cabinet_orange')
    for x in (8, 20, 33, 46, 59):
        pendant(mb, x, 48.2, 4.4, 2.6)
    gq(mb, 51, 41, 69, 49, 0.208, 'glow_amber'); gq(mb, 0, 40, 40, 48, 0.209, 'glow_amber')
    mb.finish("Int_N2_Workshop", cb)

    # =========================================================================================== E1 SERVICE CENTRE
    mb = MB()
    mb.box(64, 7, 0, 12, 62, 0.2, 'concrete', mtop='int_floor')
    mb.box(69.8, 7, 0.2, 0.4, 62, 4.8, 'graphite')
    mb.box(64, -23.8, 0.2, 12, 0.4, 4.8, 'graphite'); mb.box(64, 37.8, 0.2, 12, 0.4, 4.8, 'graphite')
    mb.box(69.55, 7, 0.2, 0.1, 61, 4.7, 'int_wall', top=False)
    mb.box(64, -23.55, 0.2, 11.4, 0.1, 4.7, 'int_wall', top=False)
    mb.box(64, 7, 5.0, 12, 62, 0.4, 'concrete', mtop='terrace')
    wE = Wall(mb, 'y', 58.0)
    E1_DOORS = [(-20.5, 5.0), (-14, 4.4), (-7.6, 4.4), (-1.2, 4.4), (5.2, 4.4)]
    facade(wE, -24, 10, 0.2, 5.0, doors=E1_DOORS, pier=3.8)
    facade(wE, 10, 24, 0.2, 5.0, doors=[(17, 3.2)], pier=3.5, roll_up=False)
    facade(wE, 24, 38, 0.2, 5.0, doors=[(27, 3.2), (31, 3.2), (35, 3.2)], pier=3.5, door_h=3.2)
    # interior partition between service hall and lounge
    mb.box(63.9, 10.0, 0.2, 11.6, 0.2, 4.8, 'int_wall'); mb.box(63.9, 24.0, 0.2, 11.6, 0.2, 4.8, 'int_wall')
    # upper level volume (x 62..70, z 5.4..8.4) + glazing
    mb.box(66, 7, 5.4, 8, 60, 3.0, 'graphite', mtop='terrace')
    wEu = Wall(mb, 'y', 62.0)
    facade(wEu, -22, 36, 5.4, 8.4, pier=4.0, plinth=0.8, lights=False, trim='neon_amber')
    mb.box(62.45, 7, 5.9, 0.1, 58, 2.1, 'int_wall', top=False)
    mb.finish("Bld_E1_ServiceCentre", cb)
    mb = MB()
    # E1 terrace (roof of ground floor, x 58..62 at z 5.4) + roof
    mb.box(60, 7, 5.4, 4.0, 62, 0.05, 'terrace')
    railing2(mb, 58.35, -23.6, 58.35, 37.6, 5.4)
    for i in range(10):
        planter_box(mb, 59.2, -20 + 6.4 * i, 5.45, 3.0, 0.9, rot=90)
    for i in range(5):
        bench(mb, 60.8, -17 + 12 * i, 90)
    mb.box(66, 7, 8.4, 8.4, 60.4, 0.3, 'concrete', mtop='terrace')
    parapet(mb, 61.8, -23.2, 70, 37.2, 8.7, skip=())
    for i in range(4):
        hvac_unit(mb, 66, -18 + 11 * i, 8.7, rot=90)
    for i in range(3):
        vent_stack(mb, 63.5, -12 + 14 * i, 8.7, 2.0)
    solar_row(mb, 67.8, 26.5, 1, 1.0, w=0.1, d=0.1, z=8.7, tilt=0.0) if False else None
    for i in range(6):
        solar_row(mb, 68.3, -22 + 3.3 * i, 1, 1, w=2.6, d=2.8, z=8.7, tilt=0.45)
    pipe_run(mb, [(64.5, -22, 9.5), (64.5, 16, 9.5)], r=0.1)
    cable_tray(mb, 69, -22, 69, 16, 8.75)
    # dock platform + dock levellers + bumpers + ramp (north part of the facade)
    mb.box(56.2, 31, 0, 3.6, 13.4, 1.1, 'concrete', mtop='graphite')
    for yd in (27, 31, 35):
        mb.box(56.5, yd, 1.1, 2.4, 2.4, 0.06, 'metal_light'); mb.box(54.8, yd, 0.5, 0.25, 1.0, 0.45, 'rubber')
        mb.box(54.4, yd, 0.15, 0.3, 3.0, 0.03, 'hazard')
    mb.wedge(55.0, 21.0, 0, 7.0, 3.4, 1.1, 'concrete', rot=90, mside='graphite') if False else None
    mb.wedge(56.2, 22.3, 0, 3.0, 3.6, 1.1, 'concrete', rot=0, mside='graphite') if False else None
    railing2(mb, 54.5, 24.3, 54.5, 25.6, 1.1, neon=None); railing2(mb, 54.5, 36.6, 54.5, 37.5, 1.1, neon=None)
    mb.finish("Roof_E1_Terrace_Dock", cb)
    # E1 interior
    mb = MB()
    for (uy, w_) in E1_DOORS[1:]:
        hoist(mb, 63.6, uy, rot=0)
        for (a, b, c_, d_) in ((60.6, uy - 2.6, 66.6, uy - 2.5), (60.6, uy + 2.5, 66.6, uy + 2.6)):
            gq(mb, a, b, c_, d_, 0.215, 'mark_yellow')
        pendant(mb, 60.5, uy, 4.4, 2.2, rot=90); pendant(mb, 66, uy, 4.4, 2.2, rot=90)
    for i in range(6):
        tool_cabinet(mb, 69.0, -20 + 3.3 * i, 90) if i % 2 == 0 else shelf_unit(mb, 69.1, -20 + 3.3 * i, 90)
    tire_rack(mb, 59.4, -11, 90); tire_rack(mb, 59.4, -4.6, 90) if False else None
    workbench(mb, 59.2, 8.2, 90, 2.2)
    # lounge (y 10..24)
    for k in range(3):
        mb.box(61 + 0, 12.5 + 3.5 * k, 0.2, 1.8, 0.9, 0.42, 'steel_teal', rot=90); mb.box(60.4, 12.5 + 3.5 * k, 0.55, 0.2, 1.6, 0.5, 'steel_teal', rot=0)
        mb.box(62.8, 12.5 + 3.5 * k, 0.2, 0.9, 0.9, 0.38, 'graphite')
    mb.box(67.5, 17, 0.2, 1.0, 8.0, 1.1, 'graphite_dark', mtop='metal_light')           # reception counter
    terminal(mb, 67.3, 14.2, 90); terminal(mb, 67.3, 19.8, 90)
    for y_ in (11.5, 22.5):
        mb.cyl(59.8, y_, 0.2, 0.3, 0.5, 'planter', seg=8, mtop='foliage'); mb.cyl(59.8, y_, 0.7, 0.45, 1.0, 'foliage_b', seg=7, r2=0.1)
    # dock hall interior (y 24..38)
    for i in range(5):
        mb.box(66.5, 26 + 2.4 * i, 0.2, 1.3, 1.3, 1.0 + 0.2 * (i % 3), 'cabinet_orange' if i % 2 else 'cabinet_blue')
    pendant(mb, 61, 25.5, 4.4, 2.2, rot=90); pendant(mb, 61, 32, 4.4, 2.2, rot=90)
    pipe_run(mb, [(69.0, -23, 4.4), (69.0, 37, 4.4)], r=0.09)
    pipe_run(mb, [(69.0, -23, 4.0), (69.0, 37, 4.0)], r=0.05, m='cabinet_orange')
    gq(mb, 59, -23, 69, 9, 0.208, 'glow_amber'); gq(mb, 59, 11, 69, 23, 0.209, 'glow_amber')
    mb.finish("Int_E1_ServiceCentre", cb)

    # =========================================================================================== N1 SHOWROOM
    mb = MB()
    mb.box(-41, 40, 0, 58, 20, 0.2, 'concrete', mtop='int_floor')
    mb.box(-41, 49.8, 0.2, 58, 0.4, 4.6, 'graphite')
    mb.box(-69.8, 40, 0.2, 0.4, 20, 4.6, 'graphite'); mb.box(-12.2, 40, 0.2, 0.4, 20, 4.6, 'graphite')
    mb.box(-41, 49.55, 0.2, 57, 0.1, 4.5, 'int_wall', top=False)
    mb.box(-69.55, 40, 0.2, 0.1, 19, 4.5, 'int_wall', top=False)
    mb.box(-41, 40, 4.8, 58, 20, 0.4, 'concrete', mtop='terrace')
    wN = Wall(mb, 'x', 30.0)
    facade(wN, -70, -12, 0.2, 4.8, doors=[(-60, 3.4), (-41, 3.8), (-24, 3.4)], pier=4.0, roll_up=False, door_h=3.2)
    # second level: set back 3 m (y 33..50) + a full-depth stair-tower block at the east end (x -19..-12)
    mb.box(-44.5, 41.5, 5.2, 51, 17, 3.0, 'graphite', mtop='terrace')
    mb.box(-15.5, 40, 5.2, 7, 20, 3.0, 'graphite', mtop='terrace')
    wN2 = Wall(mb, 'x', 33.0)
    facade(wN2, -70, -19, 5.2, 8.2, pier=4.0, plinth=0.8, lights=False, trim='neon_amber')
    mb.box(-44.5, 33.45, 5.7, 50, 0.1, 2.2, 'int_wall', top=False)
    wN3 = Wall(mb, 'x', 30.0)
    facade(wN3, -19, -12, 5.2, 8.2, pier=3.5, plinth=0.8, lights=False, trim='neon_amber')
    mb.box(-15.5, 30.45, 5.7, 6.5, 0.1, 2.2, 'int_wall', top=False)
    mb.finish("Bld_N1_Showroom", cb)
    mb = MB()
    mb.box(-44.5, 31.5, 5.2, 51, 3.0, 0.05, 'terrace')            # front terrace z 5.2 (y 30..33)
    railing2(mb, -69.6, 30.3, -19, 30.3, 5.2, neon='neon_cyan')
    for i in range(9):
        planter_box(mb, -66 + 5.6 * i, 32.2, 5.25, 3.0, 0.9)
    for i in range(3):
        bench(mb, -58 + 18 * i, 31.2, 0)
    mb.box(-41, 41.5, 8.2, 58, 17.0, 0.3, 'concrete', mtop='terrace')
    parapet(mb, -70, 33, -12, 50, 8.5)
    # west part: sawtooth/vault mix; centre: pergola + garden; east: plant
    mb.vault(-58, 41.5, 8.5, 22, 8.0, 1.4, 'metal_light', axis='x', seg=8, mcap='graphite')
    for i in range(6):
        mb.box(-67.5 + 4 * i, 41.5, 8.5, 0.12, 8.0, 0.1, 'graphite_dark')
    mb.box(-41, 37.0, 8.5, 14, 6, 0.06, 'lawn')
    for px_ in (-48, -34):
        for py_ in (35, 40):
            mb.box(px_, py_, 8.5, 0.2, 0.2, 3.0, 'graphite_dark')
    mb.box(-41, 37.5, 11.5, 15.5, 6.0, 0.14, 'graphite_dark')
    for k in range(9):
        mb.box(-47.5 + 1.7 * k, 37.5, 11.64, 0.12, 6.0, 0.1, 'metal_light')
    mb.box(-41, 37.5, 11.46, 15.0, 5.6, 0.03, 'neon_amber')
    for i in range(3):
        bench(mb, -44 + 3.4 * i, 37.2, 0)
    for i in range(4):
        hvac_unit(mb, -27 + 3.8 * i, 46.5, 8.5, rot=0)
    solar_row(mb, -66, 47.0, 6, 3.3, w=2.8, d=2.6, z=8.5, tilt=0.45)
    for i in range(3):
        vent_stack(mb, -26 + 4 * i, 36.5, 8.5, 2.0)
    pipe_run(mb, [(-27, 44, 9.4), (-12.5, 44, 9.4)], r=0.09)
    mb.finish("Roof_N1_Terrace", cb)
    # N1 interior (showroom): EMPTY display pedestals, reception, lounge
    mb = MB()
    for i in range(6):
        cx = -63 + 9.2 * i
        mb.cyl(cx, 35.0, 0.2, 2.1, 0.28, 'graphite', seg=14, mtop='paving')
        mb.ring_flat(cx, 35.0, 0.49, 1.7, 1.9, 'neon_cyan', seg=16)
        mb.cyl(cx, 35.0, 0.2, 2.15, 0.04, 'neon_amber', seg=14, top=False)
        pendant(mb, cx, 35.0, 4.2, 3.0, rot=0)
    mb.box(-14.5, 43, 0.2, 1.0, 8.0, 1.1, 'graphite_dark', mtop='metal_light')                       # reception counter
    terminal(mb, -15.3, 40.3, 90); terminal(mb, -15.3, 45.7, 90)
    for k in range(4):
        mb.box(-36 + 5 * k, 43.5, 0.2, 2.0, 0.9, 0.42, 'steel_teal'); mb.box(-36 + 5 * k, 44.2, 0.55, 2.0, 0.2, 0.5, 'steel_teal')
        mb.box(-36 + 5 * k, 42.0, 0.2, 0.9, 0.9, 0.38, 'graphite')
    for x_ in (-68.4, -13.6):
        mb.cyl(x_, 33.2, 0.2, 0.3, 0.5, 'planter', seg=8, mtop='foliage'); mb.cyl(x_, 33.2, 0.7, 0.45, 1.0, 'foliage_b', seg=7, r2=0.1)
    for k in range(9):
        mb.box(-66.5 + 6.2 * k, 49.2, 0.5, 0.2, 0.1, 3.4, 'int_panel')                                 # back-wall light slots
    gq(mb, -69, 31, -13, 40, 0.208, 'glow_amber')
    mb.finish("Int_N1_Showroom", cb)

    # =========================================================================================== W2 UTILITY / STORAGE BLOCK
    mb = MB()
    mb.box(-64, 18, 0, 12, 20, 5.4, 'concrete', mtop='terrace')
    wW = Wall(mb, 'x', 8.0)
    # south face: storage roll-up doors (closed), louvre panels, small glazed office
    for i in range(3):
        ux = -68.4 + 3.1 * i if False else -67.7 + 3.4 * i
    wW.box(-66.6, 0.1, 0.3, 3.2, 0.12, 3.4, 'steel_painted')         # closed roll-up door
    for k in range(10):
        wW.box(-66.6, 0.17, 0.4 + k * 0.34, 3.1, 0.05, 0.05, 'graphite_dark')
    wW.box(-66.6, 0.12, 3.8, 3.8, 0.3, 0.3, 'graphite')
    for k in range(12):
        wW.box(-61.3, 0.12, 0.7 + k * 0.32, 2.8, 0.16, 0.1, 'graphite_dark')                  # louvres
    wW.box(-61.3, 0.06, 0.4, 3.2, 0.08, 4.2, 'int_dark')
    wW.box(-63.6, 0.08, 0.3, 0.3, 0.3, 4.6, 'graphite')
    wW.box(-64, 0.22, 4.9, 12, 0.5, 0.5, 'graphite_dark'); wW.box(-64, 0.5, 4.95, 12, 0.04, 0.07, 'neon_cyan')
    # upper office block (y 18..28, z 5.6..8.4) with glazed south face
    mb.box(-66, 23, 5.6, 8, 10, 2.8, 'graphite', mtop='terrace')   # office set back from the yard edge (keeps SLOT_display_01 sight-line free)
    wW2 = Wall(mb, 'x', 18.0)
    facade(wW2, -70, -62, 5.6, 8.4, pier=3.0, plinth=0.7, lights=False, trim='neon_amber')
    mb.box(-66, 18.45, 6.0, 7.5, 0.1, 2.0, 'int_wall', top=False)
    # east face (towards the yard): equipment doors + pipe rack
    wEW = Wall(mb, 'y', -58.0)
    for k in range(3):
        wEW.box(11.5 + 5.5 * k, 0.12, 0.3, 3.2, 0.12, 3.4, 'steel_painted')
        for q in range(9):
            wEW.box(11.5 + 5.5 * k, 0.18, 0.4 + q * 0.36, 3.1, 0.05, 0.05, 'graphite_dark') if False else None
    for k in range(5):
        wEW.box(14 + 3.2 * k, 0.1, 0.5, 1.4, 0.08, 4.0, 'graphite_dark')
    mb.finish("Bld_W2_UtilityBlock", cb)
    mb = MB()
    mb.box(-64, 13, 5.4, 12, 10, 0.3, 'concrete', mtop='terrace')
    parapet(mb, -70, 8, -58, 18, 5.7, h=0.4, skip=('E',))
    mb.box(-58.15, 13, 5.7, 0.3, 10, 0.12, 'graphite', mtop='metal_light')    # low kerb on the yard side (keeps display sight-lines clear)
    for i in range(3):
        hvac_unit(mb, -66.5 + 3.8 * (i % 2) + 0.5, 10 + 3.2 * i, 5.7, rot=90, sx=2.4, sy=1.5)
    for (x_, y_) in ((-63.5, 15.5), (-63.5, 11)):
        mb.cyl(x_, y_, 5.7, 0.9, 2.4, 'steel_painted', seg=10, mtop='graphite_dark')       # tanks
    vent_stack(mb, -68, 16.5, 5.7, 3.2, 0.35)
    pipe_run(mb, [(-63.5, 12.5, 6.4), (-63.5, 17, 6.4), (-64, 17, 6.4), (-64, 17.9, 6.4)], r=0.1)
    solar_row(mb, -65, 15.5, 3, 2.6, w=2.2, d=1.8, z=5.7, tilt=0.35)
    mb.box(-66, 23, 8.4, 8, 10, 0.3, 'concrete', mtop='terrace')
    for i in range(3):
        hvac_unit(mb, -68.4 + 2.6 * i, 25.5, 8.7, rot=0, sx=2.4, sy=1.5)
    parapet(mb, -70, 18, -62, 28, 8.7, h=0.4)
    mb.cyl(-64, 21, 8.7, 0.15, 7, 'metal_light', seg=4); mb.box(-64, 21, 15.7, 0.3, 0.3, 0.3, 'neon_magenta')
    mb.finish("Roof_W2_Equipment", cb)
    # service corridor W2 <-> N1 (glazed link, z 0..3.2)
    mb = MB()
    mb.box(-64, 29, 0, 3.0, 2.2, 0.15, 'concrete', mtop='int_floor')
    mb.box(-64, 29, 3.0, 3.4, 2.4, 0.25, 'graphite', mtop='terrace')
    for sx_ in (-1, 1):
        mb.box(-64 + sx_ * 1.55, 29, 0.15, 0.1, 2.0, 2.85, 'glass_tint')
        mb.box(-64 + sx_ * 1.6, 28.05, 0, 0.25, 0.25, 3.0, 'graphite'); mb.box(-64 + sx_ * 1.6, 29.95, 0, 0.25, 0.25, 3.0, 'graphite')
    mb.box(-64, 29, 2.9, 3.0, 2.0, 0.05, 'int_panel')
    mb.finish("Service_Corridor_W2_N1", cc)

    # =========================================================================================== D1 DETAILING STUDIO (central yard)
    mb = MB()
    DX0, DX1, DY0, DY1 = 22.0, 35.0, 6.0, 16.0
    mb.box(28.5, 11, 0, 13, 10, 0.2, 'concrete', mtop='int_floor')
    mb.box(28.5, 15.8, 0.2, 13, 0.4, 4.2, 'graphite'); mb.box(34.8, 11, 0.2, 0.4, 10, 4.2, 'graphite')
    mb.box(28.5, 15.55, 0.2, 12, 0.1, 4.0, 'int_wall', top=False); mb.box(34.55, 11, 0.2, 0.1, 9, 4.0, 'int_wall', top=False)
    mb.box(28.5, 11, 4.4, 13, 10, 0.35, 'concrete', mtop='terrace')
    wD = Wall(mb, 'x', DY0)
    facade(wD, DX0, DX1, 0.2, 4.4, doors=[(26.5, 4.4), (31.5, 4.4)], pier=3.2)
    wDw = Wall(mb, 'y', DX0)
    facade(wDw, DY0, DY1, 0.2, 4.4, pier=3.2, doors=[(11, 1.8)], roll_up=False, door_h=2.6)
    mb.finish("Bld_D1_DetailStudio", cb)
    mb = MB()
    parapet(mb, 22, 6, 35, 16, 4.75, h=0.4)
    mb.vault(28.5, 11, 4.75, 12.4, 9.0, 1.1, 'metal_light', axis='y', seg=8, mcap='graphite')
    mb.box(28.5, 6.2, 4.78, 12.6, 0.1, 0.12, 'neon_cyan')
    hvac_unit(mb, 33.0, 14.5, 4.75, rot=0, sx=2.2, sy=1.4)
    vent_stack(mb, 24, 14, 4.75, 1.6)
    mb.finish("Roof_D1", cb)
    mb = MB()
    for ux in (26.5, 31.5):
        hoist(mb, ux, 11.0, rot=90)
        pendant(mb, ux, 8.6, 3.9, 2.0); pendant(mb, ux, 13.6, 3.9, 2.0)
    workbench(mb, 34.2, 11, 90, 3.0); tool_cabinet(mb, 34.2, 14, 90)
    tool_cart(mb, 23.5, 13.5, 20); terminal(mb, 23.0, 8.0, 0); drum(mb, 34, 7.2)
    gq(mb, 22.5, 6.5, 34.5, 15.5, 0.208, 'glow_amber')
    mb.finish("Int_D1_DetailStudio", cb)

    # =========================================================================================== FUEL SHOP
    mb = MB()
    mb.box(-22.5, -23.5, 0, 17, 6.0, 0.2, 'concrete', mtop='int_floor')
    mb.box(-22.5, -20.7, 0.2, 17, 0.4, 3.8, 'graphite'); mb.box(-31.2, -23.5, 0.2, 0.4, 6, 3.8, 'graphite'); mb.box(-13.8, -23.5, 0.2, 0.4, 6, 3.8, 'graphite')
    mb.box(-22.5, -20.95, 0.2, 16, 0.1, 3.6, 'int_wall', top=False); mb.box(-30.95, -23.5, 0.2, 0.1, 5.2, 3.6, 'int_wall', top=False)
    mb.box(-22.5, -23.5, 4.0, 17, 6.0, 0.4, 'concrete', mtop='terrace')
    wS = Wall(mb, 'x', -26.5)
    facade(wS, -31, -14, 0.2, 4.0, doors=[(-22.5, 3.0)], pier=3.4, roll_up=False, door_h=3.0)
    mb.box(-22.5, -26.8, 4.4, 12.0, 0.3, 0.9, 'graphite_dark'); mb.box(-22.5, -26.97, 4.55, 10.0, 0.05, 0.6, 'neon_amber')   # blank sign band
    parapet(mb, -31.4, -26.7, -13.6, -20.4, 4.4, h=0.4)
    hvac_unit(mb, -18, -22.5, 4.4, rot=0, sx=2.2, sy=1.4); vent_stack(mb, -27, -22, 4.4, 1.8)
    # shop interior: shelf rows, coolers, counter
    for k in range(4):
        shelf_unit(mb, -29 + 3.2 * k, -23.0, 0, L=2.4, levels=3, hgt=1.6)
    mb.box(-16.5, -24.2, 0.2, 0.7, 3.2, 1.1, 'graphite_dark', mtop='metal_light')
    mb.box(-30.2, -23.5, 0.2, 0.6, 4.6, 1.9, 'steel_teal'); mb.box(-29.9, -23.5, 0.8, 0.02, 4.4, 0.9, 'neon_blue')
    pendant(mb, -25, -24.8, 3.6, 2.4); pendant(mb, -19, -24.8, 3.6, 2.4)
    gq(mb, -30.5, -26, -14.5, -21, 0.208, 'glow_amber')
    mb.finish("Bld_Fuel_Shop", cf)

    # =========================================================================================== EV LOUNGE + battery yard
    mb = MB()
    mb.box(63.5, -37, 0, 11, 8, 0.2, 'concrete', mtop='int_floor')
    mb.box(68.8, -37, 0.2, 0.4, 8, 3.6, 'graphite'); mb.box(63.5, -33.2, 0.2, 11, 0.4, 3.6, 'graphite'); mb.box(63.5, -40.8, 0.2, 11, 0.4, 3.6, 'graphite')
    mb.box(68.55, -37, 0.2, 0.1, 7.2, 3.5, 'int_wall', top=False); mb.box(63.5, -33.45, 0.2, 10.4, 0.1, 3.5, 'int_wall', top=False)
    mb.box(63.5, -37, 3.8, 11, 8, 0.4, 'concrete', mtop='terrace')
    wEv = Wall(mb, 'y', 58.0)
    facade(wEv, -41, -33, 0.2, 3.8, doors=[(-37, 2.4)], pier=2.7, roll_up=False, door_h=3.0, trim='neon_cyan')
    mb.box(63.5, -37, 4.2, 10.4, 7.4, 0.1, 'solar'); parapet(mb, 58.2, -41, 69, -33, 4.2, h=0.35)
    for k in range(3):
        mb.box(66.5, -39.5 + 2.6 * k, 0.2, 1.4, 0.9, 0.42, 'steel_teal'); mb.box(66.5, -38.9 + 2.6 * k, 0.55, 1.4, 0.2, 0.5, 'steel_teal')
    mb.box(60.5, -37, 0.2, 0.8, 2.6, 1.9, 'graphite_dark'); mb.box(60.15, -37, 0.8, 0.03, 2.4, 1.0, 'neon_cyan')
    pendant(mb, 62, -37, 3.5, 2.4, rot=90); pendant(mb, 66, -37, 3.5, 2.4, rot=90)
    mb.finish("Bld_EV_Lounge", cf)
    mb = MB()
    # battery / transformer yard
    for k in range(4):
        x_ = 61 + 2.0 * k
        mb.box(x_, -29.0, 0, 1.6, 2.2, 2.3, 'steel_painted', mtop='graphite_dark')
        mb.box(x_, -29.0, 0.4, 1.62, 1.0, 0.05, 'neon_cyan'); mb.box(x_ - 0.5, -27.85, 1.0, 0.6, 0.04, 0.9, 'graphite_dark')
    for k in range(2):
        mb.box(67.5, -31 + 2.5 * k, 0, 1.8, 1.6, 2.0, 'cabinet_blue', mtop='graphite_dark')
    mb.box(64, -30.2, 0, 10, 0.1, 1.2, 'graphite_dark', top=False)       # screen fence
    mb.finish("EV_Battery_Yard", cf)
