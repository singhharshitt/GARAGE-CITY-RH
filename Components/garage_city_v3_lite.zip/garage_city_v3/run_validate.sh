#!/bin/bash
# Full validation suite (run after run_build.sh). Writes validation_*.json + slot_diff_*.json. Needs: Blender, python3+numpy(+trimesh), node (tools/node_modules or THREE_DIR).
BL=${BLENDER:-/workspace/blender-4.2.3-linux-x64/blender}
cd "$(dirname "$0")"
export THREE_DIR=${THREE_DIR:-$PWD/tools/node_modules/three}
set -x
$BL -b garage_city_environment.blend --python validate_blend.py > logs_validate_blend.txt 2>&1
python3 validate_glb.py > logs_validate_glb.txt 2>&1
$BL -b --python validate_glb_blender.py > logs_validate_glb_blender.txt 2>&1
node threejs_load_test.mjs > logs_threejs_node.txt 2>&1
node validate_glb_three.mjs garage_city_environment.glb optimized/garage_city_environment.opt.glb garage_core.glb optimized/garage_core.opt.glb > logs_validate_glb_three.txt 2>&1
python3 diff_slots_v1.py > logs_slot_diff.txt 2>&1
# negative control on the .blend: cube in SLOT_bay_01 envelope + wall in front of SLOT_bay_05 -> validator MUST flag them
mkdir -p /tmp/negctrl
$BL -b garage_city_environment.blend --python negative_control.py > /dev/null 2>&1
VAL_OUT=$PWD VAL_NAME=validation_negative_control.json $BL -b /tmp/negctrl/garage_neg.blend --python validate_blend.py > logs_negctrl.txt 2>&1
echo VALIDATE_DONE
