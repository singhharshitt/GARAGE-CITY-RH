from gc_lib import *

PROTO = {}

def build_protos():
    # ---- palm trees (3 variants, shared meshes)
    for k, (H, L, nf) in enumerate([(5.0, 2.6, 9), (7.0, 3.0, 9), (9.5, 3.4, 10)]):
        mb = MB()
        segs = 3
        lean = (0.0, 0.0)
        px, py = 0.0, 0.0
        r = 0.22 + 0.04 * k
        for s_ in range(segs):
            h = H / segs
            nx = px + 0.18 * (s_ + 1) * (1 if k != 1 else -1) * 0.5
            mb.cyl(px, py, s_ * h, r * (1 - 0.18 * s_), h, 'trunk', seg=6, r2=r * (1 - 0.18 * (s_ + 1)), top=False)
            px = nx
        top = (px, py, H)
        for i in range(nf):
            a = 2 * math.pi * i / nf + 0.3 * k
            ca, sa = math.cos(a), math.sin(a)
            na, nb = -sa, ca
            def P(d, up, w):
                return ((top[0] + ca * d + na * w, top[1] + sa * d + nb * w, top[2] + up))
            drop = 0.9 + 0.1 * (i % 3)
            pts = [(0.0, 0.25, 0.10), (L * 0.45, 0.65, 0.42), (L * 0.85, -0.05, 0.28), (L, -drop, 0.02)]
            for a0, a1 in zip(pts[:-1], pts[1:]):
                mb.quad(P(a0[0], a0[1], -a0[2]), P(a1[0], a1[1], -a1[2]), P(a1[0], a1[1], a1[2]), P(a0[0], a0[1], a0[2]), 'palm_leaf')
        mb.box(top[0], top[1], H - 0.2, 0.3, 0.3, 0.3, 'trunk')
        PROTO['palm%d' % k] = mb.mesh('palm_proto_%d' % k)
    # ---- round trees (V3: lumpy layered canopy instead of cones)
    for k, (H, R) in enumerate([(2.8, 1.8), (3.6, 2.3)]):
        mb = MB()
        fm = 'foliage' if k == 0 else 'foliage_b'
        mb.cyl(0, 0, 0, 0.18, H, 'trunk', seg=5, r2=0.12, top=False)
        z0 = H - 0.7
        mb.cyl(0, 0, z0, R * 0.62, R * 0.45, fm, seg=8, r2=R * 1.0, top=False)
        mb.cyl(0.25 * R, 0.1 * R, z0 + R * 0.35, R * 0.95, R * 0.55, fm, seg=8, r2=R * 0.85, top=False)
        mb.cyl(-0.3 * R, -0.15 * R, z0 + R * 0.2, R * 0.7, R * 0.8, fm if k else 'foliage_b', seg=7, r2=R * 0.45, top=True)
        mb.cyl(0, 0, z0 + R * 0.85, R * 0.75, R * 0.5, fm, seg=8, r2=R * 0.25, top=True)
        PROTO['tree%d' % k] = mb.mesh('tree_proto_%d' % k)
    # ---- V3 cypress (slender conifer silhouette) + low bush cluster: breaks up the palm/tree repetition
    mb = MB()
    mb.cyl(0, 0, 0, 0.14, 1.0, 'trunk', seg=5, top=False)
    mb.cyl(0, 0, 0.8, 1.1, 3.2, 'foliage', seg=6, r2=0.55, top=False)
    mb.cyl(0, 0, 3.8, 0.58, 2.8, 'foliage_b', seg=6, r2=0.05, top=False)
    PROTO['cypress'] = mb.mesh('cypress_proto')
    mb = MB()
    for (bx, by, br) in ((0, 0, 0.7), (0.9, 0.3, 0.5), (-0.6, 0.55, 0.45)):
        mb.cyl(bx, by, 0, br, 0.55, 'foliage_b', seg=6, r2=br * 0.45, top=True)
    PROTO['bush'] = mb.mesh('bush_proto')
    # ---- shrub
    mb = MB()
    mb.cyl(0, 0, 0, 0.6, 0.5, 'foliage_b', seg=6, r2=0.35, top=True)
    PROTO['shrub'] = mb.mesh('shrub_proto')
    # ---- street light (amber head + cyan ring)
    mb = MB()
    mb.box(0, 0, 0, 0.5, 0.5, 0.4, 'graphite_dark')
    mb.cyl(0, 0, 0.4, 0.13, 8.0, 'graphite', seg=6, r2=0.09, top=False)
    mb.cyl(0, 0, 1.5, 0.16, 0.12, 'neon_cyan', seg=6)
    mb.box(1.0, 0, 8.2, 2.3, 0.14, 0.14, 'graphite')
    mb.box(1.9, 0, 8.05, 0.9, 0.42, 0.12, 'graphite_dark')
    mb.quad((1.45, 0.2, 8.04), (2.35, 0.2, 8.04), (2.35, -0.2, 8.04), (1.45, -0.2, 8.04), 'lamp_warm')
    PROTO['streetlight'] = mb.mesh('streetlight_proto')
    # ---- short plaza light (double arm, lower)
    mb = MB()
    mb.cyl(0, 0, 0, 0.1, 5.0, 'graphite', seg=6, r2=0.08, top=False)
    mb.box(0, 0, 5.0, 1.8, 0.3, 0.14, 'graphite_dark')
    mb.box(-0.8, 0, 4.9, 0.25, 0.25, 0.1, 'lamp_warm')
    mb.box(0.8, 0, 4.9, 0.25, 0.25, 0.1, 'neon_cyan')
    PROTO['plazalight'] = mb.mesh('plazalight_proto')
    # ---- bollard
    mb = MB()
    mb.cyl(0, 0, 0, 0.16, 0.8, 'graphite', seg=6, top=True)
    mb.cyl(0, 0, 0.62, 0.165, 0.08, 'neon_amber', seg=6)
    PROTO['bollard'] = mb.mesh('bollard_proto')
    # ---- road sign (abstract glyph, no text)
    mb = MB()
    mb.cyl(0, 0, 0, 0.05, 3.2, 'metal_light', seg=5)
    mb.box(0, 0.05, 2.2, 1.1, 0.06, 1.1, 'graphite_dark')
    mb.box(0, 0.09, 2.45, 0.7, 0.02, 0.12, 'neon_cyan')
    mb.box(0, 0.09, 2.65, 0.12, 0.02, 0.3, 'neon_amber')
    PROTO['sign'] = mb.mesh('roadsign_proto')
    # ---- low-poly planter shrub box (1.2m)
    mb = MB()
    mb.box(0, 0, 0, 1.4, 1.4, 0.55, 'planter')
    mb.cyl(0, 0, 0.55, 0.62, 0.55, 'foliage', seg=6, r2=0.25)
    PROTO['planter_s'] = mb.mesh('planter_small_proto')

_cnt = {}
def place(kind, collection, x, y, z=0.0, rot=None, scale=None, rng=random):
    me = PROTO[kind]
    _cnt[kind] = _cnt.get(kind, 0) + 1
    ob = bpy.data.objects.new("%s_%03d" % (kind, _cnt[kind]), me)
    ob.location = (x, y, z)
    ob.rotation_euler = (0, 0, math.radians(rng.uniform(0, 360) if rot is None else rot))
    s = scale if scale is not None else 1.0
    ob.scale = (s, s, s)
    collection.objects.link(ob)
    return ob

def palm(collection, x, y, z=0.0, rng=random, k=None):
    k = rng.choice([0, 1, 2]) if k is None else k
    return place('palm%d' % k, collection, x, y, z, rng=rng, scale=rng.uniform(0.85, 1.15))

def tree(collection, x, y, z=0.0, rng=random):
    return place('tree%d' % rng.choice([0, 1]), collection, x, y, z, rng=rng, scale=rng.uniform(0.9, 1.3))
