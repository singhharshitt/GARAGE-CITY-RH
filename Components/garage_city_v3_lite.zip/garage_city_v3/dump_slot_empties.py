import bpy, json, sys
out=sys.argv[-1]
d={}
for o in bpy.data.objects:
    if o.name.startswith('SLOT_'):
        d[o.name]=dict(m=[round(v,5) for r in o.matrix_world for v in r], props={k:(o[k] if isinstance(o[k],(int,float,str)) else str(o[k])) for k in o.keys()}, coll=[c.name for c in o.users_collection], disp=o.empty_display_type, size=o.empty_display_size)
json.dump(d,open(out,'w'),sort_keys=True)
