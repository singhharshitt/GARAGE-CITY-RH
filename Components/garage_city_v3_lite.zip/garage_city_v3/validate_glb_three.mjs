// node validate_glb_three.mjs [file.glb ...]   -> validation_glb_three_clearance.json
// Slot keep-clear + camera sight-line checks done on the SHIPPED GLB geometry as loaded by three.js (works for meshopt + instanced files that Blender cannot import).
// keep-clear: every triangle (instances expanded, world space) is tested against each slot's oriented envelope box (SAT).  floor tolerance 0.15 m (paint/decals).
// sight-line: rays from 5 points per slot (centre @1.0 m, 4 corners @0.5 m) to both game cameras, brute-force Moller-Trumbore, Sky_Dome excluded.
// negative control: a box dropped into SLOT_bay_01 and a wall between SLOT_bay_05 and the perspective camera MUST be detected.
import fs from 'fs'; import path from 'path'; import { fileURLToPath } from 'url';
const here = path.dirname(fileURLToPath(import.meta.url));
const THREE_DIR = process.env.THREE_DIR || path.join(here, 'tools/node_modules/three');
globalThis.self = globalThis; globalThis.createImageBitmap = async () => ({ width: 8, height: 8, close() {} });
const THREE = await import(THREE_DIR + '/build/three.module.js');
const { GLTFLoader } = await import(THREE_DIR + '/examples/jsm/loaders/GLTFLoader.js');
const { MeshoptDecoder } = await import(THREE_DIR + '/examples/jsm/libs/meshopt_decoder.module.js');
const files = process.argv.slice(2).length ? process.argv.slice(2) : ['garage_city_environment.glb', 'optimized/garage_city_environment.opt.glb'];
const TOL = 0.15;
function triSoup(scene) {
  const out = []; const v = [new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3()]; const m = new THREE.Matrix4(), im = new THREE.Matrix4();
  scene.updateMatrixWorld(true);
  scene.traverse((o) => {
    if (!o.isMesh || o.name.startsWith('Sky_Dome') || (o.parent && o.parent.name.startsWith('Sky_Dome'))) return;
    const g = o.geometry, pos = g.attributes.position, idx = g.index; const n = idx ? idx.count : pos.count;
    const cnt = o.isInstancedMesh ? o.count : 1;
    for (let k = 0; k < cnt; k++) {
      if (o.isInstancedMesh) { o.getMatrixAt(k, im); m.multiplyMatrices(o.matrixWorld, im); } else m.copy(o.matrixWorld);
      for (let t = 0; t < n; t += 3) {
        for (let j = 0; j < 3; j++) { const i = idx ? idx.getX(t + j) : t + j; v[j].set(pos.getX(i), pos.getY(i), pos.getZ(i)).applyMatrix4(m); }
        out.push(v[0].x, v[0].y, v[0].z, v[1].x, v[1].y, v[1].z, v[2].x, v[2].y, v[2].z);
      }
    }
  });
  return Float32Array.from(out);
}
function boxTri(T, i, hx, hy, z0, z1) {   // triangle (local coords, already in slot frame) vs AABB [-hx,hx]x[-hy,hy]x[z0,z1]  (SAT)
  const c = [0, (z0 + z1) / 2], h = [hx, hy, (z1 - z0) / 2];
  const p = [[T[i], T[i + 1], T[i + 2] - c[1]], [T[i + 3], T[i + 4], T[i + 5] - c[1]], [T[i + 6], T[i + 7], T[i + 8] - c[1]]];
  for (let a = 0; a < 3; a++) { const mn = Math.min(p[0][a], p[1][a], p[2][a]), mx = Math.max(p[0][a], p[1][a], p[2][a]); if (mn > h[a] || mx < -h[a]) return false; }
  const e = [[p[1][0] - p[0][0], p[1][1] - p[0][1], p[1][2] - p[0][2]], [p[2][0] - p[1][0], p[2][1] - p[1][1], p[2][2] - p[1][2]], [p[0][0] - p[2][0], p[0][1] - p[2][1], p[0][2] - p[2][2]]];
  const nrm = [e[0][1] * e[1][2] - e[0][2] * e[1][1], e[0][2] * e[1][0] - e[0][0] * e[1][2], e[0][0] * e[1][1] - e[0][1] * e[1][0]];
  const r = h[0] * Math.abs(nrm[0]) + h[1] * Math.abs(nrm[1]) + h[2] * Math.abs(nrm[2]); const d = nrm[0] * p[0][0] + nrm[1] * p[0][1] + nrm[2] * p[0][2];
  if (Math.abs(d) > r) return false;
  for (let a = 0; a < 3; a++) for (let b = 0; b < 3; b++) {
    const ax = a === 0 ? [0, -e[b][2], e[b][1]] : a === 1 ? [e[b][2], 0, -e[b][0]] : [-e[b][1], e[b][0], 0];
    const q0 = ax[0] * p[0][0] + ax[1] * p[0][1] + ax[2] * p[0][2], q1 = ax[0] * p[1][0] + ax[1] * p[1][1] + ax[2] * p[1][2], q2 = ax[0] * p[2][0] + ax[1] * p[2][1] + ax[2] * p[2][2];
    const rr = h[0] * Math.abs(ax[0]) + h[1] * Math.abs(ax[1]) + h[2] * Math.abs(ax[2]);
    if (Math.min(q0, q1, q2) > rr || Math.max(q0, q1, q2) < -rr) return false;
  }
  return true;
}
function rayHit(T, o, d, maxd) {   // any triangle hit closer than maxd
  for (let i = 0; i < T.length; i += 9) {
    const e1x = T[i + 3] - T[i], e1y = T[i + 4] - T[i + 1], e1z = T[i + 5] - T[i + 2], e2x = T[i + 6] - T[i], e2y = T[i + 7] - T[i + 1], e2z = T[i + 8] - T[i + 2];
    const px = d.y * e2z - d.z * e2y, py = d.z * e2x - d.x * e2z, pz = d.x * e2y - d.y * e2x; const det = e1x * px + e1y * py + e1z * pz; if (Math.abs(det) < 1e-9) continue;
    const inv = 1 / det, tx = o.x - T[i], ty = o.y - T[i + 1], tz = o.z - T[i + 2]; const u = (tx * px + ty * py + tz * pz) * inv; if (u < 0 || u > 1) continue;
    const qx = ty * e1z - tz * e1y, qy = tz * e1x - tx * e1z, qz = tx * e1y - ty * e1x; const v = (d.x * qx + d.y * qy + d.z * qz) * inv; if (v < 0 || u + v > 1) continue;
    const t = (e2x * qx + e2y * qy + e2z * qz) * inv; if (t > 1e-3 && t < maxd) return true;
  }
  return false;
}
function boxSoup(cx, cy, cz, sx, sy, sz) {
  const o = []; const V = []; for (const a of [-1, 1]) for (const b of [-1, 1]) for (const c of [-1, 1]) V.push([cx + a * sx / 2, cy + b * sy / 2, cz + c * sz / 2]);
  for (const f of [[0, 1, 3], [0, 3, 2], [4, 6, 7], [4, 7, 5], [0, 4, 5], [0, 5, 1], [2, 3, 7], [2, 7, 6], [0, 2, 6], [0, 6, 4], [1, 5, 7], [1, 7, 3]]) for (const k of f) o.push(...V[k]);
  return o;
}
function checkAll(scene, T, cams, slots) {
  const res = { slots_overlapping: [], los_blocked: {} };
  const q = new THREE.Quaternion(), p = new THREE.Vector3(), inv = new THREE.Matrix4(), loc = new Float32Array(9), w = new THREE.Vector3();
  for (const s of slots) {
    s.updateWorldMatrix(true, false); s.matrixWorld.decompose(p, q, new THREE.Vector3()); inv.copy(s.matrixWorld).invert();
    const W = s.userData.envelope_width_m, L = s.userData.envelope_length_m, Hh = s.userData.envelope_height_m;
    // slot local frame in glTF: Blender local +X -> +X, local +Y(nose) -> -Z, local +Z(up) -> +Y.  Envelope is W (x) by L (nose axis) by H (up).
    let hit = 0;
    for (let i = 0; i < T.length; i += 9) {
      if (Math.abs(T[i] - p.x) > 12 || Math.abs(T[i + 2] - p.z) > 12) continue;
      for (let j = 0; j < 9; j += 3) { w.set(T[i + j], T[i + j + 1], T[i + j + 2]).applyMatrix4(inv); loc[j] = w.x; loc[j + 1] = -w.z; loc[j + 2] = w.y; }   // -> (x, nose, up) in Blender-local convention
      if (boxTri(loc, 0, W / 2, L / 2, TOL, Hh)) hit++;
    }
    if (hit) res.slots_overlapping.push({ slot: s.name, triangles: hit });
  }
  for (const [cn, cam] of Object.entries(cams)) {
    let blocked = 0, rays = 0; const camPos = new THREE.Vector3(); cam.getWorldPosition(camPos);
    const fwd = new THREE.Vector3(0, 0, -1).applyQuaternion(cam.getWorldQuaternion(new THREE.Quaternion()));
    for (const s of slots) {
      const W = s.userData.envelope_width_m, L = s.userData.envelope_length_m;
      const pts = [[0, 0, 1.0], ...[[-1, -1], [-1, 1], [1, -1], [1, 1]].map(([a, b]) => [a * W / 2, b * L / 2, 0.5])];
      for (const [x, nose, up] of pts) {
        const wp = new THREE.Vector3(x, up, -nose).applyMatrix4(s.matrixWorld);   // Blender local (x, y=nose, z=up) -> glTF local (x, z, -y)
        let d, dist; if (cam.isPerspectiveCamera) { d = camPos.clone().sub(wp); dist = d.length(); d.normalize(); } else { d = fwd.clone().negate(); dist = 400; }
        rays++; if (rayHit(T, wp, d, dist)) blocked++;
      }
    }
    res.los_blocked[cn] = { rays, blocked };
  }
  return res;
}
const out = { three_revision: THREE.REVISION, files: {} };
for (const f of files) {
  const buf = fs.readFileSync(path.join(here, f)); const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
  const g = await new Promise((res, rej) => new GLTFLoader().setMeshoptDecoder(MeshoptDecoder).parse(ab, '', res, rej));
  const scene = g.scene; const slots = []; scene.traverse(o => { if (o.name.startsWith('SLOT_')) slots.push(o); });
  const cams = {}; for (const c of g.cameras) { for (const n of [c.name, c.parent && c.parent.name]) if (n === 'CAM_Game_Perspective' || n === 'CAM_Game_Isometric_Ortho') cams[n] = c; }
  const T = triSoup(scene); const r = { triangles_in_soup: T.length / 9, slots: slots.length, cameras: Object.keys(cams) };
  const t0 = Date.now(); Object.assign(r, checkAll(scene, T, cams, slots)); r.seconds = (Date.now() - t0) / 1000;
  // negative control: bay_01 box + wall in front of the perspective camera for bay_05
  const s1 = slots.find(s => s.name === 'SLOT_bay_01'), s5 = slots.find(s => s.name === 'SLOT_bay_05'); const hasCam = !!cams.CAM_Game_Perspective;
  const p1 = new THREE.Vector3(); s1.getWorldPosition(p1); const p5 = new THREE.Vector3(); s5.getWorldPosition(p5);
  let extra = boxSoup(p1.x, p1.y + 0.9, p1.z, 1.5, 1.2, 1.5);
  if (hasCam) { const cp = new THREE.Vector3(); cams.CAM_Game_Perspective.getWorldPosition(cp); const wp = p5.clone().add(cp.clone().sub(p5).normalize().multiplyScalar(3)); extra = [...extra, ...boxSoup(wp.x, p5.y + 3, wp.z, 6, 6, 6)]; }
  const T2 = Float32Array.from([...T, ...extra]);
  const neg = checkAll(scene, T2, cams, slots);
  r.los_note = hasCam ? 'sight-lines checked' : 'file has no cameras (split core file): sight-lines not checked here, keep-clear only';
  r.negative_control = { overlapping_detected: neg.slots_overlapping.map(s => s.slot), los_blocked: neg.los_blocked,
    PASS: neg.slots_overlapping.some(s => s.slot === 'SLOT_bay_01') && (!hasCam || neg.los_blocked.CAM_Game_Perspective.blocked > r.los_blocked.CAM_Game_Perspective.blocked) };
  out.files[f] = r; console.log(f, JSON.stringify({ slots_overlapping: r.slots_overlapping, los_blocked: r.los_blocked, neg: r.negative_control.PASS, s: r.seconds }));
}
fs.writeFileSync(path.join(here, 'validation_glb_three_clearance.json'), JSON.stringify(out, null, 1));
