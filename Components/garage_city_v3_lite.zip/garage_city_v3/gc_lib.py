"""Garage City RH - shared helpers (mesh builder, materials, textures, instancing).
Run through Blender:  blender -b --python build_scene.py
Units: 1 Blender unit = 1 metre, +Z up. World origin = centre of the garage compound.
"""
import bpy, bmesh, math, random, os
import numpy as np
from mathutils import Vector, Matrix

OUT = os.path.dirname(os.path.abspath(__file__))
TEX_DIR = os.path.join(OUT, "textures")
os.makedirs(TEX_DIR, exist_ok=True)

# ---------------------------------------------------------------- colours
def srgb(h):
    h = h.lstrip('#')
    c = [int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4)]
    lin = [(x / 12.92 if x <= 0.04045 else ((x + 0.055) / 1.055) ** 2.4) for x in c]
    return (lin[0], lin[1], lin[2], 1.0)

# ---------------------------------------------------------------- collections
_root = None
def root_coll():
    global _root
    if _root is None:
        _root = bpy.data.collections.new("Garage_City_RH")
        bpy.context.scene.collection.children.link(_root)
    return _root

def coll(name, parent=None):
    if name in bpy.data.collections:
        return bpy.data.collections[name]
    c = bpy.data.collections.new(name)
    (parent or root_coll()).children.link(c)
    return c

# ---------------------------------------------------------------- images
def save_img(name, arr):
    """arr float HxWx4 0..1 (sRGB values). Creates packed image + file on disk."""
    h, w = arr.shape[:2]
    img = bpy.data.images.new(name, w, h, alpha=False)
    img.colorspace_settings.name = 'sRGB'
    a = np.clip(arr, 0, 1).astype(np.float32)
    # blender images store linear for sRGB images when set via pixels? pixels are interpreted as the
    # colour-space of the image data (we write sRGB-encoded values directly via 'byte' buffer)
    img.pixels.foreach_set(a.flatten())
    img.filepath_raw = os.path.join(TEX_DIR, name + ".png")
    img.file_format = 'PNG'
    img.save()
    img.pack()
    return img

def make_window_tex(name, palette, lit_prob, seed, size=512, cells=8):
    rng = np.random.RandomState(seed)
    cs = size // cells
    arr = np.zeros((size, size, 4), np.float32)
    wall = np.array([0.055, 0.065, 0.09, 1])
    arr[:] = wall
    for r in range(cells):
        rowp = rng.choice([0.3, 0.9, 1.6]); rowc = palette[rng.choice(len(palette), p=[q[1] for q in palette])][0]
        for c in range(cells):
            x0, y0 = c * cs, r * cs
            mx, my = int(cs * 0.14), int(cs * 0.17)
            lit = rng.rand() < lit_prob * rowp
            if lit:
                p = rowc if rng.rand() < 0.75 else palette[rng.choice(len(palette), p=[q[1] for q in palette])][0]
                k = 0.65 + 0.35 * rng.rand()
                col = np.array([p[0] * k, p[1] * k, p[2] * k, 1])
            else:
                col = np.array([0.035, 0.06, 0.10, 1]) * (0.8 + 0.5 * rng.rand())
                col[3] = 1
            arr[y0 + my:y0 + cs - my, x0 + mx:x0 + cs - mx] = col
            # mullion split
            arr[y0 + my:y0 + cs - my, x0 + cs // 2 - 1:x0 + cs // 2 + 1] = wall
    return save_img(name, arr)

def make_sky_tex(name):
    h = 512
    stops = [  # (t from horizon 0 -> zenith 1, colour sRGB)  V3: sunset ember at the horizon, quickly into blue hour
        (0.00, (1.00, 0.58, 0.28)), (0.05, (0.96, 0.46, 0.34)), (0.13, (0.66, 0.34, 0.50)),
        (0.28, (0.30, 0.27, 0.56)), (0.55, (0.11, 0.16, 0.42)), (1.0, (0.035, 0.07, 0.25))]
    arr = np.zeros((h, 8, 4), np.float32)
    for i in range(h):
        t = i / (h - 1)  # row 0 = bottom of image = nadir ... we map v: 0 bottom pole,1 top pole
        # v=0.0 nadir, 0.5 horizon, 1.0 zenith
        if t < 0.5:
            col = np.array(stops[0][1]) * min(1.0, max(0.15, 1 - (0.5 - t) * 1.2)) * 0.5
        else:
            u = (t - 0.5) * 2
            for (t0, c0), (t1, c1) in zip(stops[:-1], stops[1:]):
                if t0 <= u <= t1:
                    f = (u - t0) / (t1 - t0)
                    col = np.array(c0) * (1 - f) + np.array(c1) * f
                    break
        arr[i, :, :3] = col
        arr[i, :, 3] = 1
    return save_img(name, arr)

def make_water_tex(name, size=256):
    """V3: calm, tileable harbour water -- soft broad swell bands + a few faint glints (no hard streaks, no grid)"""
    y, x = np.mgrid[0:size, 0:size] / size
    rng = np.random.RandomState(7)
    v = np.zeros((size, size))
    for _ in range(9):
        kx, ky = rng.randint(1, 5), rng.randint(1, 5)
        ph = rng.rand() * 6.28
        v += np.sin(2 * math.pi * (kx * x + ky * y) + ph) * rng.rand()
    v = (v - v.min()) / (v.max() - v.min())
    glint = np.clip((v - 0.80) * 5, 0, 1) ** 2
    base = np.array([0.025, 0.085, 0.16]); mid = np.array([0.05, 0.15, 0.26]); hi = np.array([0.30, 0.55, 0.75])
    arr = np.zeros((size, size, 4), np.float32)
    for k in range(3):
        arr[..., k] = base[k] * (1 - v) + mid[k] * v + hi[k] * glint * 0.30
    arr[..., 3] = 1
    return save_img(name, arr)

def make_glow_tex(name, size=128):
    y, x = np.mgrid[0:size, 0:size]
    r = np.hypot((x - size / 2 + 0.5) / (size / 2), (y - size / 2 + 0.5) / (size / 2))
    a = np.clip(1 - r, 0, 1) ** 2.2
    img = bpy.data.images.new(name, size, size, alpha=True)
    arr = np.ones((size, size, 4), np.float32)
    arr[..., 3] = a
    img.pixels.foreach_set(arr.flatten())
    img.alpha_mode = 'STRAIGHT'
    img.filepath_raw = os.path.join(TEX_DIR, name + ".png"); img.file_format = 'PNG'
    img.save(); img.pack()
    return img



# ---------------------------------------------------------------- V2 textures (all <= 512 px, tiling, procedural)
def _noise(size, rng, octaves=((4, .5), (16, .3), (64, .2))):
    out = np.zeros((size, size))
    for n, a in octaves:
        g = rng.rand(n, n)
        # bilinear upsample (tileable)
        xs = np.linspace(0, n, size, endpoint=False)
        x0 = xs.astype(int); fx = xs - x0; x1 = (x0 + 1) % n
        row = g[:, x0] * (1 - fx) + g[:, x1] * fx
        ys = np.linspace(0, n, size, endpoint=False)
        y0 = ys.astype(int); fy = (ys - y0)[:, None]; y1 = (y0 + 1) % n
        out += a * (row[y0] * (1 - fy) + row[y1] * fy)
    return out

def make_concrete_tex(name, base, size=256, joints=4, contrast=0.10, seed=11):
    rng = np.random.RandomState(seed)
    n = _noise(size, rng)
    n = (n - n.mean())
    arr = np.zeros((size, size, 4), np.float32)
    for k in range(3):
        arr[..., k] = base[k] * (1 + contrast * n * 3) + (rng.rand(size, size) - 0.5) * 0.02
    if joints:
        cs = size // joints
        for i in range(joints):
            arr[i * cs:i * cs + 2, :, :3] *= 0.62
            arr[:, i * cs:i * cs + 2, :3] *= 0.62
    arr[..., 3] = 1
    return save_img(name, arr)

def make_asphalt_tex(name, base, size=256, seed=5):
    rng = np.random.RandomState(seed)
    n = _noise(size, rng, ((8, .4), (32, .3), (128, .3)))
    grain = (rng.rand(size, size) - 0.5)
    arr = np.zeros((size, size, 4), np.float32)
    for k in range(3):
        arr[..., k] = base[k] * (1 + 0.45 * (n - n.mean()) + 0.30 * grain)
    arr[..., 3] = 1
    return save_img(name, arr)

def make_brushed_tex(name, base, size=256, seed=3, panel=4):
    rng = np.random.RandomState(seed)
    streak = rng.rand(size, 1) * 0.5 + rng.rand(size, 1) * 0.5
    streak = np.repeat(streak, size, axis=1)
    smooth = (streak + np.roll(streak, 1, 0) + np.roll(streak, -1, 0)) / 3
    arr = np.zeros((size, size, 4), np.float32)
    for k in range(3):
        arr[..., k] = base[k] * (0.82 + 0.36 * smooth)
    cs = size // panel
    for i in range(panel):
        arr[i * cs:i * cs + 2, :, :3] *= 0.55
        arr[:, i * cs:i * cs + 2, :3] *= 0.55
        arr[i * cs + 4:i * cs + 6:2, 6::cs // 2 if cs // 2 else 1, :3] *= 1.3   # rivet-ish dots
    arr[..., 3] = 1
    return save_img(name, arr)

def make_hazard_tex(name, size=128):
    y, x = np.mgrid[0:size, 0:size]
    stripe = (((x + y) // 16) % 2).astype(np.float32)
    arr = np.zeros((size, size, 4), np.float32)
    arr[..., 0] = 0.07 + stripe * 0.85; arr[..., 1] = 0.07 + stripe * 0.68; arr[..., 2] = 0.07 + stripe * 0.08; arr[..., 3] = 1
    return save_img(name, arr)

def make_window_band_tex(name, palette, lit_prob, seed, size=512):
    """horizontal ribbon-window floors: 16 floor bands, each divided into 8 lit/unlit segments"""
    rng = np.random.RandomState(seed)
    arr = np.zeros((size, size, 4), np.float32); arr[:] = np.array([0.07, 0.085, 0.11, 1])
    fh = size // 16
    for f in range(16):
        y0 = f * fh + int(fh * 0.22); y1 = f * fh + int(fh * 0.80)
        seg = size // 8
        rowp = rng.choice([0.3, 0.9, 1.6]); rowc = palette[rng.choice(len(palette), p=[q[1] for q in palette])][0]
        for c in range(8):
            if rng.rand() < lit_prob * rowp:
                p = rowc if rng.rand() < 0.8 else palette[rng.choice(len(palette), p=[q[1] for q in palette])][0]
                k = 0.6 + 0.4 * rng.rand(); col = np.array([p[0] * k, p[1] * k, p[2] * k, 1])
            else:
                col = np.array([0.045, 0.075, 0.12, 1]) * (0.8 + 0.5 * rng.rand()); col[3] = 1
            arr[y0:y1, c * seg + 1:(c + 1) * seg - 1] = col
    return save_img(name, arr)

def make_window_curtain_tex(name, palette, lit_prob, seed, size=512, cells=16):
    """glass curtain wall: fine grid, blue-grey unlit glass, a few lit panes"""
    rng = np.random.RandomState(seed)
    cs = size // cells
    arr = np.zeros((size, size, 4), np.float32); arr[:] = np.array([0.05, 0.065, 0.09, 1])
    for r in range(cells):
        rowp = rng.choice([0.3, 0.9, 1.6]); rowc = palette[rng.choice(len(palette), p=[q[1] for q in palette])][0]
        for c in range(cells):
            if rng.rand() < lit_prob * rowp:
                p = rowc if rng.rand() < 0.8 else palette[rng.choice(len(palette), p=[q[1] for q in palette])][0]
                k = 0.55 + 0.45 * rng.rand(); col = np.array([p[0] * k, p[1] * k, p[2] * k, 1])
            else:
                col = np.array([0.07, 0.15, 0.24, 1]) * (0.75 + 0.5 * rng.rand()); col[3] = 1
            arr[r * cs + 1:(r + 1) * cs - 1, c * cs + 1:(c + 1) * cs - 1] = col
    return save_img(name, arr)

def make_window_punch_tex(name, palette, lit_prob, seed, size=512):
    """V3 punched-opening facade: light concrete wall field with recessed dark openings (reads as architecture, not as a lit grid)"""
    rng = np.random.RandomState(seed)
    arr = np.zeros((size, size, 4), np.float32)
    n = _noise(size, rng, ((4, .6), (16, .4)))
    base = np.array([0.20, 0.215, 0.255])
    for k in range(3):
        arr[..., k] = base[k] * (1 + 0.35 * (n - n.mean()))
    arr[..., 3] = 1
    cols, rows = 6, 8
    cw, rh = size // cols, size // rows
    for r in range(rows):
        flo = rng.rand() < 0.5
        for c in range(cols):
            x0, y0 = c * cw + int(cw * 0.22), r * rh + int(rh * 0.2)
            x1, y1 = (c + 1) * cw - int(cw * 0.22), (r + 1) * rh - int(rh * 0.28)
            if rng.rand() < lit_prob * (1.6 if flo else 0.5):
                p = palette[rng.choice(len(palette), p=[q[1] for q in palette])][0]
                k = 0.7 + 0.3 * rng.rand(); col = np.array([p[0] * k, p[1] * k, p[2] * k, 1])
            else:
                col = np.array([0.03, 0.05, 0.08, 1]) * (0.8 + 0.5 * rng.rand()); col[3] = 1
            arr[y0:y1, x0:x1] = col
            arr[y1:y1 + 3, x0 - 2:x1 + 2, :3] = base * 1.5          # sill highlight
    return save_img(name, arr)

def make_window_fins_tex(name, palette, lit_prob, seed, size=512):
    """V3 vertical-fin facade: dark glass strips between light fins, lit strips follow whole columns (varied rhythm)"""
    rng = np.random.RandomState(seed)
    arr = np.zeros((size, size, 4), np.float32); arr[:] = np.array([0.12, 0.135, 0.17, 1])
    strips = 16; sw = size // strips
    for c in range(strips):
        colp = rng.choice([0.2, 0.8, 1.5])
        for seg in range(4):
            y0, y1 = seg * (size // 4) + 4, (seg + 1) * (size // 4) - 4
            if rng.rand() < lit_prob * colp:
                p = palette[rng.choice(len(palette), p=[q[1] for q in palette])][0]
                k = 0.6 + 0.4 * rng.rand(); col = np.array([p[0] * k, p[1] * k, p[2] * k, 1])
            else:
                col = np.array([0.04, 0.07, 0.11, 1]) * (0.8 + 0.5 * rng.rand()); col[3] = 1
            arr[y0:y1, c * sw + 4:(c + 1) * sw - 4] = col
    return save_img(name, arr)

# ---------------------------------------------------------------- materials
MATS = {}
def mat(name, color, rough=0.6, metal=0.0, emit=None, estr=0.0, tex=None, emit_tex=False, unlit_tex=None, uvscale=None):
    if name in MATS:
        return MATS[name]
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    bsdf = nt.nodes["Principled BSDF"]
    bsdf.inputs["Roughness"].default_value = rough
    bsdf.inputs["Metallic"].default_value = metal
    if tex is not None:
        tn = nt.nodes.new("ShaderNodeTexImage")
        tn.image = tex
        tn.interpolation = 'Linear'
        tn.extension = 'REPEAT'
        nt.links.new(tn.outputs["Color"], bsdf.inputs["Base Color"])
        if emit_tex:
            nt.links.new(tn.outputs["Color"], bsdf.inputs["Emission Color"])
            bsdf.inputs["Emission Strength"].default_value = estr
    else:
        bsdf.inputs["Base Color"].default_value = srgb(color)
        if emit:
            bsdf.inputs["Emission Color"].default_value = srgb(emit)
            bsdf.inputs["Emission Strength"].default_value = estr
    if unlit_tex is not None:   # emission-only (sky dome): black base, emissive texture
        bsdf.inputs["Base Color"].default_value = (0, 0, 0, 1)
        bsdf.inputs["Roughness"].default_value = 1
        bsdf.inputs["Specular IOR Level"].default_value = 0
        tn = nt.nodes.new("ShaderNodeTexImage"); tn.image = unlit_tex
        tn.extension = 'EXTEND'
        nt.links.new(tn.outputs["Color"], bsdf.inputs["Emission Color"])
        bsdf.inputs["Emission Strength"].default_value = 1.0
    m.diffuse_color = srgb(color or '#808080')
    m.use_backface_culling = name not in ('palm_leaf',)
    MATS[name] = m
    return m

# ---------------------------------------------------------------- mesh builder
class MB:
    def __init__(self):
        self.bm = bmesh.new()
        self.uvl = self.bm.loops.layers.uv.new("UVMap")
        self.mats = []
        self.counts = 0

    def mi(self, m):
        if isinstance(m, str):
            m = MATS[m]
        if m not in self.mats:
            self.mats.append(m)
        return self.mats.index(m)

    def _face(self, pts, m, uvs=None):
        try:
            vs = [self.bm.verts.new(p) for p in pts]
            f = self.bm.faces.new(vs)
        except ValueError:
            return None
        f.material_index = self.mi(m)
        if not uvs:
            # default: world-planar UV (3 m per tile) so tiling textures (concrete, asphalt, brushed metal) work everywhere
            n = (Vector(pts[1]) - Vector(pts[0])).cross(Vector(pts[-1]) - Vector(pts[0]))
            ax = max(range(3), key=lambda i: abs(n[i])) if n.length > 0 else 2
            S = 3.0
            uvs = [((p[0] / S, p[1] / S) if ax == 2 else ((p[0] / S, p[2] / S) if ax == 1 else (p[1] / S, p[2] / S))) for p in pts]
        for l, uv in zip(f.loops, uvs):
            l[self.uvl].uv = uv
        return f

    def quad(self, p0, p1, p2, p3, m, uvs=None):
        return self._face([p0, p1, p2, p3], m, uvs)

    def tri(self, p0, p1, p2, m):
        return self._face([p0, p1, p2], m)

    # --- box: centre x,y ; base z ; size ; yaw (deg)
    def box(self, x, y, z, sx, sy, sz, m, rot=0, mtop=None, mbot=None, bottom=False, top=True,
            uv=None, sides=(True, True, True, True)):
        """uv=(tile_u_m, tile_v_m, u_off, v_off) -> window-style side UVs (metres per tile)."""
        c, s = math.cos(math.radians(rot)), math.sin(math.radians(rot))
        hx, hy = sx / 2, sy / 2
        loc = [(-hx, -hy), (hx, -hy), (hx, hy), (-hx, hy)]
        pts = [(x + a * c - b * s, y + a * s + b * c) for a, b in loc]
        b = [(p[0], p[1], z) for p in pts]
        t = [(p[0], p[1], z + sz) for p in pts]
        if bottom:
            self._face([b[0], b[3], b[2], b[1]], mbot or m)
        if top:
            self._face([t[0], t[1], t[2], t[3]], mtop or m)
        lens = [sx, sy, sx, sy]
        u0 = 0
        for i in range(4):
            if not sides[i]:
                continue
            j = (i + 1) % 4
            uvs = None
            if uv:
                tu, tv, uo, vo = uv
                ua = uo + u0 / tu
                ub = ua + lens[i] / tu
                uvs = [(ua, vo), (ub, vo), (ub, vo + sz / tv), (ua, vo + sz / tv)]
            self._face([b[i], b[j], t[j], t[i]], m, uvs)
            u0 += lens[i]

    def cyl(self, x, y, z, r, h, m, seg=8, r2=None, mtop=None, top=True, bottom=False, uv=None, rot=0):
        r2 = r if r2 is None else r2
        bot = [(x + r * math.cos(rot + 2 * math.pi * i / seg), y + r * math.sin(rot + 2 * math.pi * i / seg), z) for i in range(seg)]
        tp = [(x + r2 * math.cos(rot + 2 * math.pi * i / seg), y + r2 * math.sin(rot + 2 * math.pi * i / seg), z + h) for i in range(seg)]
        for i in range(seg):
            j = (i + 1) % seg
            uvs = None
            if uv:
                tu, tv, uo, vo = uv
                circ = 2 * math.pi * r
                ua = uo + circ * i / seg / tu
                ub = uo + circ * (i + 1) / seg / tu
                uvs = [(ua, vo), (ub, vo), (ub, vo + h / tv), (ua, vo + h / tv)]
            self._face([bot[i], bot[j], tp[j], tp[i]], m, uvs)
        if top and r2 > 0:
            self._face(tp, mtop or m)
        if bottom:
            self._face(bot[::-1], m)

    def hcyl(self, x, y, z, r, length, m, axis='x', seg=8):
        """horizontal cylinder (tyres, pipes) with axis along x or y, centre at (x,y,z)."""
        pts0, pts1 = [], []
        for i in range(seg):
            a = 2 * math.pi * i / seg
            u, v = r * math.cos(a), r * math.sin(a)
            if axis == 'x':
                pts0.append((x - length / 2, y + u, z + v)); pts1.append((x + length / 2, y + u, z + v))
            else:
                pts0.append((x + u, y - length / 2, z + v)); pts1.append((x + u, y + length / 2, z + v))
        for i in range(seg):
            j = (i + 1) % seg
            self._face([pts0[i], pts1[i], pts1[j], pts0[j]], m)
        self._face(pts1, m); self._face(pts0[::-1], m)

    def wedge(self, x, y, z, sx, sy, sz, m, rot=0, mside=None):
        """ramp: rises from z (at local -x) to z+sz (at local +x)."""
        c, s = math.cos(math.radians(rot)), math.sin(math.radians(rot))
        def P(a, b, h):
            return (x + a * c - b * s, y + a * s + b * c, z + h)
        hx, hy = sx / 2, sy / 2
        b0, b1, b2, b3 = P(-hx, -hy, 0), P(hx, -hy, 0), P(hx, hy, 0), P(-hx, hy, 0)
        t1, t2 = P(hx, -hy, sz), P(hx, hy, sz)
        self._face([b0, b3, b2, b1], m)
        self._face([b0, b1, t1], mside or m)
        self._face([b2, b3, t2], mside or m)
        self._face([b0, t1, t2, b3], m)     # slope
        self._face([b1, b2, t2, t1], mside or m)

    def stairs(self, x, y, z0, width, rise, run_dir, n, m, tread=0.30, mside=None):
        """straight stair; run_dir deg (0=+x). starts at (x,y) z0, n steps each rise/n."""
        r = rise / n
        c, s = math.cos(math.radians(run_dir)), math.sin(math.radians(run_dir))
        for i in range(n):
            d = i * tread + tread / 2
            self.box(x + c * d, y + s * d, z0, tread, width, r * (i + 1), m, rot=run_dir, mtop=mside)

    def frustum(self, x, y, z, w0, d0, w1, d1, h, m, rot=0, mtop=None, uv=None, off=(0.0, 0.0)):
        """tapered prism: base w0 x d0 at z, top w1 x d1 at z+h (top centre shifted by off)."""
        c, s = math.cos(math.radians(rot)), math.sin(math.radians(rot))
        def R(a, b, dx=0.0, dy=0.0):
            return (x + dx * c - dy * s + a * c - b * s, y + dx * s + dy * c + a * s + b * c)
        b = [R(-w0 / 2, -d0 / 2), R(w0 / 2, -d0 / 2), R(w0 / 2, d0 / 2), R(-w0 / 2, d0 / 2)]
        t = [R(-w1 / 2, -d1 / 2, *off), R(w1 / 2, -d1 / 2, *off), R(w1 / 2, d1 / 2, *off), R(-w1 / 2, d1 / 2, *off)]
        lens = [w0, d0, w0, d0]
        u0 = 0
        for i in range(4):
            j = (i + 1) % 4
            uvs = None
            if uv:
                tu, tv, uo, vo = uv
                ua = uo + u0 / tu; ub = ua + lens[i] / tu
                uvs = [(ua, vo), (ub, vo), (ub, vo + h / tv), (ua, vo + h / tv)]
            self._face([(b[i][0], b[i][1], z), (b[j][0], b[j][1], z), (t[j][0], t[j][1], z + h), (t[i][0], t[i][1], z + h)], m, uvs)
            u0 += lens[i]
        self._face([(p[0], p[1], z + h) for p in t], mtop or m)

    def twist(self, x, y, z, w, d, h, turn, steps, m, taper=1.0, mtop=None, uv=None, nsides=4):
        """twisted prism: rotates `turn` degrees over h, optional linear taper (top scale)."""
        rings = []
        for k in range(steps + 1):
            f = k / steps
            a = math.radians(turn * f) + math.pi / nsides * (1 if nsides != 4 else 0)
            sc = 1.0 + (taper - 1.0) * f
            ring = []
            for i in range(nsides):
                ang = 2 * math.pi * i / nsides + math.pi / 4 if nsides == 4 else 2 * math.pi * i / nsides
                px, py = math.cos(ang) * w / 2 * 1.4142 * (1 if nsides == 4 else 1), math.sin(ang) * d / 2 * 1.4142
                if nsides != 4:
                    px, py = math.cos(ang) * w / 2, math.sin(ang) * d / 2
                ca, sa = math.cos(a), math.sin(a)
                ring.append((x + (px * ca - py * sa) * sc, y + (px * sa + py * ca) * sc, z + h * f))
            rings.append(ring)
        per = 2 * math.pi * (w / 2)
        for k in range(steps):
            for i in range(nsides):
                j = (i + 1) % nsides
                uvs = None
                if uv:
                    tu, tv, uo, vo = uv
                    ua = uo + (per * i / nsides) / tu; ub = uo + (per * (i + 1) / nsides) / tu
                    va = vo + (h * k / steps) / tv; vb = vo + (h * (k + 1) / steps) / tv
                    uvs = [(ua, va), (ub, va), (ub, vb), (ua, vb)]
                self._face([rings[k][i], rings[k][j], rings[k + 1][j], rings[k + 1][i]], m, uvs)
        self._face(rings[-1], mtop or m)
        return rings[-1]

    def vault(self, x, y, z, length, width, rise, m, axis='x', seg=8, mcap=None):
        """barrel-vault roof (circular arc) spanning `width`, running `length` along `axis`; end caps are flat polygons."""
        R = (width * width / 4 + rise * rise) / (2 * rise)
        a0 = math.asin(width / 2 / R)
        pts = []
        for i in range(seg + 1):
            a = -a0 + 2 * a0 * i / seg
            pts.append((R * math.sin(a), R * math.cos(a) - (R - rise)))
        def P3(u, v, t):
            return (x + t, y + u, z + v) if axis == 'x' else (x + u, y + t, z + v)
        for i in range(seg):
            (u0, v0), (u1, v1) = pts[i], pts[i + 1]
            if axis == 'x':
                self._face([P3(u0, v0, -length / 2), P3(u0, v0, length / 2), P3(u1, v1, length / 2), P3(u1, v1, -length / 2)], m)
            else:
                self._face([P3(u0, v0, -length / 2), P3(u1, v1, -length / 2), P3(u1, v1, length / 2), P3(u0, v0, length / 2)], m)
        for t, sg in ((-length / 2, 1), (length / 2, -1)):
            poly = [P3(u, v, t) for (u, v) in pts]
            if sg == -1:
                poly = poly[::-1]
            self._face(poly, mcap or m)

    def pipe(self, p0, p1, r, m, seg=6, caps=True):
        a = Vector(p0); b = Vector(p1)
        d = b - a
        if d.length < 1e-4:
            return
        d.normalize()
        ref = Vector((0, 0, 1)) if abs(d.z) < 0.9 else Vector((1, 0, 0))
        u = d.cross(ref).normalized(); v = d.cross(u).normalized()
        c0, c1 = [], []
        for i in range(seg):
            ang = 2 * math.pi * i / seg
            off = (u * math.cos(ang) + v * math.sin(ang)) * r
            c0.append(tuple(a + off)); c1.append(tuple(b + off))
        for i in range(seg):
            j = (i + 1) % seg
            self._face([c0[i], c0[j], c1[j], c1[i]], m)
        if caps:
            self._face(c1, m)

    def ring_flat(self, cx, cy, z, r0, r1, m, seg=32, a0=0.0, a1=2 * math.pi):
        for i in range(seg):
            t0 = a0 + (a1 - a0) * i / seg; t1 = a0 + (a1 - a0) * (i + 1) / seg
            self._face([(cx + r0 * math.cos(t0), cy + r0 * math.sin(t0), z), (cx + r1 * math.cos(t0), cy + r1 * math.sin(t0), z),
                        (cx + r1 * math.cos(t1), cy + r1 * math.sin(t1), z), (cx + r0 * math.cos(t1), cy + r0 * math.sin(t1), z)], m)

    def mesh(self, name):
        bm = self.bm
        me = bpy.data.meshes.new(name)
        bm.normal_update()
        bm.to_mesh(me)
        bm.free()
        for m in self.mats:
            me.materials.append(m)
        for p in me.polygons:
            p.use_smooth = False
        return me

    def finish(self, name, collection, loc=(0, 0, 0)):
        me = self.mesh(name)
        ob = bpy.data.objects.new(name, me)
        ob.location = loc
        collection.objects.link(ob)
        return ob

def glow(mb, cx, cy, sx, sy, m, z=0.075, rot=0.0):
    c, s_ = math.cos(math.radians(rot)), math.sin(math.radians(rot))
    def P(a, b):
        return (cx + a * c - b * s_, cy + a * s_ + b * c, z)
    mb.quad(P(-sx / 2, -sy / 2), P(sx / 2, -sy / 2), P(sx / 2, sy / 2), P(-sx / 2, sy / 2), m, uvs=[(0, 0), (1, 0), (1, 1), (0, 1)])

def gq(mb, x0, y0, x1, y1, z, m):
    """axis aligned quad facing +Z"""
    mb.quad((x0, y0, z), (x1, y0, z), (x1, y1, z), (x0, y1, z), m)

def railing(mb, x0, y0, x1, y1, z, h=1.1, m='metal_light', mneon=None, post=2.0):
    L = math.hypot(x1 - x0, y1 - y0)
    n = max(1, int(L / post))
    ang = math.degrees(math.atan2(y1 - y0, x1 - x0))
    for i in range(n + 1):
        t = i / n
        mb.box(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, z, 0.07, 0.07, h, m, rot=ang)
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    mb.box(cx, cy, z + h, L, 0.08, 0.06, m, rot=ang)
    mb.box(cx, cy, z + h * 0.5, L, 0.04, 0.04, m, rot=ang)
    if mneon:
        mb.box(cx, cy, z + h + 0.06, L, 0.05, 0.03, mneon, rot=ang)

def link_dup(name, proto_obj, collection, loc, rot=0, scale=1.0, sz=None):
    ob = bpy.data.objects.new(name, proto_obj.data)
    ob.location = loc
    ob.rotation_euler = (0, 0, math.radians(rot))
    ob.scale = (scale, scale, scale if sz is None else sz)
    collection.objects.link(ob)
    return ob

def tri_count_obj(ob):
    if ob.type != 'MESH':
        return 0
    me = ob.data
    n = 0
    for p in me.polygons:
        n += len(p.vertices) - 2
    return n


# ---------------------------------------------------------------- keep-clear helper (V2): new detail props must not intrude into slot footprints
SLOT_FOOT = []     # (cx, cy, hx, hy)  axis-aligned footprint of every slot envelope (rotation aware, includes yaw_extra)
def register_slot_footprint(x, y, w, l, yaw):
    c, s_ = abs(math.cos(math.radians(yaw))), abs(math.sin(math.radians(yaw)))
    SLOT_FOOT.append((x, y, (w * c + l * s_) / 2, (w * s_ + l * c) / 2))

def free_xy(x, y, sx=0.0, sy=0.0, margin=1.0):
    """True if the AABB (centre x,y; size sx,sy) stays `margin` m away from every slot envelope footprint."""
    for (cx, cy, hx, hy) in SLOT_FOOT:
        if abs(x - cx) < hx + sx / 2 + margin and abs(y - cy) < hy + sy / 2 + margin:
            return False
    return True
